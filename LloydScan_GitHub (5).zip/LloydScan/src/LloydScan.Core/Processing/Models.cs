using LloydScan.Core.Configuration;
using LloydScan.Core.Imaging;
using LloydScan.Core.Pdf;

namespace LloydScan.Core.Processing;

/// <summary>Image brute reçue du scanner ou d'un fichier importé.</summary>
public sealed class ScannedImage
{
    public byte[] Data { get; init; } = Array.Empty<byte>();
    /// <summary>
    /// Page mise en attente sur le disque (le scanner va plus vite que le traitement) : évite d'accumuler
    /// des images de 25 Mo en mémoire. Lue puis supprimée au moment du traitement.
    /// </summary>
    public string? SpoolPath { get; init; }
    /// <summary>Résolution à utiliser si le fichier n'en indique pas de fiable.</summary>
    public double? DpiHint { get; init; }
    public string? SourceName { get; init; }
}

/// <summary>Fichier PDF importé d'origine : permet de le déposer tel quel s'il est déjà plus léger que le résultat.</summary>
public sealed class ImportSource
{
    public byte[] Data { get; init; } = Array.Empty<byte>();
    public int PageCount { get; init; }
}

public sealed class ProcessedPage
{
    public int Index { get; set; }
    public string? SourceName { get; init; }
    public string? QrText { get; init; }
    public bool IsSeparator { get; init; }
    public bool IsBlank { get; init; }
    public double InkRatio { get; init; }
    public OptimizedPage? Optimized { get; set; }
    /// <summary>Vignette (≈ 180 px de large) pour l'écran de contrôle, avant rotation manuelle.</summary>
    public RasterImage Thumbnail { get; set; } = null!;
    /// <summary>Rotation manuelle (0, 90, 180, 270), appliquée sans perte dans le PDF.</summary>
    public int Rotation
    {
        get => Optimized?.Rotation ?? 0;
        set { if (Optimized != null) Optimized.Rotation = ((value % 360) + 360) % 360; }
    }
    /// <summary>Bilan du nettoyage automatique ou manuel (bords, trous, redressement).</summary>
    public string CleanupNote { get; set; } = "";
    /// <summary>Copie de la page numérisée (dossier de travail local) pour un nettoyage manuel ultérieur.</summary>
    public string? SourcePath { get; set; }
    /// <summary>Résolution de la copie source (pages blanches retirées, qui n'ont pas de PDF de référence).</summary>
    public double SourceDpi { get; init; }
    /// <summary>Profil utilisé, réappliqué en cas de retraitement.</summary>
    public ScanProfile? Profile { get; init; }
    /// <summary>PDF importé dont provient la page, et sa position dans ce fichier.</summary>
    public ImportSource? Origin { get; init; }
    public int OriginIndex { get; init; }
    /// <summary>Retouches manuelles de l'image (fenêtre « Image »), rejouées à chaque retraitement.</summary>
    public Imaging.ImageAdjustments? Adjustments { get; set; }
    /// <summary>Nettoyage appliqué en dernier (profil ou nettoyage manuel complet).</summary>
    public Configuration.CleanupSettings? AppliedCleanup { get; set; }

    /// <summary>PDF natif conservé tel quel (optimisé sans perte) au lieu d'une page numérisée.</summary>
    public byte[]? NativePdf { get; init; }
    public int NativePageCount { get; init; }
    /// <summary>Taille non compressée de la page (pixels).</summary>
    public long RawBytes { get; init; }
    /// <summary>Taille de la page à l'entrée : image transmise par le scanner ou part du fichier importé.</summary>
    public long InputBytes { get; init; }
    public string? Error { get; init; }
}

public enum DocumentStatus { Ready, Sending, Sent, Queued, Failed }

/// <summary>Un document = les pages comprises entre deux pages séparatrices.</summary>
public sealed class ScanDocument
{
    public int Sequence { get; set; }
    public string? QrText { get; init; }
    public string Target { get; set; } = "";
    public string RoutingReason { get; set; } = "";
    /// <summary>Destination donnée par la règle VIE / Lloyd, conservée quand un profil impose une autre destination.</summary>
    public string? RoutedTarget { get; set; }
    public List<ProcessedPage> Pages { get; } = new();
    public List<string> Warnings { get; } = new();
    /// <summary>Modifications manuelles (tracées dans le journal).</summary>
    public List<string> Edits { get; } = new();
    public string FileName { get; set; } = "";
    public byte[]? Pdf { get; set; }
    public DocumentStatus Status { get; set; } = DocumentStatus.Ready;
    public string? RemoteUrl { get; set; }
    /// <summary>Compte WebDAV utilisé pour le dépôt (traçabilité).</summary>
    public string? Account { get; set; }
    public string? Error { get; set; }

    public long RawBytes => Pages.Sum(p => p.RawBytes);
    /// <summary>Taille à l'entrée de la numérisation (scanner ou fichiers importés).</summary>
    public long InputBytes => Pages.Sum(p => p.InputBytes);

    /// <summary>Document issu d'un PDF natif (pas de retouche de pages possible).</summary>
    /// <remarks>Le document peut commencer par sa fiche séparatrice numérisée, placée en tête du PDF natif.</remarks>
    public bool IsNativePdf => Pages.Count(p => p.NativePdf != null) == 1 && Pages.All(p => p.NativePdf != null || p.IsSeparator);
    public ProcessedPage? NativePage => Pages.FirstOrDefault(p => p.NativePdf != null);
    public int PageCount => IsNativePdf ? NativePage!.NativePageCount + Pages.Count(p => p.IsSeparator) : Pages.Count;
    public long PdfBytes => Pdf?.LongLength ?? 0;
}

public sealed class BatchResult
{
    public string BatchId { get; init; } = "";
    public DateTimeOffset StartedAt { get; init; }
    public string ProfileName { get; init; } = "";
    public List<ScanDocument> Documents { get; } = new();
    public List<string> Warnings { get; } = new();
    public int TotalPages { get; set; }
    public int BlankPagesRemoved { get; set; }
    /// <summary>Pages retirées comme blanches, gardées jusqu'à l'envoi pour pouvoir être réintégrées (zéro perte).</summary>
    public List<ProcessedPage> RemovedBlankPages { get; } = new();
    public int SeparatorPages { get; set; }
}
