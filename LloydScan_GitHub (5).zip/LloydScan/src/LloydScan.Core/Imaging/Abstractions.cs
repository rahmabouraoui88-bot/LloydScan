namespace LloydScan.Core.Imaging;

/// <summary>Décodage des images reçues (BMP du pilote TWAIN, TIFF/JPEG/PNG importés) et encodage JPEG.</summary>
public interface IImageCodec
{
    /// <summary>Décode un fichier image ; un TIFF multipage renvoie plusieurs pages.</summary>
    IReadOnlyList<RasterImage> Decode(byte[] data);

    /// <summary>Encode en JPEG baseline (gris si 1 canal, RGB si 3 canaux).</summary>
    byte[] EncodeJpeg(RasterImage image, int quality);

    /// <summary>
    /// Lecture page par page d'un fichier (PDF ou TIFF de plusieurs pages) : une seule page décodée en mémoire à la fois,
    /// indispensable dans le processus 32 bits. Par défaut : décodage complet (codecs de test).
    /// </summary>
    IFrameReader OpenFrames(byte[] data) => new ListFrameReader(Decode(data));
}

/// <summary>Accès aux pages d'un fichier, une à la fois.</summary>
public interface IFrameReader : IDisposable
{
    int Count { get; }
    /// <summary>Décode la page <paramref name="index"/>, réduite si besoin à <paramref name="maxDpi"/>.</summary>
    RasterImage Read(int index, double maxDpi);
}

internal sealed class ListFrameReader : IFrameReader
{
    private readonly IReadOnlyList<RasterImage> _frames;
    public ListFrameReader(IReadOnlyList<RasterImage> frames) => _frames = frames;
    public int Count => _frames.Count;
    public RasterImage Read(int index, double maxDpi)
    {
        var f = _frames[index];
        return f.Dpi > maxDpi * 1.02 ? ImageOps.ScaleToDpi(f, maxDpi) : f;
    }
    public void Dispose() { }
}

/// <summary>Lecture de QR code sur une image en niveaux de gris.</summary>
public interface IQrDecoder
{
    /// <summary>Renvoie le texte du premier QR trouvé, ou null.</summary>
    string? Decode(RasterImage gray);
}
