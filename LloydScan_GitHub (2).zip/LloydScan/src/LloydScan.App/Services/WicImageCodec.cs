using System.IO;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using LloydScan.Core.Imaging;

namespace LloydScan.App.Services;

/// <summary>
/// Codec basé sur WIC (Windows Imaging Component, intégré à Windows) :
/// lit les BMP des pilotes TWAIN/WIA, les TIFF/JPEG/PNG et (via Windows.Data.Pdf) les PDF importés, encode en JPEG.
/// Aucune licence tierce.
/// </summary>
public sealed class WicImageCodec : IImageCodec
{
    /// <summary>Résolution de rendu des PDF (copieurs multifonctions).</summary>
    public const double PdfRenderDpi = 300;

    public IReadOnlyList<RasterImage> Decode(byte[] data)
    {
        if (PdfRasterizer.IsPdf(data))
        {
            var pages = new List<RasterImage>();
            foreach (var png in PdfRasterizer.RenderPages(data, PdfRenderDpi))
                foreach (var page in DecodeImage(png))
                {
                    page.Dpi = PdfRenderDpi;
                    pages.Add(page);
                }
            return pages;
        }
        return DecodeImage(data);
    }

    private static IReadOnlyList<RasterImage> DecodeImage(byte[] data)
    {
        using var ms = new MemoryStream(data, writable: false);
        var decoder = BitmapDecoder.Create(ms,
            BitmapCreateOptions.PreservePixelFormat | BitmapCreateOptions.IgnoreColorProfile,
            BitmapCacheOption.OnLoad);
        var pages = new List<RasterImage>(decoder.Frames.Count);
        foreach (var frame in decoder.Frames) pages.Add(ToRaster(frame));
        return pages;
    }

    private static RasterImage ToRaster(BitmapSource src)
    {
        bool gray = IsGray(src);
        var target = gray ? PixelFormats.Gray8 : PixelFormats.Rgb24;
        BitmapSource converted = src.Format == target ? src : new FormatConvertedBitmap(src, target, null, 0);
        int w = converted.PixelWidth, h = converted.PixelHeight, c = gray ? 1 : 3;
        var pixels = new byte[w * h * c];
        converted.CopyPixels(pixels, w * c, 0);
        return new RasterImage(w, h, c, pixels, src.DpiX);
    }

    private static bool IsGray(BitmapSource src)
    {
        var f = src.Format;
        if (f == PixelFormats.BlackWhite || f == PixelFormats.Gray2 || f == PixelFormats.Gray4 ||
            f == PixelFormats.Gray8 || f == PixelFormats.Gray16 || f == PixelFormats.Gray32Float)
            return true;
        // Images indexées (BMP 1 bit du mode noir et blanc) : grises si la palette l'est
        if (src.Palette != null &&
            (f == PixelFormats.Indexed1 || f == PixelFormats.Indexed2 || f == PixelFormats.Indexed4 || f == PixelFormats.Indexed8))
            return src.Palette.Colors.All(col => col.R == col.G && col.G == col.B);
        return false;
    }

    public byte[] EncodeJpeg(RasterImage image, int quality)
    {
        var format = image.IsGray ? PixelFormats.Gray8 : PixelFormats.Rgb24;
        BitmapSource bmp = BitmapSource.Create(image.Width, image.Height, image.Dpi, image.Dpi, format, null,
            image.Pixels, image.Stride);
        // L'encodeur JPEG de WIC attend du BGR 24 bits ou du gris 8 bits
        if (!image.IsGray) bmp = new FormatConvertedBitmap(bmp, PixelFormats.Bgr24, null, 0);
        var encoder = new JpegBitmapEncoder { QualityLevel = quality };
        encoder.Frames.Add(BitmapFrame.Create(bmp));
        using var ms = new MemoryStream();
        encoder.Save(ms);
        return ms.ToArray();
    }

    /// <summary>Conversion d'une vignette pour l'affichage WPF.</summary>
    public static BitmapSource ToBitmapSource(RasterImage image)
    {
        var format = image.IsGray ? PixelFormats.Gray8 : PixelFormats.Rgb24;
        var bmp = BitmapSource.Create(image.Width, image.Height, 96, 96, format, null, image.Pixels, image.Stride);
        bmp.Freeze();
        return bmp;
    }
}
