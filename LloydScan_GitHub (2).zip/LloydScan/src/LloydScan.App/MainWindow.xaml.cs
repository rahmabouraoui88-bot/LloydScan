using System.ComponentModel;
using System.IO;
using System.Windows;
using System.Windows.Interop;
using System.Windows.Media.Imaging;
using LloydScan.App.ViewModels;

namespace LloydScan.App;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
        LoadLogo();
        SourceInitialized += (_, _) =>
        {
            if (DataContext is MainViewModel vm) vm.WindowHandle = new WindowInteropHelper(this).Handle;
        };
        Loaded += (_, _) => (DataContext as MainViewModel)?.Initialize();
    }

    /// <summary>
    /// Logo de l'entreprise : Assets\logo.png (PNG, fond transparent de préférence), à côté de NAPS++.exe,
    /// affiché en haut à gauche. Assets\icon.png (carré) sert d'icône de fenêtre et de barre des tâches
    /// (à défaut, le logo). Pour les changer : remplacer les fichiers et relancer, sans recompiler.
    /// </summary>
    private void LoadLogo()
    {
        try
        {
            var assets = Path.Combine(AppContext.BaseDirectory, "Assets");
            var logo = Load(Path.Combine(assets, "logo.png"));
            if (logo != null)
            {
                LogoImage.Source = logo;
                LogoImage.Visibility = Visibility.Visible;
            }
            var icon = Load(Path.Combine(assets, "icon.png")) ?? logo;
            if (icon != null) Icon = icon;
        }
        catch
        {
            // Logo illisible : l'application démarre quand même, sans logo
        }
    }

    private static BitmapImage? Load(string path)
    {
        if (!File.Exists(path)) return null;
        var image = new BitmapImage();
        image.BeginInit();
        image.CacheOption = BitmapCacheOption.OnLoad;   // fichier libéré tout de suite (remplaçable)
        image.UriSource = new Uri(path);
        image.EndInit();
        image.Freeze();
        return image;
    }

    protected override void OnClosing(CancelEventArgs e)
    {
        if (DataContext is MainViewModel vm)
        {
            if (vm.IsBusy &&
                MessageBox.Show("Un traitement est en cours. Quitter quand même ?", AppInfo.Name,
                    MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes)
            {
                e.Cancel = true;
                return;
            }
            vm.Dispose();
        }
        base.OnClosing(e);
    }
}
