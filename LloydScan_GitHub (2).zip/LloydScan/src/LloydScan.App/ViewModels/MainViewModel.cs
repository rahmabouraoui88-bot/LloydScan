using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Threading;
using Microsoft.Win32;
using LloydScan.App.Services;
using LloydScan.Core.Configuration;
using LloydScan.Core.Processing;
using LloydScan.Core.Upload;

namespace LloydScan.App.ViewModels;

/// <summary>Scanner disponible, quel que soit son pilote.</summary>
public sealed record ScannerSource(string Kind, string Id, string Name)
{
    public string DisplayName => $"{Name}  ({Kind})";
    public override string ToString() => DisplayName;
}

public sealed class MainViewModel : ObservableObject, IDisposable
{
    private readonly AppSettings _settings;
    private readonly ScanPipeline _pipeline;
    private readonly DocumentEditor _editor;
    private readonly Dictionary<BatchResult, BatchSnapshot> _snapshots = new();
    private readonly DocumentSender _sender;
    private readonly AgentCredentialStore _credentials = new();
    private readonly TwainScanner _scanner = new();
    private readonly WiaScanner _wia = new();
    private readonly List<HotFolderScanner> _hotFolders;
    private readonly DispatcherTimer _hotTimer = new() { Interval = TimeSpan.FromSeconds(5) };
    private bool _hotRunning;
    private readonly string? _configWarning;
    private CancellationTokenSource? _cts;

    public MainViewModel(AppSettings settings, string? configWarning = null)
    {
        _settings = settings;
        _configWarning = configWarning;
        _pipeline = new ScanPipeline(settings, new WicImageCodec(), new LloydScan.Core.Imaging.Qr.QrReader(),
            new WindowsPdfTool(settings.Pdf.ResolveQpdfPath()),
            new LloydScan.Core.Ocr.TesseractOcr(settings.Ocr.ResolveTesseractPath(), settings.Ocr.Languages,
                settings.Ocr.ResolveTessdataPath(), settings.Ocr.MinConfidence));
        _editor = new DocumentEditor(_pipeline);
        _sender = new DocumentSender(settings, _credentials);
        _hotFolders = settings.HotFolders.Where(h => !string.IsNullOrWhiteSpace(h.Path)).Select(h => new HotFolderScanner(h)).ToList();

        // Profils ouverts à cet agent sur ce poste (règles de l'administrateur LLOYD)
        Profiles = settings.ProfilesFor(Environment.MachineName, Environment.UserName);
        _selectedProfile = settings.ResolveProfile(Environment.MachineName, Environment.UserName);
        TargetNames = settings.Targets.Keys.ToList();

        RefreshScannersCommand = new RelayCommand(RefreshScanners, () => !IsBusy);
        ScanCommand = new AsyncRelayCommand(ScanAsync, () => !IsBusy && SelectedScanner != null);
        ImportCommand = new AsyncRelayCommand(ImportAsync, () => !IsBusy);
        CancelCommand = new RelayCommand(() => _cts?.Cancel(), () => IsBusy && _cts != null);
        SendAllCommand = new AsyncRelayCommand(SendAllAsync,
            () => !IsBusy && Documents.Any(d => d.Document.Status is DocumentStatus.Ready or DocumentStatus.Failed));
        RetryOutboxCommand = new AsyncRelayCommand(RetryOutboxAsync, () => !IsBusy && PendingCount > 0);
        ClearCommand = new RelayCommand(Clear, () => !IsBusy && Documents.Count > 0);
        OpenPdfCommand = new RelayCommand(OpenSelectedPdf, () => SelectedDocument?.Document.Pdf != null);
        OpenJournalCommand = new RelayCommand(() => OpenFolder(_sender.JournalFolder));
        CredentialsCommand = new RelayCommand(() => EditCredentials(null), () => !IsBusy);

        // Retouches des pages avant envoi
        bool PageEditable() => !IsBusy && SelectedDocument?.CanEdit == true && SelectedDocument.Document.IsNativePdf == false
                               && SelectedPage != null;
        RotateLeftCommand = new RelayCommand(() => EditPage((b, d, p) => _editor.Rotate(b, d, p, -90)), PageEditable);
        RotateRightCommand = new RelayCommand(() => EditPage((b, d, p) => _editor.Rotate(b, d, p, 90)), PageEditable);
        Rotate180Command = new RelayCommand(() => EditPage((b, d, p) => _editor.Rotate(b, d, p, 180)), PageEditable);
        MovePageLeftCommand = new RelayCommand(() => EditPage((b, d, p) => _editor.Move(b, d, p, -1)), PageEditable);
        MovePageRightCommand = new RelayCommand(() => EditPage((b, d, p) => _editor.Move(b, d, p, +1)), PageEditable);
        DeletePageCommand = new RelayCommand(DeletePage, PageEditable);
        SplitHereCommand = new RelayCommand(() => EditPage((b, d, p) => _editor.SplitBefore(b, d, p)), PageEditable);
        MergeNextCommand = new RelayCommand(() => EditPage((b, d, _) => _editor.MergeWithNext(b, d), requirePage: false),
            () => !IsBusy && SelectedDocument?.CanEdit == true);
        CleanPageCommand = new AsyncRelayCommand(CleanPageAsync, PageEditable);
        RestoreBatchCommand = new RelayCommand(RestoreBatch,
            () => !IsBusy && SelectedDocument != null && _snapshots.ContainsKey(SelectedDocument.Batch));
        RestoreBlankCommand = new RelayCommand(RestoreBlankPages,
            () => !IsBusy && SelectedDocument?.Batch.RemovedBlankPages.Count > 0);
    }

    // ---------------- Propriétés liées à l'écran ----------------

    public IReadOnlyList<ScanProfile> Profiles { get; }
    /// <summary>Faux si l'administrateur impose un profil unique à ce poste ou à cet agent.</summary>
    public bool CanChooseProfile => Profiles.Count > 1;
    public string ProfileLockText => CanChooseProfile
        ? "Profils autorisés par l'administrateur LLOYD"
        : "Profil imposé par l'administrateur LLOYD pour ce poste";
    public IReadOnlyList<string> TargetNames { get; }
    public ObservableCollection<ScannerSource> Scanners { get; } = new();
    public ObservableCollection<DocumentItem> Documents { get; } = new();

    private ScanProfile _selectedProfile;
    public ScanProfile SelectedProfile
    {
        get => _selectedProfile;
        set { if (Set(ref _selectedProfile, value)) OnPropertyChanged(nameof(ProfileDetails)); }
    }

    /// <summary>Réglages du profil, affichés en lecture seule (définis par l'administrateur).</summary>
    public string ProfileDetails
    {
        get
        {
            var p = SelectedProfile;
            string color = p.ColorMode switch { ScanColorMode.Gray => "gris", ScanColorMode.BlackWhite => "noir et blanc", _ => "couleur" };
            string output = p.Output.Mode switch
            {
                OutputMode.Auto => "optimisation auto (MRC)",
                OutputMode.Mrc => "MRC couleur",
                OutputMode.Color => $"JPEG couleur {p.Output.ImageDpi} dpi",
                OutputMode.Gray => $"JPEG gris {p.Output.ImageDpi} dpi",
                _ => "noir et blanc G4"
            };
            return $"{p.Resolution} dpi · {color} · {(p.Duplex ? "recto-verso" : "recto")} · " +
                   $"{(p.RemoveBlankPages ? "pages blanches retirées" : "pages blanches conservées")} · {output}";
        }
    }

    /// <summary>Agent connecté et comptes WebDAV utilisés pour chaque destination.</summary>
    public string AgentInfo =>
        $"Agent {Environment.UserDomainName}\\{Environment.UserName} — " + string.Join(" · ", _settings.Targets.Select(kv =>
            $"{kv.Value.DisplayName} : " + kv.Value.Authentication switch
            {
                WebDavAuthentication.Windows => "session Windows",
                WebDavAuthentication.Service => "compte de service",
                _ => _credentials.Get(kv.Key, kv.Value)?.Username ?? "à renseigner"
            }));

    private ScannerSource? _selectedScanner;
    public ScannerSource? SelectedScanner { get => _selectedScanner; set => Set(ref _selectedScanner, value); }

    /// <summary>Dossiers surveillés actifs (copieurs multifonctions).</summary>
    public string HotFolderInfo =>
        (_settings.Ocr.Enabled ? (_pipeline.OcrActive ? $"OCR {_settings.Ocr.Languages} · " : "OCR indisponible · ") : "") +
        (_settings.Pdf.PdfA ? "PDF/A-2b" : "PDF") +
        (_hotFolders.Count == 0 ? "" : " · Dossiers surveillés : " + string.Join(", ", _hotFolders.Select(h => h.Settings.Name)));

    private DocumentItem? _selectedDocument;
    public DocumentItem? SelectedDocument
    {
        get => _selectedDocument;
        set { if (Set(ref _selectedDocument, value)) SelectedPage = null; }
    }

    private PageItem? _selectedPage;
    public PageItem? SelectedPage { get => _selectedPage; set => Set(ref _selectedPage, value); }

    private bool _isBusy;
    public bool IsBusy { get => _isBusy; private set => Set(ref _isBusy, value); }

    private string _statusText = "Prêt.";
    public string StatusText { get => _statusText; private set => Set(ref _statusText, value); }

    private int _pendingCount;
    public int PendingCount
    {
        get => _pendingCount;
        private set { if (Set(ref _pendingCount, value)) OnPropertyChanged(nameof(RetryLabel)); }
    }
    public string RetryLabel => PendingCount > 0 ? $"Renvoyer la file ({PendingCount})" : "File d'attente vide";

    public string Summary
    {
        get
        {
            if (Documents.Count == 0) return "";
            long before = Documents.Sum(d => d.Document.InputBytes), pdf = Documents.Sum(d => d.Document.PdfBytes);
            int pages = Documents.Sum(d => d.PageCount);
            int vie = Documents.Count(d => d.Target == _settings.Routing.VieTarget);
            string gain = before > 0 ? $" (−{100.0 * (1 - (double)pdf / before):0.#} %)" : "";
            return $"{Documents.Count} document(s) · {pages} page(s) · {vie} vers {_settings.Routing.VieTarget}, " +
                   $"{Documents.Count - vie} vers Lloyd · Taille : {DocumentItem.FormatSize(before)} → {DocumentItem.FormatSize(pdf)}{gain}";
        }
    }

    public IntPtr WindowHandle { get; set; }

    public RelayCommand RefreshScannersCommand { get; }
    public AsyncRelayCommand ScanCommand { get; }
    public AsyncRelayCommand ImportCommand { get; }
    public RelayCommand CancelCommand { get; }
    public AsyncRelayCommand SendAllCommand { get; }
    public AsyncRelayCommand RetryOutboxCommand { get; }
    public RelayCommand ClearCommand { get; }
    public RelayCommand OpenPdfCommand { get; }
    public RelayCommand OpenJournalCommand { get; }
    public RelayCommand CredentialsCommand { get; }
    public RelayCommand RotateLeftCommand { get; }
    public RelayCommand RotateRightCommand { get; }
    public RelayCommand Rotate180Command { get; }
    public RelayCommand MovePageLeftCommand { get; }
    public RelayCommand MovePageRightCommand { get; }
    public RelayCommand DeletePageCommand { get; }
    public RelayCommand SplitHereCommand { get; }
    public RelayCommand MergeNextCommand { get; }
    public AsyncRelayCommand CleanPageCommand { get; }
    public RelayCommand RestoreBatchCommand { get; }
    public RelayCommand RestoreBlankCommand { get; }

    // ---------------- Démarrage ----------------

    public void Initialize()
    {
        _pipeline.PurgeOldSources(TimeSpan.FromDays(2));
        var error = _scanner.Open();
        if (error != null) StatusText = error + " Les scanners WIA et l'import de fichiers restent disponibles.";
        RefreshScanners();
        PendingCount = _sender.PendingCount();
        if (PendingCount > 0)
            StatusText = $"{PendingCount} document(s) en file d'attente d'un envoi précédent : cliquer sur « Renvoyer la file ».";
        if (_settings.Ocr.Enabled && !_pipeline.OcrActive)
            StatusText = "OCR indisponible (tools\\tesseract absent ou Windows 32 bits) : les PDF seront produits sans texte interrogeable.";
        OnPropertyChanged(nameof(HotFolderInfo));
        if (_configWarning != null) StatusText = _configWarning;

        // Dossiers surveillés (copieurs multifonctions)
        if (_hotFolders.Count > 0)
        {
            _hotTimer.Tick += async (_, _) => await PollHotFoldersAsync();
            _hotTimer.Start();
        }

        // Première utilisation : l'agent renseigne ses comptes ELISE Lloyd / Lloyd Vie
        var missing = _credentials.Missing(_settings);
        if (missing.Count > 0)
            _ = Application.Current.Dispatcher.InvokeAsync(() =>
                EditCredentials("Première utilisation : renseignez vos identifiants WebDAV personnels."));
    }

    /// <summary>Ouvre « Mes identifiants ». Renvoie true si l'agent a enregistré.</summary>
    private bool EditCredentials(string? intro)
    {
        var window = new CredentialsWindow(_settings, _credentials, intro) { Owner = Application.Current.MainWindow };
        bool saved = window.ShowDialog() == true;
        if (saved)
        {
            _sender.ResetClients();
            OnPropertyChanged(nameof(AgentInfo));
            StatusText = "Identifiants enregistrés.";
        }
        return saved;
    }

    private void RefreshScanners()
    {
        var current = SelectedScanner;
        Scanners.Clear();
        // 1. TWAIN : pilotes des fabricants (recommandé, toutes les options du scanner)
        foreach (var name in _scanner.GetSources()) Scanners.Add(new ScannerSource("TWAIN", name, name));
        // 2. WIA : pilote intégré à Windows (scanners sans pilote TWAIN, ou pilote dans l'autre architecture 32/64 bits)
        try
        {
            foreach (var d in WiaScanner.GetDevices()) Scanners.Add(new ScannerSource("WIA", d.Id, d.Name));
        }
        catch (Exception ex) { Debug.WriteLine("WIA indisponible : " + ex.Message); }

        SelectedScanner = Scanners.FirstOrDefault(s => s == current) ?? Scanners.FirstOrDefault();
        if (Scanners.Count == 0)
            StatusText = "Aucun scanner détecté (TWAIN ou WIA). Vérifier le branchement et le pilote, puis « Actualiser ».";
    }

    // ---------------- Numérisation ----------------

    private Task ScanAsync()
    {
        var profile = SelectedProfile;
        var source = SelectedScanner!;
        return RunBatchAsync(ct => source.Kind == "WIA"
                ? _wia.Scan(source.Id, profile, ct)
                : _scanner.Scan(source.Id, profile, WindowHandle, ct),
            profile, $"Numérisation sur {source.DisplayName}…", interactive: true);
    }

    private Task ImportAsync()
    {
        var dialog = new OpenFileDialog
        {
            Title = "Importer des images numérisées",
            Filter = "Documents numérisés (*.pdf;*.tif;*.tiff;*.jpg;*.jpeg;*.png;*.bmp)|*.pdf;*.tif;*.tiff;*.jpg;*.jpeg;*.png;*.bmp",
            Multiselect = true
        };
        if (dialog.ShowDialog() != true) return Task.CompletedTask;
        var files = dialog.FileNames.OrderBy(f => f, StringComparer.OrdinalIgnoreCase).ToArray();
        return RunBatchAsync(ct => ReadFiles(files, ct), SelectedProfile, $"Import de {files.Length} fichier(s)…", interactive: true);
    }

    private static async IAsyncEnumerable<ScannedImage> ReadFiles(string[] files, [EnumeratorCancellation] CancellationToken ct)
    {
        foreach (var f in files)
        {
            ct.ThrowIfCancellationRequested();
            yield return new ScannedImage { Data = await File.ReadAllBytesAsync(f, ct), SourceName = Path.GetFileName(f) };
        }
    }

    /// <summary>Traite un lot ; renvoie null si aucune page n'a été reçue ou en cas d'annulation.</summary>
    private async Task<BatchResult?> RunBatchAsync(Func<CancellationToken, IAsyncEnumerable<ScannedImage>> source,
        ScanProfile profile, string message, bool interactive)
    {
        _cts = new CancellationTokenSource();
        IsBusy = true;
        StatusText = message;
        var progress = new Progress<string>(s => StatusText = s);
        try
        {
            var images = source(_cts.Token);
            if (_scanner.LastWarnings.Count > 0)
                Debug.WriteLine("Réglages non appliqués : " + string.Join(", ", _scanner.LastWarnings));
            var batch = await Task.Run(() => _pipeline.ProcessAsync(images, profile, progress, _cts.Token));
            if (batch.TotalPages == 0)
            {
                StatusText = "Aucune page reçue. Vérifier que les documents sont dans le chargeur.";
                return null;
            }
            foreach (var doc in batch.Documents)
                Documents.Add(new DocumentItem(doc, batch, Retarget, _settings.Routing.OperatorOverride));
            _snapshots[batch] = BatchSnapshot.Capture(batch);
            SelectedDocument ??= Documents.FirstOrDefault();
            OnPropertyChanged(nameof(Summary));

            var alerts = batch.Warnings.Concat(batch.Documents.SelectMany(d => d.Warnings.Select(w => $"Document {d.Sequence} : {w}"))).ToList();
            long inBytes = batch.Documents.Sum(d => d.InputBytes), outBytes = batch.Documents.Sum(d => d.PdfBytes);
            int outPages = batch.Documents.Sum(d => d.PageCount);
            string size = inBytes == 0 ? "" :
                $" Taille : {DocumentItem.FormatSize(inBytes)} → {DocumentItem.FormatSize(outBytes)} " +
                $"(−{100.0 * (1 - (double)outBytes / inBytes):0.#} %, {DocumentItem.FormatSize(outBytes / Math.Max(1, outPages))} par page).";
            StatusText = $"{batch.Documents.Count} document(s) prêt(s) à vérifier — {batch.TotalPages} page(s), " +
                         $"{batch.BlankPagesRemoved} blanche(s) retirée(s)" +
                         (batch.BlankPagesRemoved > 0 ? " (récupérables : « Pages blanches retirées… »)" : "") +
                         $", {batch.SeparatorPages} séparatrice(s)." + size +
                         (alerts.Count > 0 ? $" {alerts.Count} alerte(s) à vérifier (lignes en orange)." : "");
            if (interactive && batch.Warnings.Count > 0)
                MessageBox.Show(string.Join(Environment.NewLine, batch.Warnings), "Alertes du lot",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
            return batch;
        }
        catch (OperationCanceledException)
        {
            StatusText = "Opération annulée.";
            return null;
        }
        finally
        {
            IsBusy = false;
            _cts.Dispose();
            _cts = null;
        }
    }

    // ---------------- Retouches des pages ----------------

    /// <summary>Applique une retouche à la page sélectionnée puis resynchronise l'affichage du lot.</summary>
    private void EditPage(Action<BatchResult, ScanDocument, ProcessedPage> operation, bool requirePage = true)
    {
        var item = SelectedDocument;
        var page = SelectedPage?.Page;
        if (item == null || (requirePage && page == null)) return;
        int pageIndex = page != null ? item.Document.Pages.IndexOf(page) : -1;
        try
        {
            operation(item.Batch, item.Document, page!);
        }
        catch (InvalidOperationException ex)
        {
            MessageBox.Show(ex.Message, "Retouche impossible", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        SyncBatch(item.Batch);

        // On garde la sélection sur la page retouchée (ou la plus proche)
        var current = Documents.FirstOrDefault(d => d.Document == item.Document) ?? Documents.FirstOrDefault(d => d.Batch == item.Batch);
        SelectedDocument = current;
        if (current != null && page != null)
            SelectedPage = current.Pages.FirstOrDefault(p => p.Page == page)
                           ?? current.Pages.ElementAtOrDefault(Math.Min(Math.Max(pageIndex, 0), current.Pages.Count - 1));
        StatusText = "Retouche appliquée — le PDF a été régénéré.";
    }

    private void DeletePage()
    {
        if (SelectedDocument == null || SelectedPage == null) return;
        if (MessageBox.Show("Supprimer cette page du document ?", "Supprimer la page",
                MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
        EditPage((b, d, p) => _editor.Delete(b, d, p));
    }

    private async Task CleanPageAsync()
    {
        var item = SelectedDocument;
        var page = SelectedPage?.Page;
        if (item == null || page == null) return;
        IsBusy = true;
        StatusText = "Nettoyage de la page (bords, trous, redressement)…";
        try
        {
            await Task.Run(() => _editor.Clean(item.Batch, item.Document, page));
            SyncBatch(item.Batch);
            SelectedDocument = Documents.FirstOrDefault(d => d.Document == item.Document);
            SelectedPage = SelectedDocument?.Pages.FirstOrDefault(p => p.Page == page);
            StatusText = $"Page nettoyée : {page.CleanupNote}.";
        }
        catch (InvalidOperationException ex)
        {
            MessageBox.Show(ex.Message, "Nettoyage impossible", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        finally { IsBusy = false; }
    }

    private void RestoreBatch()
    {
        var item = SelectedDocument;
        if (item == null || !_snapshots.TryGetValue(item.Batch, out var snapshot)) return;
        if (MessageBox.Show("Annuler toutes les retouches de ce lot (rotations, ordre, suppressions, découpes, nettoyages) ?",
                "Rétablir le lot d'origine", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
        try
        {
            snapshot.Restore(item.Batch, _pipeline);
        }
        catch (InvalidOperationException ex)
        {
            MessageBox.Show(ex.Message, "Rétablissement impossible", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        SyncBatch(item.Batch);
        SelectedDocument = Documents.FirstOrDefault(d => d.Batch == item.Batch);
        StatusText = "Lot rétabli dans son état d'origine.";
    }

    /// <summary>Remet dans le lot les pages retirées comme blanches (page très claire prise pour une page blanche).</summary>
    private void RestoreBlankPages()
    {
        var item = SelectedDocument;
        if (item == null) return;
        int count = item.Batch.RemovedBlankPages.Count;
        if (count == 0) return;
        if (MessageBox.Show($"{count} page(s) de ce lot ont été retirées comme blanches.\n\nLes réintégrer à leur place d'origine pour vérification ? " +
                            "Vous pourrez ensuite supprimer celles qui sont vraiment blanches.",
                "Pages blanches retirées", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
        int restored;
        try { restored = _editor.RestoreBlankPages(item.Batch); }
        catch (InvalidOperationException ex)
        {
            MessageBox.Show(ex.Message, "Réintégration impossible", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        SyncBatch(item.Batch);
        SelectedDocument = Documents.FirstOrDefault(d => d.Batch == item.Batch);
        StatusText = restored == count
            ? $"{restored} page(s) réintégrée(s) : vérifiez-les, supprimez celles qui sont vraiment blanches."
            : $"{restored} page(s) réintégrée(s) sur {count} (les autres concernent un document déjà envoyé ou un PDF importé).";
    }

    /// <summary>Aligne la liste affichée sur les documents du lot (après découpe, fusion, suppression).</summary>
    private void SyncBatch(BatchResult batch)
    {
        var existing = Documents.Where(d => d.Batch == batch).ToList();
        int insertAt = existing.Count > 0 ? Documents.IndexOf(existing[0]) : Documents.Count;
        var byDoc = existing.ToDictionary(d => d.Document);
        foreach (var it in existing) Documents.Remove(it);
        foreach (var doc in batch.Documents)
        {
            if (!byDoc.TryGetValue(doc, out var it))
                it = new DocumentItem(doc, batch, Retarget, _settings.Routing.OperatorOverride);
            else
                it.ReloadPages();
            Documents.Insert(insertAt++, it);
        }
        OnPropertyChanged(nameof(Summary));
    }

    // ---------------- Dossiers surveillés ----------------

    /// <summary>Toutes les 5 s : traite un fichier prêt (un fichier = un lot du copieur), puis l'archive.</summary>
    private async Task PollHotFoldersAsync()
    {
        if (_hotRunning || IsBusy) return;
        _hotRunning = true;
        try
        {
            foreach (var hot in _hotFolders)
            {
                List<string> files;
                try { files = await Task.Run(() => hot.FindReadyFiles()); }
                catch (Exception ex)
                {
                    StatusText = $"Dossier « {hot.Settings.Name} » inaccessible : {ex.Message}";
                    continue;
                }
                foreach (var file in files)
                {
                    if (IsBusy) return; // l'agent a lancé une numérisation : on reprendra au prochain passage
                    var profile = _settings.GetProfile(hot.Settings.Profile);
                    BatchResult? batch = null;
                    bool ok;
                    try
                    {
                        batch = await RunBatchAsync(ct => ReadFiles(new[] { file }, ct), profile,
                            $"{hot.Settings.Name} : traitement de {Path.GetFileName(file)}…", interactive: false);
                        ok = batch is { Documents.Count: > 0 };
                    }
                    catch (Exception ex)
                    {
                        StatusText = $"{hot.Settings.Name} : {Path.GetFileName(file)} non traité — {ex.Message}";
                        ok = false;
                    }
                    try { hot.Archive(file, ok); }
                    catch (Exception ex) { StatusText = $"{hot.Settings.Name} : archivage impossible — {ex.Message}"; }

                    if (ok && hot.Settings.AutoSend)
                    {
                        // Envoi automatique des seuls documents sans alerte ; les autres attendent la validation de l'agent
                        var clean = Documents.Where(d => d.Batch == batch && !d.HasWarning &&
                                                         d.Document.Status == DocumentStatus.Ready).ToList();
                        await SendDocumentsAsync(clean, interactive: false);
                    }
                }
            }
        }
        finally { _hotRunning = false; }
    }

    private void Retarget(DocumentItem item, string target)
    {
        _pipeline.Retarget(item.Document, item.Batch, target);
        OnPropertyChanged(nameof(Summary));
    }

    // ---------------- Envoi WebDAV ----------------

    private Task SendAllAsync() =>
        SendDocumentsAsync(Documents.Where(d => d.Document.Status is DocumentStatus.Ready or DocumentStatus.Failed).ToList(), interactive: true);

    private async Task SendDocumentsAsync(List<DocumentItem> toSend, bool interactive)
    {
        if (toSend.Count == 0) return;

        // Chaque agent dépose avec SES comptes : on vérifie qu'ils sont renseignés pour les destinations concernées
        var missing = _credentials.Missing(_settings, toSend.Select(d => d.Target));
        if (missing.Count > 0)
        {
            var names = string.Join(", ", missing.Select(m => _settings.Targets[m].DisplayName));
            if (!interactive)
            {
                StatusText = $"Envoi automatique impossible : identifiants manquants pour {names}.";
                return;
            }
            EditCredentials($"Identifiants manquants pour : {names}.");
            missing = _credentials.Missing(_settings, toSend.Select(d => d.Target));
            if (missing.Count > 0)
            {
                StatusText = "Envoi annulé : identifiants WebDAV non renseignés.";
                return;
            }
        }
        int flagged = toSend.Count(d => d.HasWarning);
        if (flagged > 0 && interactive)
        {
            var answer = MessageBox.Show(
                $"{flagged} document(s) comportent une alerte (par exemple pages sans page séparatrice).\n" +
                "Vérifiez leur destination avant l'envoi.\n\nEnvoyer quand même ?",
                "Confirmation d'envoi", MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if (answer != MessageBoxResult.Yes) return;
        }

        _cts = new CancellationTokenSource();
        IsBusy = true;
        int sent = 0, queued = 0;
        try
        {
            foreach (var item in toSend)
            {
                StatusText = $"Envoi de {item.FileName} vers {item.Target}…";
                item.Document.Status = DocumentStatus.Sending;
                item.Refresh();
                await Task.Run(() => _sender.SendAsync(item.Document, item.Batch, _cts.Token));
                item.Refresh();
                if (item.Document.Status == DocumentStatus.Sent) sent++; else queued++;
            }
            StatusText = queued == 0
                ? $"{sent} document(s) envoyé(s)."
                : $"{sent} envoyé(s), {queued} mis en file d'attente (serveur injoignable) — aucun document perdu.";
        }
        catch (OperationCanceledException)
        {
            StatusText = $"Envoi interrompu : {sent} document(s) envoyé(s).";
        }
        finally
        {
            foreach (var item in toSend) item.Refresh();
            PendingCount = _sender.PendingCount();
            IsBusy = false;
            _cts.Dispose();
            _cts = null;
        }
    }

    private async Task RetryOutboxAsync()
    {
        IsBusy = true;
        try
        {
            var progress = new Progress<string>(s => StatusText = s);
            var (sent, pending) = await Task.Run(() => _sender.RetryOutboxAsync(progress, CancellationToken.None));
            // Les documents encore affichés et repartis avec succès passent à « Envoyé »
            foreach (var item in Documents.Where(d => d.Document.Status == DocumentStatus.Queued))
            {
                var file = Path.Combine(_sender.OutboxFolder, item.Target, item.FileName);
                if (!File.Exists(file))
                {
                    item.Document.Status = DocumentStatus.Sent;
                    item.Document.Error = null;
                    item.Refresh();
                }
            }
            StatusText = $"Reprise : {sent} envoyé(s), {pending} toujours en attente.";
        }
        finally
        {
            PendingCount = _sender.PendingCount();
            IsBusy = false;
        }
    }

    // ---------------- Divers ----------------

    private void Clear()
    {
        int unsent = Documents.Count(d => d.Document.Status is DocumentStatus.Ready or DocumentStatus.Failed);
        if (unsent > 0 && MessageBox.Show($"{unsent} document(s) n'ont pas été envoyés et seront perdus. Vider la liste ?",
                "Confirmation", MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes)
            return;
        foreach (var d in Documents) ScanPipeline.DeleteSources(d.Document.Pages);
        foreach (var b in Documents.Select(d => d.Batch).Distinct()) ScanPipeline.DeleteSources(b.RemovedBlankPages);
        Documents.Clear();
        _snapshots.Clear();
        SelectedDocument = null;
        OnPropertyChanged(nameof(Summary));
        StatusText = "Liste vidée.";
    }

    private void OpenSelectedPdf()
    {
        var doc = SelectedDocument?.Document;
        if (doc?.Pdf == null) return;
        var dir = Path.Combine(Path.GetTempPath(), "LloydScan-apercu");
        Directory.CreateDirectory(dir);
        var path = Path.Combine(dir, doc.FileName);
        File.WriteAllBytes(path, doc.Pdf);
        Process.Start(new ProcessStartInfo(path) { UseShellExecute = true });
    }

    private static void OpenFolder(string path)
    {
        Directory.CreateDirectory(path);
        Process.Start(new ProcessStartInfo(path) { UseShellExecute = true });
    }

    public void Dispose()
    {
        _cts?.Cancel();
        _hotTimer.Stop();
        foreach (var d in Documents) ScanPipeline.DeleteSources(d.Document.Pages); // copies de travail des documents non envoyés
        foreach (var b in Documents.Select(d => d.Batch).Distinct()) ScanPipeline.DeleteSources(b.RemovedBlankPages);
        _scanner.Dispose();
        _sender.Dispose();
    }
}
