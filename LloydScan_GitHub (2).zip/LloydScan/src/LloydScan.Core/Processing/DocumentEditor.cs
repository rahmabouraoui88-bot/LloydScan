namespace LloydScan.Core.Processing;

/// <summary>
/// Retouches manuelles avant envoi : rotation, ordre des pages, suppression, découpe et fusion de documents.
/// Chaque opération régénère le(s) PDF concerné(s) et est tracée (journal d'envoi).
/// Les documents déjà envoyés ou en file d'attente ne sont plus modifiables.
/// </summary>
public sealed class DocumentEditor
{
    private readonly ScanPipeline _pipeline;

    public DocumentEditor(ScanPipeline pipeline) => _pipeline = pipeline;

    public static bool CanEdit(ScanDocument doc) => doc.Status is DocumentStatus.Ready or DocumentStatus.Failed;

    private static void EnsureEditable(ScanDocument doc)
    {
        if (!CanEdit(doc)) throw new InvalidOperationException("Ce document est déjà envoyé ou en file d'attente : il n'est plus modifiable.");
        if (doc.IsNativePdf) throw new InvalidOperationException("PDF natif conservé tel quel : les retouches de pages s'appliquent aux documents numérisés.");
    }

    private static int Position(ScanDocument doc, ProcessedPage page)
    {
        int i = doc.Pages.IndexOf(page);
        if (i < 0) throw new ArgumentException("Page absente du document.");
        return i;
    }

    /// <summary>Rotation par quart de tour (90 = sens horaire, -90 = antihoraire, 180), sans recompression.</summary>
    public void Rotate(BatchResult batch, ScanDocument doc, ProcessedPage page, int degrees)
    {
        EnsureEditable(doc);
        int pos = Position(doc, page);
        page.Rotation += degrees;
        doc.Edits.Add($"rotation p{pos + 1} {degrees:+0;-0}°");
        _pipeline.Rebuild(doc, batch);
    }

    /// <summary>Déplace une page dans le document (offset -1 = vers le début, +1 = vers la fin).</summary>
    public void Move(BatchResult batch, ScanDocument doc, ProcessedPage page, int offset)
    {
        EnsureEditable(doc);
        int pos = Position(doc, page), target = Math.Clamp(pos + offset, 0, doc.Pages.Count - 1);
        if (target == pos) return;
        // La fiche séparatrice reste la 1re page du document déposé (son QR fixe l'orientation)
        if (page.IsSeparator && pos == 0 || target == 0 && doc.Pages[0].IsSeparator)
            throw new InvalidOperationException("La fiche séparatrice reste en 1re page du document.");
        doc.Pages.RemoveAt(pos);
        doc.Pages.Insert(target, page);
        doc.Edits.Add($"page {pos + 1} → {target + 1}");
        _pipeline.Rebuild(doc, batch);
    }

    /// <summary>Supprime une page ; un document vidé disparaît du lot. Renvoie true si le document a été retiré.</summary>
    public bool Delete(BatchResult batch, ScanDocument doc, ProcessedPage page)
    {
        EnsureEditable(doc);
        int pos = Position(doc, page);
        if (page.IsSeparator && pos == 0 && doc.Pages.Count > 1)
            throw new InvalidOperationException("La fiche séparatrice est conservée dans le PDF (elle porte le QR d'orientation) : elle ne peut pas être supprimée.");
        doc.Pages.RemoveAt(pos);
        doc.Edits.Add($"suppression p{pos + 1}");
        if (doc.Pages.Count == 0)
        {
            batch.Documents.Remove(doc);
            return true;
        }
        _pipeline.Rebuild(doc, batch);
        return false;
    }

    /// <summary>
    /// Découpe : la page choisie et les suivantes forment un nouveau document (même QR, même destination),
    /// placé juste après. Utile quand une page séparatrice a été oubliée entre deux documents.
    /// </summary>
    public ScanDocument SplitBefore(BatchResult batch, ScanDocument doc, ProcessedPage page)
    {
        EnsureEditable(doc);
        int pos = Position(doc, page);
        if (pos == 0) throw new InvalidOperationException("Choisir une page autre que la première pour découper le document.");
        var created = new ScanDocument
        {
            // Numéro jamais réutilisé : le nom de fichier reste unique, même par rapport aux documents déjà envoyés
            Sequence = batch.Documents.Max(d => d.Sequence) + 1,
            QrText = doc.QrText,
            Target = doc.Target,
            RoutingReason = doc.RoutingReason + " (document découpé manuellement)"
        };
        created.Warnings.AddRange(doc.Warnings);
        created.Pages.AddRange(doc.Pages.Skip(pos));
        doc.Pages.RemoveRange(pos, doc.Pages.Count - pos);
        doc.Edits.Add($"découpe avant p{pos + 1} → document {created.Sequence}");
        created.Edits.Add($"issu de la découpe du document {doc.Sequence}");
        batch.Documents.Insert(batch.Documents.IndexOf(doc) + 1, created);
        _pipeline.Rebuild(doc, batch);
        _pipeline.Rebuild(created, batch);
        return created;
    }

    /// <summary>Fusionne le document avec le suivant du lot (même destination exigée).</summary>
    public void MergeWithNext(BatchResult batch, ScanDocument doc)
    {
        EnsureEditable(doc);
        int i = batch.Documents.IndexOf(doc);
        if (i < 0 || i == batch.Documents.Count - 1) throw new InvalidOperationException("Aucun document suivant dans ce lot.");
        var next = batch.Documents[i + 1];
        EnsureEditable(next);
        if (!string.Equals(next.Target, doc.Target, StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException($"Fusion impossible : destinations différentes ({doc.Target} / {next.Target}).");
        doc.Pages.AddRange(next.Pages);
        foreach (var w in next.Warnings.Where(w => !doc.Warnings.Contains(w))) doc.Warnings.Add(w);
        doc.Edits.Add($"fusion avec le document {next.Sequence}");
        batch.Documents.RemoveAt(i + 1);
        _pipeline.Rebuild(doc, batch);
    }

    /// <summary>Nettoyage manuel complet d'une page (bords, trous, redressement) depuis sa copie source.</summary>
    /// <summary>
    /// Réintègre les pages retirées comme blanches (page très claire prise à tort pour une page blanche) :
    /// chaque page reprend sa place d'origine, juste après la page numérisée avant elle, puis est optimisée.
    /// Renvoie le nombre de pages réintégrées ; l'agent supprime ensuite celles qui étaient vraiment blanches.
    /// </summary>
    public int RestoreBlankPages(BatchResult batch)
    {
        int restored = 0;
        foreach (var page in batch.RemovedBlankPages.OrderBy(p => p.Index).ToList())
        {
            // Document et position : après la dernière page conservée qui la précédait dans le lot
            ScanDocument? target = null; int insertAt = 0, bestIndex = -1;
            foreach (var d in batch.Documents)
                for (int i = 0; i < d.Pages.Count; i++)
                    if (d.Pages[i].Index < page.Index && d.Pages[i].Index > bestIndex)
                    { bestIndex = d.Pages[i].Index; target = d; insertAt = i + 1; }
            if (target == null)
            {
                target = batch.Documents.FirstOrDefault();
                insertAt = target?.Pages.TakeWhile(p => p.IsSeparator).Count() ?? 0;
            }
            if (target == null || !CanEdit(target) || target.IsNativePdf) continue;
            _pipeline.Reprocess(page, (page.Profile ?? new Configuration.ScanProfile()).Cleanup);
            target.Pages.Insert(insertAt, page);
            target.Edits.Add($"page blanche réintégrée p{insertAt + 1}");
            batch.RemovedBlankPages.Remove(page);
            batch.BlankPagesRemoved--;
            _pipeline.Rebuild(target, batch);
            restored++;
        }
        return restored;
    }

    public void Clean(BatchResult batch, ScanDocument doc, ProcessedPage page)
    {
        EnsureEditable(doc);
        int pos = Position(doc, page);
        _pipeline.Reprocess(page, Configuration.CleanupSettings.Full);
        doc.Edits.Add($"nettoyage p{pos + 1}");
        _pipeline.Rebuild(doc, batch);
    }
}

/// <summary>Photographie d'un lot juste après numérisation, pour « Rétablir le lot d'origine ».</summary>
public sealed class BatchSnapshot
{
    private sealed record PageState(ProcessedPage Page, Pdf.OptimizedPage? Optimized, int Rotation, Imaging.RasterImage Thumbnail, string Note);
    private sealed record DocState(ScanDocument Doc, string Target, string Reason, List<string> Warnings, List<PageState> Pages);

    private readonly List<DocState> _docs;
    private readonly List<ProcessedPage> _blank;

    private BatchSnapshot(List<DocState> docs, List<ProcessedPage> blank) { _docs = docs; _blank = blank; }

    public static BatchSnapshot Capture(BatchResult batch) => new(batch.Documents.Select(d => new DocState(
        d, d.Target, d.RoutingReason, d.Warnings.ToList(),
        d.Pages.Select(p => new PageState(p, p.Optimized, p.Rotation, p.Thumbnail, p.CleanupNote)).ToList())).ToList(),
        batch.RemovedBlankPages.ToList());

    /// <summary>Restaure le lot (impossible si un de ses documents est déjà parti).</summary>
    public void Restore(BatchResult batch, ScanPipeline pipeline)
    {
        if (batch.Documents.Any(d => !DocumentEditor.CanEdit(d)))
            throw new InvalidOperationException("Un document de ce lot est déjà envoyé : le lot ne peut plus être rétabli.");
        batch.Documents.Clear();
        batch.RemovedBlankPages.Clear(); batch.RemovedBlankPages.AddRange(_blank);
        batch.BlankPagesRemoved = _blank.Count;
        foreach (var ds in _docs)
        {
            var doc = ds.Doc;
            doc.Target = ds.Target;
            doc.RoutingReason = ds.Reason;
            doc.Warnings.Clear(); doc.Warnings.AddRange(ds.Warnings);
            doc.Edits.Clear();
            doc.Pages.Clear();
            foreach (var ps in ds.Pages)
            {
                ps.Page.Optimized = ps.Optimized;
                ps.Page.Rotation = ps.Rotation;
                ps.Page.Thumbnail = ps.Thumbnail;
                ps.Page.CleanupNote = ps.Note;
                doc.Pages.Add(ps.Page);
            }
            batch.Documents.Add(doc);
            pipeline.Rebuild(doc, batch);
        }
    }
}
