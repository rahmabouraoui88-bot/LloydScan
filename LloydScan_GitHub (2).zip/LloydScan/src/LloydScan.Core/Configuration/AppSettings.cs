using System.Text.Json;
using System.Text.Json.Serialization;

namespace LloydScan.Core.Configuration;

/// <summary>Configuration complète de l'application (fichier appsettings.json).</summary>
public sealed class AppSettings
{
    /// <summary>Profils de numérisation proposés à l'opérateur.</summary>
    public List<ScanProfile> Profiles { get; set; } = new();

    /// <summary>Nom du profil sélectionné au démarrage.</summary>
    public string? DefaultProfile { get; set; }

    /// <summary>Qui choisit le profil : profils ouverts aux agents, profils réservés, affectation par poste ou par agent.</summary>
    public ProfilePolicy ProfilePolicy { get; set; } = new();

    public SeparatorSettings Separator { get; set; } = new();
    public RoutingSettings Routing { get; set; } = new();

    /// <summary>Destinations WebDAV, indexées par nom (ex. "Vie", "Lloyd").</summary>
    public Dictionary<string, WebDavTarget> Targets { get; set; } = new(StringComparer.OrdinalIgnoreCase);

    public NamingSettings Naming { get; set; } = new();
    public StorageSettings Storage { get; set; } = new();

    /// <summary>Reconnaissance de texte (PDF interrogeable).</summary>
    public OcrSettings Ocr { get; set; } = new();

    /// <summary>Traitement des PDF importés (natifs ou scannés).</summary>
    public PdfSettings Pdf { get; set; } = new();

    /// <summary>Dossiers surveillés : copieurs multifonctions réseau en « scan vers dossier ».</summary>
    public List<HotFolderSettings> HotFolders { get; set; } = new();

    /// <summary>Nombre de pages traitées en parallèle (0 = automatique).</summary>
    public int MaxParallelPages { get; set; }

    public static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNameCaseInsensitive = true,
        ReadCommentHandling = JsonCommentHandling.Skip,
        AllowTrailingCommas = true,
        WriteIndented = true,
        Converters = { new JsonStringEnumConverter() }
    };

    public static AppSettings Load(string path)
    {
        var json = File.ReadAllText(path);
        var settings = JsonSerializer.Deserialize<AppSettings>(json, JsonOptions)
                       ?? throw new InvalidDataException("Fichier de configuration vide.");
        settings.Validate();
        return settings;
    }

    /// <summary>Contrôle de cohérence : lève une exception explicite si la configuration est inutilisable.</summary>
    public void Validate()
    {
        if (Profiles.Count == 0)
            throw new InvalidDataException("Aucun profil de numérisation n'est défini.");
        foreach (var name in new[] { Routing.VieTarget, Routing.DefaultTarget, Routing.NoSeparatorTarget })
        {
            if (!Targets.ContainsKey(name))
                throw new InvalidDataException($"La destination « {name} » est utilisée par le routage mais absente de Targets.");
        }
        foreach (var (name, t) in Targets)
        {
            if (!Uri.TryCreate(t.Url, UriKind.Absolute, out var u) || (u.Scheme != "https" && u.Scheme != "http"))
                throw new InvalidDataException($"URL WebDAV invalide pour « {name} » : {t.Url}");
            if (t.Authentication == WebDavAuthentication.Service && string.IsNullOrWhiteSpace(t.Username))
                throw new InvalidDataException($"Destination « {name} » en mode Service sans Username.");
            if (string.IsNullOrWhiteSpace(t.DisplayName)) t.DisplayName = name;
        }
        foreach (var name in ProfilePolicy.AgentProfiles.Concat(ProfilePolicy.Assignments.Select(a => a.Profile)))
            if (!Profiles.Any(p => string.Equals(p.Name, name, StringComparison.OrdinalIgnoreCase)))
                throw new InvalidDataException($"ProfilePolicy : le profil « {name} » n'existe pas dans Profiles.");
    }

    /// <summary>
    /// Profil de départ de ce poste et de cet agent : la première affectation qui correspond, sinon DefaultProfile.
    /// </summary>
    public ScanProfile ResolveProfile(string computer, string user)
    {
        var hit = ProfilePolicy.Assignments.FirstOrDefault(a => a.Matches(computer, user));
        return GetProfile(hit?.Profile ?? DefaultProfile);
    }

    /// <summary>
    /// Profils que l'agent peut choisir. Si le choix est fermé, seul le profil affecté est proposé.
    /// Un profil affecté par l'administrateur est toujours proposé, même s'il est réservé.
    /// </summary>
    public IReadOnlyList<ScanProfile> ProfilesFor(string computer, string user)
    {
        var assigned = ResolveProfile(computer, user);
        if (!ProfilePolicy.AgentCanChooseProfile) return new[] { assigned };
        var open = ProfilePolicy.AgentProfiles.Count == 0
            ? Profiles
            : Profiles.Where(p => ProfilePolicy.AgentProfiles.Contains(p.Name, StringComparer.OrdinalIgnoreCase)).ToList();
        return open.Contains(assigned) ? open : open.Prepend(assigned).ToList();
    }

    public ScanProfile GetProfile(string? name) =>
        Profiles.FirstOrDefault(p => string.Equals(p.Name, name, StringComparison.OrdinalIgnoreCase))
        ?? Profiles.FirstOrDefault(p => string.Equals(p.Name, DefaultProfile, StringComparison.OrdinalIgnoreCase))
        ?? Profiles[0];
}

/// <summary>Règles de choix du profil, définies par l'administrateur LLOYD (fichier protégé).</summary>
public sealed class ProfilePolicy
{
    /// <summary>L'agent peut changer de profil dans la liste. Faux : le profil affecté au poste est imposé.</summary>
    public bool AgentCanChooseProfile { get; set; } = true;
    /// <summary>Profils que l'agent peut choisir (vide = tous). Les autres (ex. « Haute fidélité ») sont réservés à l'affectation.</summary>
    public List<string> AgentProfiles { get; set; } = new();
    /// <summary>Affectations par poste et/ou par agent (jokers * et ?), la première qui correspond s'applique.</summary>
    public List<ProfileAssignment> Assignments { get; set; } = new();
}

public sealed class ProfileAssignment
{
    /// <summary>Nom du poste Windows (ex. "LLOYD-JUR-*"), vide = tous les postes.</summary>
    public string? Computer { get; set; }
    /// <summary>Compte Windows de l'agent (ex. "rbouraoui"), vide = tous les agents.</summary>
    public string? User { get; set; }
    public string Profile { get; set; } = "";

    public bool Matches(string computer, string user) => Glob(Computer, computer) && Glob(User, user);

    private static bool Glob(string? pattern, string value) =>
        string.IsNullOrWhiteSpace(pattern) ||
        System.Text.RegularExpressions.Regex.IsMatch(value,
            "^" + System.Text.RegularExpressions.Regex.Escape(pattern.Trim()).Replace("\\*", ".*").Replace("\\?", ".") + "$",
            System.Text.RegularExpressions.RegexOptions.IgnoreCase);
}

/// <summary>Profil de numérisation : réglages scanner + stratégie d'optimisation du PDF.</summary>
public sealed class ScanProfile
{
    public string Name { get; set; } = "Standard";
    public string? Description { get; set; }

    // --- Réglages envoyés au pilote TWAIN ---
    public int Resolution { get; set; } = 300;
    public ScanColorMode ColorMode { get; set; } = ScanColorMode.Color;
    public bool Duplex { get; set; } = true;
    public bool UseFeeder { get; set; } = true;
    public bool AutoDeskew { get; set; } = true;
    public bool AutoBorderDetection { get; set; } = true;
    // L'interface du pilote TWAIN n'est jamais affichée : l'agent ne peut pas modifier les réglages du profil.

    // --- Pages blanches ---
    public bool RemoveBlankPages { get; set; } = true;
    /// <summary>Part de pixels « encre » en dessous de laquelle une page est considérée blanche (0,0003 = 0,03 %).</summary>
    public double BlankInkRatio { get; set; } = 0.0003;

    public OutputSettings Output { get; set; } = new();

    /// <summary>Nettoyage automatique des pages avant optimisation.</summary>
    public CleanupSettings Cleanup { get; set; } = new();

    /// <summary>
    /// Conserve une copie de chaque page (dossier de travail local, supprimée après envoi)
    /// pour permettre le nettoyage manuel d'une page dans l'écran de contrôle.
    /// </summary>
    public bool KeepSourceForEditing { get; set; } = true;

    /// <summary>OCR pour ce profil (si activé globalement). Désactivé pour les photos par exemple.</summary>
    public bool UseOcr { get; set; } = true;

    public override string ToString() => Name;
}

public sealed class CleanupSettings
{
    /// <summary>Efface le fond sombre du scanner visible sur les bords.</summary>
    public bool RemoveBorders { get; set; } = true;
    /// <summary>Profondeur maximale effacée depuis chaque bord (mm).</summary>
    public double BorderMaxMm { get; set; } = 20;
    /// <summary>Efface les trous de perforation dans les marges.</summary>
    public bool RemovePunchHoles { get; set; } = true;
    /// <summary>Redressement logiciel (complète le redressement du pilote).</summary>
    public bool Deskew { get; set; } = true;
    public double DeskewMaxDegrees { get; set; } = 5;

    /// <summary>Réglage appliqué par le bouton « Nettoyer » de l'écran de contrôle : tout activé.</summary>
    public static CleanupSettings Full => new() { RemoveBorders = true, RemovePunchHoles = true, Deskew = true, BorderMaxMm = 25 };
}

public enum ScanColorMode { Color, Gray, BlackWhite }

/// <summary>
/// Auto : MRC, en niveaux de gris si la page n'a pas de couleur significative.
/// Mrc : MRC en conservant toujours la couleur.
/// Color / Gray : JPEG simple (photos). BlackWhite : 1 bit (texte pur).
/// </summary>
public enum OutputMode { Auto, Mrc, Color, Gray, BlackWhite }

public enum MaskCompression { CcittG4, Flate }

public sealed class OutputSettings
{
    public OutputMode Mode { get; set; } = OutputMode.Auto;

    // Modes Color / Gray
    public int ImageDpi { get; set; } = 200;
    public int JpegQuality { get; set; } = 70;

    // Mode BlackWhite
    public int BlackWhiteDpi { get; set; } = 300;

    // Modes Auto / Mrc
    /// <summary>Résolution de la couche texte (masque 1 bit) : c'est elle qui donne la netteté.</summary>
    public int MaskDpi { get; set; } = 300;
    /// <summary>Résolution du fond (papier, logos, tampons pâles).</summary>
    public int BackgroundDpi { get; set; } = 100;
    public int BackgroundQuality { get; set; } = 45;
    /// <summary>Résolution de la couleur du texte (encre bleue, tampons) quand la page est en couleur.</summary>
    public int ForegroundDpi { get; set; } = 100;
    public int ForegroundQuality { get; set; } = 50;

    /// <summary>Part minimale de pixels colorés pour garder la couleur en mode Auto (0,001 = 0,1 %).</summary>
    public double ColorDetectionRatio { get; set; } = 0.001;

    /// <summary>
    /// Mode Auto : part de la page occupée par des photos au-delà de laquelle la page passe en JPEG
    /// (ImageDpi / JpegQuality). 0 = désactivé.
    /// </summary>
    public double PhotoDetectionRatio { get; set; } = 0.15;

    /// <summary>Sensibilité du seuillage local (0,10 à 0,25). Plus haut = traits plus fins.</summary>
    public double ThresholdSensitivity { get; set; } = 0.15;
    /// <summary>
    /// Rehausse l'écriture pâle (fax délavé, crayon, encre claire, photocopie faible) : elle est captée dans la
    /// couche texte et restituée foncée, au lieu de rester aussi claire que l'original.
    /// </summary>
    public bool EnhanceFaintText { get; set; } = true;
    /// <summary>Teinte maximale du texte restitué quand le rehaussement est actif (0 = noir, 255 = blanc).</summary>
    public int MaxTextTone { get; set; } = 70;

    public bool Despeckle { get; set; } = true;
    public MaskCompression MaskCompression { get; set; } = MaskCompression.CcittG4;
}

public sealed class SeparatorSettings
{
    /// <summary>
    /// Expression régulière que doit respecter le contenu du QR pour que la page soit une page séparatrice.
    /// Vide = toute page portant un QR est une page séparatrice (déconseillé si des documents ont leur propre QR).
    /// </summary>
    public string Pattern { get; set; } = "";

    /// <summary>
    /// Retire la page séparatrice du PDF final. Par défaut false : la fiche séparatrice reste la 1re page
    /// du document déposé (son QR sert aussi à l'orientation du dépôt côté ELISE).
    /// </summary>
    public bool RemoveSeparatorPages { get; set; }

    /// <summary>Résolution de travail pour la lecture du QR (150 dpi suffit pour un QR de 2 cm et plus).</summary>
    public int QrDecodeDpi { get; set; } = 150;
}

public enum KeywordMatchMode { Contains, WholeWord, Regex }

public sealed class RoutingSettings
{
    /// <summary>Mot recherché dans le QR de la page séparatrice.</summary>
    public string VieKeyword { get; set; } = "VIE";
    public KeywordMatchMode MatchMode { get; set; } = KeywordMatchMode.Contains;
    public bool IgnoreCase { get; set; } = true;

    /// <summary>Destination si le QR contient le mot-clé.</summary>
    public string VieTarget { get; set; } = "Vie";
    /// <summary>Destination dans tous les autres cas.</summary>
    public string DefaultTarget { get; set; } = "Lloyd";
    /// <summary>Destination des pages scannées avant toute page séparatrice (signalées en alerte).</summary>
    public string NoSeparatorTarget { get; set; } = "Lloyd";

    /// <summary>Ce que l'agent peut corriger dans la colonne Destination.</summary>
    public OperatorOverride OperatorOverride { get; set; } = OperatorOverride.OnlyWithoutSeparator;
}

/// <summary>
/// Never : la destination est toujours celle de la règle QR.
/// OnlyWithoutSeparator : modifiable uniquement pour les pages sans page séparatrice (cas d'alerte).
/// Always : toujours modifiable avant envoi.
/// </summary>
public enum OperatorOverride { Never, OnlyWithoutSeparator, Always }

/// <summary>
/// Agent : chaque agent saisit son propre compte (stocké chiffré dans son profil Windows).
/// Windows : authentification intégrée (Kerberos/NTLM) avec la session de l'agent.
/// Service : compte technique commun défini par l'administrateur.
/// </summary>
public enum WebDavAuthentication { Agent, Windows, Service }

public sealed class WebDavTarget
{
    /// <summary>Libellé affiché aux agents, ex. « ELISE Lloyd », « Lloyd Vie ».</summary>
    public string DisplayName { get; set; } = "";
    /// <summary>URL racine WebDAV, ex. https://elise.lloyd.local/webdav/numerisation/</summary>
    public string Url { get; set; } = "";
    public WebDavAuthentication Authentication { get; set; } = WebDavAuthentication.Agent;
    /// <summary>Mode Service uniquement : compte technique.</summary>
    public string? Username { get; set; }
    /// <summary>Mode Service uniquement : mot de passe chiffré par DPAPI (préfixe "dpapi:").</summary>
    public string? Password { get; set; }
    /// <summary>Sous-dossier distant. Variables : {date:format}, {target}, {qr} (ex. casier ELISE), {user}, {machine}, {batch}.</summary>
    public string FolderPattern { get; set; } = "{date:yyyy}/{date:MM}/{date:dd}";
    public int TimeoutSeconds { get; set; } = 120;
    public int Retries { get; set; } = 3;
    public bool VerifyAfterUpload { get; set; } = true;
}

/// <summary>
/// Dossier alimenté par un copieur ou un scanner réseau (« scan vers dossier »).
/// Chaque fichier déposé (PDF, TIFF multipage, JPEG, PNG) est traité comme un lot : découpe QR, optimisation, routage.
/// </summary>
public sealed class HotFolderSettings
{
    public string Name { get; set; } = "Copieur";
    /// <summary>Chemin local ou réseau ; variables d'environnement acceptées (ex. \\srv\scan\%USERNAME%).</summary>
    public string Path { get; set; } = "";
    /// <summary>Profil d'optimisation appliqué (le réglage de numérisation reste celui du copieur).</summary>
    public string? Profile { get; set; }
    /// <summary>Délai sans modification avant de considérer un fichier comme complet.</summary>
    public int SettleSeconds { get; set; } = 5;
    /// <summary>Envoi automatique des documents sans alerte (sinon validation par l'agent).</summary>
    public bool AutoSend { get; set; }

    public string ResolvePath() => Environment.ExpandEnvironmentVariables(Path);
}

public sealed class OcrSettings
{
    /// <summary>Ajoute une couche texte invisible aux PDF numérisés (recherche, copier-coller, indexation GED).</summary>
    public bool Enabled { get; set; } = true;
    /// <summary>Langues Tesseract : « fra+ara » = français et arabe.</summary>
    public string Languages { get; set; } = "fra+ara";
    /// <summary>Chemin de tesseract.exe (relatif au dossier de l'application) ou commande du PATH.</summary>
    public string TesseractPath { get; set; } = "tools\\tesseract\\tesseract.exe";
    /// <summary>Dossier des fichiers de langue (*.traineddata) ; vide = celui de Tesseract.</summary>
    public string? TessdataPath { get; set; } = "tools\\tesseract\\tessdata";
    /// <summary>Mots reconnus avec une confiance inférieure ignorés (0-100).</summary>
    public double MinConfidence { get; set; } = 30;

    public string ResolveTesseractPath() => PdfSettings.ResolveTool(TesseractPath);
    public string? ResolveTessdataPath() => string.IsNullOrWhiteSpace(TessdataPath) ? null : PdfSettings.ResolveTool(TessdataPath);
}

public enum NativePdfMode
{
    /// <summary>PDF natif conservé et optimisé sans perte (texte sélectionnable, rendu identique).</summary>
    Optimize,
    /// <summary>PDF natif converti en images puis compressé comme un scan (texte non sélectionnable).</summary>
    Rasterize
}

public sealed class PdfSettings
{
    public NativePdfMode NativePdfMode { get; set; } = NativePdfMode.Optimize;
    /// <summary>Chemin de qpdf.exe (relatif au dossier de l'application).</summary>
    public string QpdfPath { get; set; } = "tools\\qpdf\\qpdf.exe";

    /// <summary>Produit des PDF/A-2b (archivage à long terme, exigence ENF-06) pour les documents numérisés.</summary>
    public bool PdfA { get; set; } = true;

    public string ResolveQpdfPath() => ResolveTool(QpdfPath);

    /// <summary>Chemin d'outil : commande du PATH, chemin absolu, ou relatif au dossier de l'application.</summary>
    public static string ResolveTool(string path)
    {
        var p = path.Replace('\\', Path.DirectorySeparatorChar);
        if (!p.Contains(Path.DirectorySeparatorChar)) return p;
        return Path.IsPathRooted(p) ? p : Path.Combine(AppContext.BaseDirectory, p);
    }
}

public sealed class NamingSettings
{
    /// <summary>Variables : {date:format}, {target}, {qr}, {seq:000}, {pages}, {batch}, {user}, {machine}.</summary>
    public string FilePattern { get; set; } = "{date:yyyyMMdd-HHmmss}_{target}_{qr}_{seq:000}";
    public int MaxQrLength { get; set; } = 60;
}

public sealed class StorageSettings
{
    /// <summary>Dossier de travail local (journal, file d'attente). Les variables d'environnement sont développées.</summary>
    public string WorkFolder { get; set; } = "%LOCALAPPDATA%\\LloydScan";
    /// <summary>Conserve une copie locale de chaque PDF envoyé (dossier Archive).</summary>
    public bool KeepLocalCopy { get; set; }

    public string ResolveWorkFolder()
    {
        var p = Environment.ExpandEnvironmentVariables(WorkFolder);
        if (p.Contains('%')) // variable inconnue (ex. hors Windows)
            p = Path.Combine(Path.GetTempPath(), "LloydScan");
        Directory.CreateDirectory(p);
        return p;
    }
}
