using System.IO;
using System.Windows;
using System.Windows.Threading;
using LloydScan.App.Services;
using LloydScan.App.ViewModels;
using LloydScan.Core.Configuration;

namespace LloydScan.App;

public partial class App : Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        DispatcherUnhandledException += OnUnhandledException;

        // Outil d'administration : LloydScan.exe --protect "motdepasse" → valeur chiffrée à coller dans appsettings.json
        if (e.Args.Length == 2 && e.Args[0] == "--protect")
        {
            var protectedValue = PasswordProtector.Protect(e.Args[1]);
            Clipboard.SetText(protectedValue);
            MessageBox.Show($"Valeur chiffrée (copiée dans le presse-papiers) :\n\n{protectedValue}\n\n" +
                            "À coller dans « Password » de appsettings.json. Valable uniquement sur ce poste.",
                "LloydScan — chiffrement du mot de passe", MessageBoxButton.OK, MessageBoxImage.Information);
            Shutdown();
            return;
        }

        AppSettings settings;
        var path = Path.Combine(AppContext.BaseDirectory, "appsettings.json");
        try
        {
            settings = AppSettings.Load(path);
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Configuration invalide ({path}) :\n\n{ex.Message}", "LloydScan",
                MessageBoxButton.OK, MessageBoxImage.Error);
            Shutdown(1);
            return;
        }

        // Verrouillage : les agents ne doivent pas pouvoir modifier la configuration (profils, optimisation, routage)
        string? configWarning = null;
        if (ConfigGuard.IsWritableByCurrentUser(path))
        {
#if DEBUG
            configWarning = "Mode développement : la configuration est modifiable. En production, installer dans C:\\Program Files\\LloydScan.";
#else
            MessageBox.Show("Installation non conforme : les paramètres de numérisation sont modifiables par votre compte.\n\n" +
                            "L'application doit être installée par l'administrateur dans un dossier protégé " +
                            "(ex. C:\\Program Files\\LloydScan). Contactez le support informatique.",
                "LloydScan", MessageBoxButton.OK, MessageBoxImage.Stop);
            Shutdown(2);
            return;
#endif
        }

        var window = new MainWindow { DataContext = new MainViewModel(settings, configWarning) };
        MainWindow = window;
        window.Show();
    }

    private void OnUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
    {
        try
        {
            var dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "LloydScan");
            Directory.CreateDirectory(dir);
            File.AppendAllText(Path.Combine(dir, "erreurs.log"), $"{DateTime.Now:O} {e.Exception}{Environment.NewLine}");
        }
        catch { /* journalisation best effort */ }
        MessageBox.Show(e.Exception.Message, "LloydScan — erreur inattendue", MessageBoxButton.OK, MessageBoxImage.Error);
        e.Handled = true;
    }
}
