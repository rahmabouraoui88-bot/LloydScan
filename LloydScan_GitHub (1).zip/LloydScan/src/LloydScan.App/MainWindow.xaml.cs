using System.ComponentModel;
using System.Windows;
using System.Windows.Interop;
using LloydScan.App.ViewModels;

namespace LloydScan.App;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
        SourceInitialized += (_, _) =>
        {
            if (DataContext is MainViewModel vm) vm.WindowHandle = new WindowInteropHelper(this).Handle;
        };
        Loaded += (_, _) => (DataContext as MainViewModel)?.Initialize();
    }

    protected override void OnClosing(CancelEventArgs e)
    {
        if (DataContext is MainViewModel vm)
        {
            if (vm.IsBusy &&
                MessageBox.Show("Un traitement est en cours. Quitter quand même ?", "LloydScan",
                    MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes)
            {
                e.Cancel = true;
                return;
            }
            vm.Dispose();
        }
        base.OnClosing(e);
    }
}
