using System.Globalization;
using System.IO.Compression;
using System.Security.Cryptography;
using System.Text;

namespace LloydScan.Core.Pdf;

/// <summary>
/// Écrivain PDF minimal dédié aux documents numérisés : les images déjà compressées
/// sont insérées sans recompression (pas de perte supplémentaire, écriture très rapide).
/// </summary>
public static class PdfDocumentWriter
{
    private static readonly CultureInfo Inv = CultureInfo.InvariantCulture;

    public static byte[] Write(IReadOnlyList<OptimizedPage> pages, PdfMetadata meta)
    {
        if (pages.Count == 0) throw new ArgumentException("Un PDF doit contenir au moins une page.", nameof(pages));

        // 1. Attribution des numéros d'objets
        int next = 1;
        int catalogId = next++, pagesId = next++, infoId = next++;
        var pageIds = new int[pages.Count];
        var contentIds = new int[pages.Count];
        var imageIds = new List<(int imageId, int maskId)>[pages.Count];
        for (int i = 0; i < pages.Count; i++)
        {
            pageIds[i] = next++;
            contentIds[i] = next++;
            imageIds[i] = new();
            foreach (var layer in pages[i].Layers)
            {
                int img = next++;
                int mask = layer.Mask != null ? next++ : 0;
                imageIds[i].Add((img, mask));
            }
        }
        // Police invisible pour la couche texte OCR (une seule pour tout le document)
        bool hasText = pages.Any(p => p.Text.Count > 0);
        int fontId = 0, cidFontId = 0, fontDescId = 0, toUnicodeId = 0;
        if (hasText) { fontId = next++; cidFontId = next++; fontDescId = next++; toUnicodeId = next++; }
        // PDF/A : métadonnées XMP + profil de couleur
        int metadataId = 0, iccId = 0;
        if (meta.PdfA) { metadataId = next++; iccId = next++; }
        int objectCount = next - 1;

        var w = new PdfOut();
        var offsets = new long[objectCount + 1];
        w.Raw("%PDF-1.7\n");
        w.Bytes(new byte[] { (byte)'%', 0xE2, 0xE3, 0xCF, 0xD3, (byte)'\n' });

        void Begin(int id) { offsets[id] = w.Position; w.Raw($"{id} 0 obj\n"); }
        void End() => w.Raw("endobj\n");

        // Catalogue
        Begin(catalogId);
        w.Raw($"<< /Type /Catalog /Pages {pagesId} 0 R ");
        if (meta.PdfA)
            w.Raw($"/Metadata {metadataId} 0 R /OutputIntents [<< /Type /OutputIntent /S /GTS_PDFA1 " +
                  $"/OutputConditionIdentifier (sRGB IEC61966-2.1) /Info (sRGB IEC61966-2.1) /DestOutputProfile {iccId} 0 R >>] ");
        w.Raw(">>\n");
        End();

        // Arbre des pages
        Begin(pagesId);
        w.Raw("<< /Type /Pages /Kids [");
        foreach (var id in pageIds) w.Raw($"{id} 0 R ");
        w.Raw($"] /Count {pages.Count} >>\n");
        End();

        // Métadonnées
        Begin(infoId);
        w.Raw("<< ");
        void Entry(string key, string? value) { if (!string.IsNullOrEmpty(value)) w.Raw($"/{key} {PdfString(value)} "); }
        Entry("Title", meta.Title);
        Entry("Author", meta.Author);
        Entry("Subject", meta.Subject);
        Entry("Keywords", meta.Keywords);
        Entry("Creator", meta.Creator);
        Entry("Producer", "LloydScan PDF writer");
        Entry("CreationDate", PdfDate(meta.CreationDate));
        if (meta.PdfA) Entry("ModDate", PdfDate(meta.CreationDate));
        foreach (var (k, v) in meta.Custom) Entry(SanitizeName(k), v);
        w.Raw(">>\n");
        End();

        for (int i = 0; i < pages.Count; i++)
        {
            var page = pages[i];
            string wpt = Num(page.WidthPt), hpt = Num(page.HeightPt);

            Begin(pageIds[i]);
            w.Raw($"<< /Type /Page /Parent {pagesId} 0 R /MediaBox [0 0 {wpt} {hpt}] ");
            int rotate = ((page.Rotation % 360) + 360) % 360;
            if (rotate != 0) w.Raw($"/Rotate {rotate} ");
            w.Raw("/Resources << /ProcSet [/PDF /ImageB /ImageC] /XObject << ");
            for (int l = 0; l < page.Layers.Count; l++) w.Raw($"/Im{l} {imageIds[i][l].imageId} 0 R ");
            w.Raw(">> ");
            if (page.Text.Count > 0) w.Raw($"/Font << /F1 {fontId} 0 R >> ");
            w.Raw($">> /Contents {contentIds[i]} 0 R >>\n");
            End();

            // Flux de contenu : chaque couche couvre toute la page
            var cs = new StringBuilder();
            for (int l = 0; l < page.Layers.Count; l++)
            {
                var layer = page.Layers[l];
                cs.Append("q ");
                if (layer.Image.Kind == PdfImageKind.StencilMask)
                    cs.Append(Num(layer.FillColor.R)).Append(' ').Append(Num(layer.FillColor.G)).Append(' ')
                      .Append(Num(layer.FillColor.B)).Append(" rg ");
                cs.Append(wpt).Append(" 0 0 ").Append(hpt).Append(" 0 0 cm /Im").Append(l).Append(" Do Q\n");
            }
            if (page.Text.Count > 0) AppendInvisibleText(cs, page);
            var content = Encoding.ASCII.GetBytes(cs.ToString());
            bool deflate = content.Length > 2048;
            if (deflate) content = Deflate(content);
            Begin(contentIds[i]);
            w.Raw($"<< /Length {content.Length} {(deflate ? "/Filter /FlateDecode " : "")}>>\nstream\n");
            w.Bytes(content);
            w.Raw("\nendstream\n");
            End();

            for (int l = 0; l < page.Layers.Count; l++)
            {
                var (imgId, maskId) = imageIds[i][l];
                WriteImage(w, offsets, imgId, page.Layers[l].Image, maskId);
                if (maskId != 0) WriteImage(w, offsets, maskId, page.Layers[l].Mask!, 0);
            }
        }

        if (hasText) WriteTextFont(w, offsets, fontId, cidFontId, fontDescId, toUnicodeId);
        if (meta.PdfA) WritePdfA(w, offsets, metadataId, iccId, meta);

        // Table de références croisées
        long xref = w.Position;
        w.Raw($"xref\n0 {objectCount + 1}\n0000000000 65535 f \n");
        for (int id = 1; id <= objectCount; id++) w.Raw($"{offsets[id]:D10} 00000 n \n");
        var idHex = Convert.ToHexString(RandomNumberGenerator.GetBytes(16));
        w.Raw($"trailer\n<< /Size {objectCount + 1} /Root {catalogId} 0 R /Info {infoId} 0 R /ID [<{idHex}> <{idHex}>] >>\n");
        w.Raw($"startxref\n{xref}\n%%EOF\n");
        return w.ToArray();
    }

    private static void WriteImage(PdfOut w, long[] offsets, int id, PdfImage img, int maskId)
    {
        offsets[id] = w.Position;
        w.Raw($"{id} 0 obj\n<< /Type /XObject /Subtype /Image /Width {img.Width} /Height {img.Height} ");
        switch (img.Kind)
        {
            case PdfImageKind.Jpeg:
                w.Raw($"/ColorSpace /{(img.Components == 3 ? "DeviceRGB" : "DeviceGray")} /BitsPerComponent 8 ");
                break;
            case PdfImageKind.Bilevel:
                // bit 1 = encre → noir
                w.Raw("/ColorSpace /DeviceGray /BitsPerComponent 1 /Decode [1 0] ");
                break;
            case PdfImageKind.StencilMask:
                // bit 1 = encre → zone peinte
                w.Raw("/ImageMask true /BitsPerComponent 1 /Decode [1 0] ");
                break;
        }
        w.Raw($"/Filter /{img.Filter} ");
        if (img.Filter == "CCITTFaxDecode")
            w.Raw($"/DecodeParms << /K -1 /Columns {img.Width} /Rows {img.Height} /BlackIs1 true >> ");
        if (maskId != 0) w.Raw($"/Mask {maskId} 0 R ");
        w.Raw($"/Length {img.Data.Length} >>\nstream\n");
        w.Bytes(img.Data);
        w.Raw("\nendstream\nendobj\n");
    }

    /// <summary>
    /// Couche texte OCR : chaque mot est écrit en mode invisible (3 Tr) à sa position, étiré (Tz) à la largeur
    /// du mot sur l'image. Le texte se sélectionne, se recherche et s'indexe ; l'apparence de la page ne change pas.
    /// </summary>
    private static void AppendInvisibleText(StringBuilder cs, OptimizedPage page)
    {
        cs.Append("BT 3 Tr\n");
        foreach (var word in page.Text)
        {
            var units = word.Text.Where(c => !char.IsSurrogate(c) && !char.IsControl(c)).ToArray();
            if (units.Length == 0) continue;
            // Le PDF stocke le texte dans l'ordre d'affichage (de gauche à droite) :
            // un mot arabe, reconnu dans l'ordre de lecture, est donc écrit inversé.
            if (units.Count(IsRightToLeft) * 2 > units.Length) Array.Reverse(units);
            double size = Math.Max(1, word.Height);
            double natural = units.Length * 0.5 * size; // largeur par défaut des glyphes : 500/1000 em
            double scale = Math.Clamp(100 * word.Width / natural, 1, 10000);
            cs.Append("/F1 ").Append(Num(size)).Append(" Tf ").Append(Num(scale)).Append(" Tz 1 0 0 1 ")
              .Append(Num(word.X)).Append(' ').Append(Num(word.Y)).Append(" Tm <");
            foreach (var c in units) cs.Append(((int)c).ToString("X4"));
            cs.Append("> Tj\n");
        }
        cs.Append("ET\n");
    }

    private static bool IsRightToLeft(char c) =>
        c is >= '\u0590' and <= '\u08FF' or >= '\uFB1D' and <= '\uFDFF' or >= '\uFE70' and <= '\uFEFF';

    /// <summary>
    /// Police « sans glyphes » : Type0 Identity-H dont les codes sont les points de code Unicode (table ToUnicode).
    /// Non incorporée, ce qui est admis en PDF/A pour du texte invisible (mode de rendu 3).
    /// </summary>
    private static void WriteTextFont(PdfOut w, long[] offsets, int fontId, int cidFontId, int descId, int toUnicodeId)
    {
        offsets[fontId] = w.Position;
        w.Raw($"{fontId} 0 obj\n<< /Type /Font /Subtype /Type0 /BaseFont /GlyphLessFont /Encoding /Identity-H " +
              $"/DescendantFonts [{cidFontId} 0 R] /ToUnicode {toUnicodeId} 0 R >>\nendobj\n");
        offsets[cidFontId] = w.Position;
        w.Raw($"{cidFontId} 0 obj\n<< /Type /Font /Subtype /CIDFontType2 /BaseFont /GlyphLessFont " +
              "/CIDSystemInfo << /Registry (Adobe) /Ordering (Identity) /Supplement 0 >> " +
              $"/FontDescriptor {descId} 0 R /DW 500 /CIDToGIDMap /Identity >>\nendobj\n");
        offsets[descId] = w.Position;
        w.Raw($"{descId} 0 obj\n<< /Type /FontDescriptor /FontName /GlyphLessFont /Flags 5 /FontBBox [0 0 500 1000] " +
              "/ItalicAngle 0 /Ascent 1000 /Descent 0 /CapHeight 1000 /StemV 80 >>\nendobj\n");

        var cmap = new StringBuilder();
        cmap.Append("/CIDInit /ProcSet findresource begin\n12 dict begin\nbegincmap\n");
        cmap.Append("/CIDSystemInfo << /Registry (Adobe) /Ordering (UCS) /Supplement 0 >> def\n");
        cmap.Append("/CMapName /Adobe-Identity-UCS def\n/CMapType 2 def\n");
        cmap.Append("1 begincodespacerange\n<0000> <FFFF>\nendcodespacerange\n");
        // Correspondance identité code → Unicode, par tranches de 256 (une plage ne doit faire varier que le dernier octet)
        for (int block = 0; block < 256; block += 100)
        {
            int count = Math.Min(100, 256 - block);
            cmap.Append(count).Append(" beginbfrange\n");
            for (int hi = block; hi < block + count; hi++)
                cmap.Append($"<{hi:X2}00> <{hi:X2}FF> <{hi:X2}00>\n");
            cmap.Append("endbfrange\n");
        }
        cmap.Append("endcmap\nCMapName currentdict /CMap defineresource pop\nend\nend\n");
        var data = Deflate(Encoding.ASCII.GetBytes(cmap.ToString()));
        offsets[toUnicodeId] = w.Position;
        w.Raw($"{toUnicodeId} 0 obj\n<< /Length {data.Length} /Filter /FlateDecode >>\nstream\n");
        w.Bytes(data);
        w.Raw("\nendstream\nendobj\n");
    }

    /// <summary>PDF/A-2b : flux XMP (identification PDF/A + mêmes valeurs que le dictionnaire Info) et profil sRGB.</summary>
    private static void WritePdfA(PdfOut w, long[] offsets, int metadataId, int iccId, PdfMetadata meta)
    {
        static string X(string? v) => System.Security.SecurityElement.Escape(v ?? "") ?? "";
        string date = meta.CreationDate.ToString("yyyy-MM-dd'T'HH:mm:ss", Inv) + meta.CreationDate.ToString("zzz", Inv);
        var xmp = new StringBuilder();
        xmp.Append("<?xpacket begin=\"\uFEFF\" id=\"W5M0MpCehiHzreSzNTczkc9d\"?>\n");
        xmp.Append("<x:xmpmeta xmlns:x=\"adobe:ns:meta/\">\n<rdf:RDF xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\">\n");
        xmp.Append("<rdf:Description rdf:about=\"\" xmlns:pdfaid=\"http://www.aiim.org/pdfa/ns/id/\" ");
        xmp.Append("xmlns:dc=\"http://purl.org/dc/elements/1.1/\" xmlns:xmp=\"http://ns.adobe.com/xap/1.0/\" ");
        xmp.Append("xmlns:pdf=\"http://ns.adobe.com/pdf/1.3/\">\n");
        xmp.Append("<pdfaid:part>2</pdfaid:part>\n<pdfaid:conformance>B</pdfaid:conformance>\n");
        if (!string.IsNullOrEmpty(meta.Title))
            xmp.Append($"<dc:title><rdf:Alt><rdf:li xml:lang=\"x-default\">{X(meta.Title)}</rdf:li></rdf:Alt></dc:title>\n");
        if (!string.IsNullOrEmpty(meta.Author))
            xmp.Append($"<dc:creator><rdf:Seq><rdf:li>{X(meta.Author)}</rdf:li></rdf:Seq></dc:creator>\n");
        if (!string.IsNullOrEmpty(meta.Subject))
            xmp.Append($"<dc:description><rdf:Alt><rdf:li xml:lang=\"x-default\">{X(meta.Subject)}</rdf:li></rdf:Alt></dc:description>\n");
        if (!string.IsNullOrEmpty(meta.Keywords))
            xmp.Append($"<pdf:Keywords>{X(meta.Keywords)}</pdf:Keywords>\n");
        xmp.Append("<pdf:Producer>LloydScan PDF writer</pdf:Producer>\n");
        xmp.Append($"<xmp:CreatorTool>{X(meta.Creator)}</xmp:CreatorTool>\n");
        xmp.Append($"<xmp:CreateDate>{date}</xmp:CreateDate>\n<xmp:ModifyDate>{date}</xmp:ModifyDate>\n");
        xmp.Append("</rdf:Description>\n</rdf:RDF>\n</x:xmpmeta>\n<?xpacket end=\"w\"?>");
        var xmpBytes = Encoding.UTF8.GetBytes(xmp.ToString());
        offsets[metadataId] = w.Position;
        w.Raw($"{metadataId} 0 obj\n<< /Type /Metadata /Subtype /XML /Length {xmpBytes.Length} >>\nstream\n");
        w.Bytes(xmpBytes);
        w.Raw("\nendstream\nendobj\n");

        using var res = typeof(PdfDocumentWriter).Assembly.GetManifestResourceStream("LloydScan.sRGB.icc")
                        ?? throw new InvalidOperationException("Profil sRGB introuvable dans l'assemblage.");
        using var ms = new MemoryStream();
        res.CopyTo(ms);
        var icc = Deflate(ms.ToArray());
        offsets[iccId] = w.Position;
        w.Raw($"{iccId} 0 obj\n<< /N 3 /Length {icc.Length} /Filter /FlateDecode >>\nstream\n");
        w.Bytes(icc);
        w.Raw("\nendstream\nendobj\n");
    }

    /// <summary>Compression Flate (zlib) pour les plans 1 bit quand G4 n'est pas souhaité.</summary>
    public static byte[] Deflate(byte[] data)
    {
        using var ms = new MemoryStream();
        using (var z = new ZLibStream(ms, CompressionLevel.SmallestSize, leaveOpen: true))
            z.Write(data, 0, data.Length);
        return ms.ToArray();
    }

    private static string Num(double v) => Math.Round(v, 4).ToString("0.####", Inv);

    private static string PdfDate(DateTimeOffset d)
    {
        var off = d.Offset;
        string sign = off < TimeSpan.Zero ? "-" : "+";
        off = off.Duration();
        return $"D:{d:yyyyMMddHHmmss}{sign}{off.Hours:D2}'{off.Minutes:D2}'";
    }

    private static string SanitizeName(string key)
    {
        var sb = new StringBuilder();
        foreach (var ch in key) if (char.IsAsciiLetterOrDigit(ch) || ch == '_') sb.Append(ch);
        return sb.Length == 0 ? "Custom" : sb.ToString();
    }

    /// <summary>Chaîne PDF : littérale si ASCII, sinon UTF-16BE hexadécimale avec BOM.</summary>
    internal static string PdfString(string s)
    {
        if (s.All(c => c >= 32 && c < 127))
        {
            var sb = new StringBuilder("(");
            foreach (var c in s)
            {
                if (c is '(' or ')' or '\\') sb.Append('\\');
                sb.Append(c);
            }
            return sb.Append(')').ToString();
        }
        return "<FEFF" + Convert.ToHexString(Encoding.BigEndianUnicode.GetBytes(s)) + ">";
    }

    private sealed class PdfOut
    {
        private readonly MemoryStream _ms = new();
        public long Position => _ms.Position;
        public void Raw(string s) { var b = Encoding.ASCII.GetBytes(s); _ms.Write(b, 0, b.Length); }
        public void Bytes(byte[] b) => _ms.Write(b, 0, b.Length);
        public byte[] ToArray() => _ms.ToArray();
    }
}
