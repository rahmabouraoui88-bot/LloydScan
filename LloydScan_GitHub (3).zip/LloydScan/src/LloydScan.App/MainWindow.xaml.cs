using System.ComponentModel;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using LloydScan.App.ViewModels;

namespace LloydScan.App;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
        LoadLogo();
        SourceInitialized += (_, _) =>
        {
            if (DataContext is MainViewModel vm) vm.WindowHandle = new WindowInteropHelper(this).Handle;
        };
        Loaded += (_, _) => (DataContext as MainViewModel)?.Initialize();
        WirePageList();
    }

    // ---------------- Vignettes : sélection multiple, glisser-déposer, double-clic ----------------

    private const string DragFormat = "NAPS++.Pages";
    private Point _dragStart;
    private PageItem? _pressed;
    private bool _deferSelection;

    private MainViewModel? Vm => DataContext as MainViewModel;

    private void WirePageList()
    {
        PagesList.SelectionChanged += (_, _) =>
        {
            if (Vm != null) Vm.SelectedPages = PagesList.SelectedItems.Cast<PageItem>().ToList();
        };
        PagesList.MouseDoubleClick += (_, e) =>
        {
            if (ItemAt(e.OriginalSource) != null && Vm?.PreviewCommand.CanExecute(null) == true) Vm.PreviewCommand.Execute(null);
        };
        PagesList.PreviewMouseLeftButtonDown += (_, e) =>
        {
            _dragStart = e.GetPosition(PagesList);
            _pressed = ItemAt(e.OriginalSource);
            // Clic sur une page déjà sélectionnée parmi plusieurs : on garde la sélection pour pouvoir la faire glisser
            _deferSelection = _pressed != null && e.ClickCount == 1 && Keyboard.Modifiers == ModifierKeys.None
                              && PagesList.SelectedItems.Count > 1 && PagesList.SelectedItems.Contains(_pressed);
            if (_deferSelection) e.Handled = true;
        };
        PagesList.PreviewMouseLeftButtonUp += (_, _) =>
        {
            if (_deferSelection && _pressed != null)
            {
                PagesList.SelectedItems.Clear();
                PagesList.SelectedItem = _pressed;
            }
            _deferSelection = false;
            _pressed = null;
        };
        PagesList.PreviewMouseMove += (_, e) =>
        {
            if (_pressed == null || e.LeftButton != MouseButtonState.Pressed || Vm?.CanReorderPages != true) return;
            var delta = e.GetPosition(PagesList) - _dragStart;
            if (Math.Abs(delta.X) < SystemParameters.MinimumHorizontalDragDistance &&
                Math.Abs(delta.Y) < SystemParameters.MinimumVerticalDragDistance) return;
            var items = PagesList.SelectedItems.Cast<PageItem>().ToList();
            if (!items.Contains(_pressed)) items = new List<PageItem> { _pressed };
            var all = PagesList.Items.Cast<PageItem>().ToList();
            items = items.OrderBy(all.IndexOf).ToList();
            _deferSelection = false;
            _pressed = null;
            DragDrop.DoDragDrop(PagesList, new DataObject(DragFormat, items), DragDropEffects.Move);
        };
        PagesList.DragOver += (_, e) =>
        {
            e.Effects = e.Data.GetDataPresent(DragFormat) ? DragDropEffects.Move : DragDropEffects.None;
            e.Handled = true;
        };
        PagesList.Drop += (_, e) =>
        {
            if (Vm == null || e.Data.GetData(DragFormat) is not List<PageItem> items) return;
            var all = PagesList.Items.Cast<PageItem>().ToList();
            int index = all.Count;
            var target = ItemAt(e.OriginalSource);
            if (target != null && PagesList.ItemContainerGenerator.ContainerFromItem(target) is ListBoxItem container)
            {
                index = all.IndexOf(target);
                // Lâchée sur la moitié droite de la vignette : la page va après
                if (e.GetPosition(container).X > container.ActualWidth / 2) index++;
            }
            e.Handled = true;
            Vm.MovePages(items, index);
        };
    }

    /// <summary>Vignette sous la souris (remonte de l'élément cliqué jusqu'à la ligne de la liste).</summary>
    private static PageItem? ItemAt(object source)
    {
        var node = source as DependencyObject;
        while (node != null && node is not ListBoxItem)
            node = node is Visual or System.Windows.Media.Media3D.Visual3D
                ? VisualTreeHelper.GetParent(node)
                : LogicalTreeHelper.GetParent(node);
        return (node as ListBoxItem)?.DataContext as PageItem;
    }

    /// <summary>
    /// Logo de l'entreprise : Assets\logo.png (PNG, fond transparent de préférence), à côté de NAPS++.exe,
    /// affiché en haut à gauche. Assets\icon.png (carré) sert d'icône de fenêtre et de barre des tâches
    /// (à défaut, le logo). Pour les changer : remplacer les fichiers et relancer, sans recompiler.
    /// </summary>
    private void LoadLogo()
    {
        try
        {
            var assets = Path.Combine(AppContext.BaseDirectory, "Assets");
            var logo = Load(Path.Combine(assets, "logo.png"));
            if (logo != null)
            {
                LogoImage.Source = logo;
                LogoImage.Visibility = Visibility.Visible;
            }
            var icon = Load(Path.Combine(assets, "icon.png")) ?? logo;
            if (icon != null) Icon = icon;
        }
        catch
        {
            // Logo illisible : l'application démarre quand même, sans logo
        }
    }

    private static BitmapImage? Load(string path)
    {
        if (!File.Exists(path)) return null;
        var image = new BitmapImage();
        image.BeginInit();
        image.CacheOption = BitmapCacheOption.OnLoad;   // fichier libéré tout de suite (remplaçable)
        image.UriSource = new Uri(path);
        image.EndInit();
        image.Freeze();
        return image;
    }

    protected override void OnClosing(CancelEventArgs e)
    {
        if (DataContext is MainViewModel vm)
        {
            if (vm.IsBusy &&
                MessageBox.Show("Un traitement est en cours. Quitter quand même ?", AppInfo.Name,
                    MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes)
            {
                e.Cancel = true;
                return;
            }
            vm.Dispose();
        }
        base.OnClosing(e);
    }
}
