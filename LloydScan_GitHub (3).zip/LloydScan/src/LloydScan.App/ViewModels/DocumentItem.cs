using System.Collections.ObjectModel;
using System.Windows.Media.Imaging;
using LloydScan.App.Services;
using LloydScan.Core.Configuration;
using LloydScan.Core.Processing;

namespace LloydScan.App.ViewModels;

public sealed class PageItem
{
    public ProcessedPage Page { get; init; } = null!;
    public BitmapSource Thumbnail { get; init; } = null!;
    /// <summary>Rotation affichée (la vignette n'est pas recalculée, elle est tournée à l'écran).</summary>
    public int Rotation { get; init; }
    public string Label { get; init; } = "";
}

/// <summary>Ligne de la liste des documents (un document = pages entre deux séparatrices).</summary>
public sealed class DocumentItem : ObservableObject
{
    private readonly Action<DocumentItem, string> _retarget;
    private readonly OperatorOverride _override;

    public DocumentItem(ScanDocument doc, BatchResult batch, Action<DocumentItem, string> retarget, OperatorOverride overrideRule)
    {
        Document = doc;
        Batch = batch;
        _retarget = retarget;
        _override = overrideRule;
        ReloadPages();
    }

    /// <summary>Recharge les vignettes après une retouche (ordre, rotation, nettoyage, suppression).</summary>
    public void ReloadPages()
    {
        Pages.Clear();
        int n = 0;
        foreach (var p in Document.Pages)
        {
            n++;
            var note = string.IsNullOrEmpty(p.CleanupNote) ? "" : $"\n{p.CleanupNote}";
            Pages.Add(new PageItem
            {
                Page = p,
                Thumbnail = WicImageCodec.ToBitmapSource(p.Thumbnail),
                Rotation = p.Rotation,
                Label = $"{(p.IsSeparator ? "Fiche séparatrice · " : "")}Page {n} · {FormatSize(p.Optimized?.EncodedBytes ?? 0)}{note}"
            });
        }
        OnPropertyChanged(nameof(PageCount));
        Refresh();
    }

    public ScanDocument Document { get; }
    public BatchResult Batch { get; }
    public ObservableCollection<PageItem> Pages { get; } = new();

    public int Sequence => Document.Sequence;
    public string Qr => Document.QrText ?? "— aucun QR —";
    public int PageCount => Document.PageCount;
    public string FileName => Document.FileName;
    public string RoutingReason => Document.RoutingReason;
    /// <summary>Taille à l'entrée (scanner ou fichier importé).</summary>
    public string SizeBeforeText => FormatSize(Document.InputBytes);
    /// <summary>Taille du PDF produit.</summary>
    public string SizeText => FormatSize(Document.PdfBytes);
    public string PerPageText => Document.PageCount == 0 ? "" : FormatSize(Document.PdfBytes / Document.PageCount);
    public string GainText => FormatGain(Document.InputBytes, Document.PdfBytes);

    /// <summary>« −35 % » quand le PDF est plus léger, « +3,4 % » quand il est plus lourd.</summary>
    public static string FormatGain(long before, long after)
    {
        if (before <= 0) return "";
        double change = 100.0 * ((double)after / before - 1);
        return change <= 0 ? $"−{-change:0.#} %" : $"+{change:0.#} %";
    }
    public string Warnings => string.Join(" · ", Document.Warnings);
    public bool HasWarning => Document.Warnings.Count > 0 && Document.Status != DocumentStatus.Sent;
    public bool CanEdit => Document.Status is DocumentStatus.Ready or DocumentStatus.Failed;

    /// <summary>L'agent peut-il corriger la destination ? (règle fixée par l'administrateur)</summary>
    public bool CanEditTarget => CanEdit && _override switch
    {
        OperatorOverride.Always => true,
        OperatorOverride.OnlyWithoutSeparator => Document.QrText is null,
        _ => false
    };
    public string? RemoteUrl => Document.RemoteUrl;
    public string? Error => Document.Error;

    public string StatusText => Document.Status switch
    {
        DocumentStatus.Ready => "Prêt",
        DocumentStatus.Sending => "Envoi…",
        DocumentStatus.Sent => "Envoyé",
        DocumentStatus.Queued => "En file d'attente",
        DocumentStatus.Failed => "Erreur",
        _ => Document.Status.ToString()
    };

    /// <summary>Destination modifiable par l'opérateur tant que le document n'est pas envoyé.</summary>
    public string Target
    {
        get => Document.Target;
        set
        {
            if (value == Document.Target || !CanEditTarget) return;
            _retarget(this, value);
            Refresh();
        }
    }

    public void Refresh()
    {
        foreach (var name in new[] { nameof(Target), nameof(FileName), nameof(SizeText), nameof(SizeBeforeText), nameof(PerPageText), nameof(GainText), nameof(Warnings), nameof(Sequence), nameof(Qr),
                                     nameof(HasWarning), nameof(StatusText), nameof(CanEdit), nameof(CanEditTarget), nameof(RoutingReason),
                                     nameof(RemoteUrl), nameof(Error) })
            OnPropertyChanged(name);
    }

    public static string FormatSize(long bytes) => bytes switch
    {
        < 1024 => $"{bytes} o",
        < 1024 * 1024 => $"{bytes / 1024.0:0} Ko",
        _ => $"{bytes / 1048576.0:0.0} Mo"
    };
}
