using System.IO;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using LloydScan.Core.Imaging;

namespace LloydScan.App.Services;

/// <summary>
/// Codec basé sur WIC (Windows Imaging Component, intégré à Windows) :
/// lit les BMP des pilotes TWAIN/WIA, les TIFF/JPEG/PNG et (via Windows.Data.Pdf) les PDF importés, encode en JPEG.
/// Aucune licence tierce.
/// </summary>
public sealed class WicImageCodec : IImageCodec
{
    /// <summary>Résolution de rendu des PDF (copieurs multifonctions).</summary>
    public const double PdfRenderDpi = 300;

    /// <summary>
    /// Résolution utile maximale : aucun profil n'exploite plus de 300 dpi. Une image plus fine (scan 600 dpi,
    /// photo de téléphone de 12 à 50 mégapixels) est réduite dès la lecture, sans jamais charger l'image entière
    /// en mémoire (sinon « Insufficient memory » dans le processus 32 bits).
    /// </summary>
    public const double MaxUsefulDpi = 300;
    /// <summary>Garde-fou mémoire : au plus 40 millions de pixels par page après lecture.</summary>
    public const long MaxPixels = 40_000_000;

    public IReadOnlyList<RasterImage> Decode(byte[] data)
    {
        if (PdfRasterizer.IsPdf(data))
        {
            var pages = new List<RasterImage>();
            foreach (var png in PdfRasterizer.RenderPages(data, PdfRenderDpi))
                foreach (var page in DecodeImage(png, PdfRenderDpi))
                    pages.Add(page);
            return pages;
        }
        return DecodeImage(data, null);
    }

    /// <summary>Décode une page rendue depuis un PDF (résolution connue).</summary>
    public RasterImage DecodeRendered(byte[] png, double dpi) => DecodeImage(png, dpi)[0];

    /// <summary>Image prête pour l'affichage ou l'impression WPF (figée, utilisable depuis tout thread).</summary>
    public static BitmapSource LoadFrozen(byte[] data, double? dpi = null)
    {
        using var ms = new MemoryStream(data, writable: false);
        var frame = BitmapFrame.Create(ms, BitmapCreateOptions.IgnoreColorProfile, BitmapCacheOption.OnLoad);
        BitmapSource result = frame;
        if (dpi is double d && Math.Abs(frame.DpiX - d) > 1)
        {
            // Même pixels, résolution corrigée : 1 pouce affiché/imprimé = 1 pouce de papier
            int stride = (frame.PixelWidth * frame.Format.BitsPerPixel + 7) / 8;
            var pixels = new byte[stride * frame.PixelHeight];
            frame.CopyPixels(pixels, stride, 0);
            result = BitmapSource.Create(frame.PixelWidth, frame.PixelHeight, d, d, frame.Format, frame.Palette, pixels, stride);
        }
        result.Freeze();
        return result;
    }

    private static IReadOnlyList<RasterImage> DecodeImage(byte[] data, double? knownDpi)
    {
        using var ms = new MemoryStream(data, writable: false);
        // CacheOption.None : chaque page est lue à la demande (pas de copie pleine résolution en cache)
        var decoder = BitmapDecoder.Create(ms,
            BitmapCreateOptions.PreservePixelFormat | BitmapCreateOptions.IgnoreColorProfile,
            BitmapCacheOption.None);
        var pages = new List<RasterImage>(decoder.Frames.Count);
        foreach (var frame in decoder.Frames)
        {
            double dpi = knownDpi ?? EffectiveDpi(frame);
            double scale = Math.Min(1.0, MaxUsefulDpi / dpi);
            long pixels = (long)frame.PixelWidth * frame.PixelHeight;
            if (pixels * scale * scale > MaxPixels) scale = Math.Sqrt((double)MaxPixels / pixels);
            bool gray = IsGray(frame);
            BitmapSource source = frame;
            if (scale < 0.98)
            {
                // Réduction par WIC pendant la lecture : la pleine résolution n'est jamais copiée en mémoire .NET
                source = new TransformedBitmap(frame, new ScaleTransform(scale, scale));
            }
            var page = ToRaster(source, gray);
            page.Dpi = dpi * page.Width / Math.Max(1, frame.PixelWidth);
            pages.Add(page);
        }
        return pages;
    }

    /// <summary>
    /// Résolution réelle de l'image. Les photos de téléphone et beaucoup de PNG indiquent 72 ou 96 dpi (valeur
    /// d'écran sans rapport avec le papier) : on l'estime alors en supposant une page A4 (29,7 cm de long).
    /// </summary>
    private static double EffectiveDpi(BitmapSource frame)
    {
        double dpi = frame.DpiX;
        if (dpi >= 100 && dpi <= 2400) return dpi;
        double longSide = Math.Max(frame.PixelWidth, frame.PixelHeight);
        return Math.Clamp(longSide / 11.69, 100, 1200);
    }

    private static RasterImage ToRaster(BitmapSource src, bool gray)
    {
        var target = gray ? PixelFormats.Gray8 : PixelFormats.Rgb24;
        BitmapSource converted = src.Format == target ? src : new FormatConvertedBitmap(src, target, null, 0);
        int w = converted.PixelWidth, h = converted.PixelHeight, c = gray ? 1 : 3;
        var pixels = new byte[w * h * c];
        converted.CopyPixels(pixels, w * c, 0);
        return new RasterImage(w, h, c, pixels, src.DpiX);
    }

    private static bool IsGray(BitmapSource src)
    {
        var f = src.Format;
        if (f == PixelFormats.BlackWhite || f == PixelFormats.Gray2 || f == PixelFormats.Gray4 ||
            f == PixelFormats.Gray8 || f == PixelFormats.Gray16 || f == PixelFormats.Gray32Float)
            return true;
        // Images indexées (BMP 1 bit du mode noir et blanc) : grises si la palette l'est
        if (src.Palette != null &&
            (f == PixelFormats.Indexed1 || f == PixelFormats.Indexed2 || f == PixelFormats.Indexed4 || f == PixelFormats.Indexed8))
            return src.Palette.Colors.All(col => col.R == col.G && col.G == col.B);
        return false;
    }

    public byte[] EncodeJpeg(RasterImage image, int quality)
    {
        var format = image.IsGray ? PixelFormats.Gray8 : PixelFormats.Rgb24;
        BitmapSource bmp = BitmapSource.Create(image.Width, image.Height, image.Dpi, image.Dpi, format, null,
            image.Pixels, image.Stride);
        // L'encodeur JPEG de WIC attend du BGR 24 bits ou du gris 8 bits
        if (!image.IsGray) bmp = new FormatConvertedBitmap(bmp, PixelFormats.Bgr24, null, 0);
        var encoder = new JpegBitmapEncoder { QualityLevel = quality };
        encoder.Frames.Add(BitmapFrame.Create(bmp));
        using var ms = new MemoryStream();
        encoder.Save(ms);
        return ms.ToArray();
    }

    /// <summary>Conversion d'une vignette pour l'affichage WPF.</summary>
    public static BitmapSource ToBitmapSource(RasterImage image)
    {
        var format = image.IsGray ? PixelFormats.Gray8 : PixelFormats.Rgb24;
        var bmp = BitmapSource.Create(image.Width, image.Height, 96, 96, format, null, image.Pixels, image.Stride);
        bmp.Freeze();
        return bmp;
    }
}
