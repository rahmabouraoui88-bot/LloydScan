using System.Security.Cryptography;
using System.Text;

namespace LloydScan.App.Services;

/// <summary>
/// Chiffrement DPAPI :
///  - portée machine pour le compte de service de appsettings.json (« dpapi:… », généré par --protect) ;
///  - portée utilisateur pour les comptes des agents : seul l'agent, dans sa session Windows, peut les déchiffrer.
/// </summary>
public static class PasswordProtector
{
    private const string Prefix = "dpapi:";
    private static readonly byte[] MachineEntropy = Encoding.UTF8.GetBytes("LloydScan/WebDAV/v1");
    private static readonly byte[] UserEntropy = Encoding.UTF8.GetBytes("LloydScan/Agent/v1");

    public static string Protect(string plain) =>
        Prefix + Convert.ToBase64String(ProtectedData.Protect(
            Encoding.UTF8.GetBytes(plain), MachineEntropy, DataProtectionScope.LocalMachine));

    public static string? Unprotect(string? stored)
    {
        if (string.IsNullOrEmpty(stored) || !stored.StartsWith(Prefix, StringComparison.Ordinal)) return stored;
        var bytes = ProtectedData.Unprotect(Convert.FromBase64String(stored[Prefix.Length..]), MachineEntropy,
            DataProtectionScope.LocalMachine);
        return Encoding.UTF8.GetString(bytes);
    }

    public static string ProtectForUser(string plain) =>
        Convert.ToBase64String(ProtectedData.Protect(Encoding.UTF8.GetBytes(plain), UserEntropy, DataProtectionScope.CurrentUser));

    public static string UnprotectForUser(string stored) =>
        Encoding.UTF8.GetString(ProtectedData.Unprotect(Convert.FromBase64String(stored), UserEntropy, DataProtectionScope.CurrentUser));
}
