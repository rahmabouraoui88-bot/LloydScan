using System.IO;
using System.Text.Json;
using LloydScan.Core.Configuration;
using LloydScan.Core.Upload;

namespace LloydScan.App.Services;

/// <summary>
/// Coffre des comptes WebDAV de l'agent connecté (un par destination : ELISE Lloyd, Lloyd Vie).
/// Fichier %APPDATA%\LloydScan\identifiants.json, mots de passe chiffrés DPAPI pour la session Windows de l'agent :
/// un autre agent du même poste ne peut ni les lire ni les utiliser.
/// </summary>
public sealed class AgentCredentialStore : ICredentialProvider
{
    public sealed class Entry
    {
        public string Username { get; set; } = "";
        public string Password { get; set; } = "";   // chiffré DPAPI CurrentUser
        public DateTimeOffset UpdatedAt { get; set; }
    }

    private readonly string _path;
    private Dictionary<string, Entry> _entries;

    public AgentCredentialStore()
    {
        var dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "LloydScan");
        Directory.CreateDirectory(dir);
        _path = Path.Combine(dir, "identifiants.json");
        _entries = Load();
    }

    private Dictionary<string, Entry> Load()
    {
        var result = new Dictionary<string, Entry>(StringComparer.OrdinalIgnoreCase);
        try
        {
            if (File.Exists(_path))
            {
                var stored = JsonSerializer.Deserialize<Dictionary<string, Entry>>(File.ReadAllText(_path));
                if (stored != null)
                    foreach (var (k, v) in stored) result[k] = v;
            }
        }
        catch { /* fichier corrompu : l'agent ressaisit ses identifiants */ }
        return result;
    }

    public WebDavCredential? Get(string targetName, WebDavTarget target)
    {
        switch (target.Authentication)
        {
            case WebDavAuthentication.Windows:
                return null;
            case WebDavAuthentication.Service:
                return new WebDavCredential(target.Username ?? "", PasswordProtector.Unprotect(target.Password) ?? "");
            default:
                if (!_entries.TryGetValue(targetName, out var e) || string.IsNullOrEmpty(e.Username)) return null;
                try { return new WebDavCredential(e.Username, PasswordProtector.UnprotectForUser(e.Password)); }
                catch { return null; } // profil Windows restauré / autre poste : ressaisie nécessaire
        }
    }

    public string? GetUsername(string targetName) => _entries.TryGetValue(targetName, out var e) ? e.Username : null;

    /// <summary>Destinations en mode Agent pour lesquelles l'agent n'a pas encore de compte utilisable.</summary>
    public List<string> Missing(AppSettings settings, IEnumerable<string>? targets = null) =>
        (targets ?? settings.Targets.Keys)
        .Distinct(StringComparer.OrdinalIgnoreCase)
        .Where(n => settings.Targets.TryGetValue(n, out var t) && t.Authentication == WebDavAuthentication.Agent
                    && Get(n, t) is null)
        .ToList();

    public void Save(string targetName, string username, string password)
    {
        _entries[targetName] = new Entry
        {
            Username = username.Trim(),
            Password = PasswordProtector.ProtectForUser(password),
            UpdatedAt = DateTimeOffset.Now
        };
        File.WriteAllText(_path, JsonSerializer.Serialize(_entries, new JsonSerializerOptions { WriteIndented = true }));
    }
}
