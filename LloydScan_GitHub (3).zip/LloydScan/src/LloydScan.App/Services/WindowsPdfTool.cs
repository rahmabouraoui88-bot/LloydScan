using LloydScan.Core.Imaging;
using LloydScan.Core.Pdf;

namespace LloydScan.App.Services;

/// <summary>qpdf (optimisation sans perte) + moteur PDF de Windows pour la vignette de la 1re page.</summary>
public sealed class WindowsPdfTool : QpdfTool
{
    public WindowsPdfTool(string qpdfPath) : base(qpdfPath) { }

    public override RasterImage? RenderThumbnail(byte[] pdf, int width)
    {
        // A4 à 22 dpi ≈ 180 px de large
        var png = PdfRasterizer.RenderPages(pdf, 22, maxPages: 1).FirstOrDefault();
        if (png is null) return null;
        var page = new WicImageCodec().Decode(png).FirstOrDefault();
        return page is null ? null : ImageOps.ScaleToWidth(page, width);
    }
}
