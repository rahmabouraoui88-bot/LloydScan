using System.IO;
using System.Reflection;
using System.Threading.Channels;
using LloydScan.Core.Configuration;
using LloydScan.Core.Processing;
using NTwain;
using NTwain.Data;

namespace LloydScan.App.Services;

/// <summary>
/// Pilotage des scanners TWAIN via NTwain (licence MIT).
/// Les pages arrivent dans un canal au fil de l'eau : le traitement commence pendant que le chargeur tourne.
/// </summary>
public sealed class TwainScanner : IDisposable
{
    private readonly TwainSession _session;
    private Channel<ScannedImage>? _channel;
    private ScanProfile? _profile;
    private CancellationToken _cancel;
    private int _pageCount;

    public TwainScanner()
    {
        var appId = TWIdentity.CreateFromAssembly(DataGroups.Image, Assembly.GetEntryAssembly() ?? Assembly.GetExecutingAssembly());
        _session = new TwainSession(appId);
        _session.TransferReady += OnTransferReady;
        _session.DataTransferred += OnDataTransferred;
        _session.TransferError += OnTransferError;
        _session.SourceDisabled += OnSourceDisabled;
    }

    public bool IsOpen { get; private set; }

    /// <summary>Ouvre le gestionnaire de sources TWAIN (DSM). Renvoie un message d'erreur ou null.</summary>
    public string? Open()
    {
        if (IsOpen) return null;
        if (!PlatformInfo.Current.IsSupported)
            return "TWAIN indisponible : le gestionnaire TWAIN (TWAINDSM.dll) n'est pas installé. Installer le pilote TWAIN du scanner.";
        var rc = _session.Open(); // boucle de messages interne à NTwain
        if (rc != ReturnCode.Success) return $"Ouverture de TWAIN impossible ({rc}).";
        IsOpen = true;
        return null;
    }

    public IReadOnlyList<string> GetSources() =>
        IsOpen ? _session.GetSources().Select(s => s.Name).Distinct().ToList() : Array.Empty<string>();

    /// <summary>Lance la numérisation ; les pages sont renvoyées au fil de leur arrivée.</summary>
    public IAsyncEnumerable<ScannedImage> Scan(string sourceName, ScanProfile profile, IntPtr windowHandle, CancellationToken ct)
    {
        if (!IsOpen) throw new InvalidOperationException("TWAIN n'est pas ouvert.");
        _channel = Channel.CreateUnbounded<ScannedImage>(new UnboundedChannelOptions { SingleReader = true });
        _profile = profile;
        _cancel = ct;
        _pageCount = 0;

        // Source déjà ouverte mais différente : on la ferme
        if (_session.State >= 4 && _session.CurrentSource != null && _session.CurrentSource.Name != sourceName)
            _session.CurrentSource.Close();

        if (_session.State < 4)
        {
            var source = _session.GetSources().FirstOrDefault(s => s.Name == sourceName)
                         ?? throw new InvalidOperationException($"Scanner introuvable : {sourceName}");
            var rcOpen = source.Open();
            if (rcOpen != ReturnCode.Success)
                throw new InvalidOperationException($"Impossible d'ouvrir le scanner « {sourceName} » ({rcOpen}). Est-il allumé et connecté ?");
        }

        var ds = _session.CurrentSource!;
        var warnings = Configure(ds, profile);

        // Toujours sans l'interface du pilote : les réglages viennent exclusivement du profil (verrouillé).
        var rc = ds.Enable(SourceEnableMode.NoUI, false, windowHandle);
        if (rc != ReturnCode.Success)
            _channel.Writer.TryComplete(new InvalidOperationException($"Le scanner a refusé de démarrer ({rc}). Vérifier le chargeur."));

        LastWarnings = warnings;
        return _channel.Reader.ReadAllAsync(ct);
    }

    /// <summary>Réglages que le pilote n'a pas acceptés (affichés à titre d'information).</summary>
    public IReadOnlyList<string> LastWarnings { get; private set; } = Array.Empty<string>();

    private static List<string> Configure(DataSource ds, ScanProfile p)
    {
        var warnings = new List<string>();
        var caps = ds.Capabilities;

        void Set<T>(ICapWrapper<T> cap, T value, string label)
        {
            try
            {
                if (!cap.IsSupported || !cap.CanSet) { warnings.Add($"{label} : non géré par le pilote"); return; }
                var rc = cap.SetValue(value);
                if (rc != ReturnCode.Success) warnings.Add($"{label} : refusé ({rc})");
            }
            catch (Exception ex) { warnings.Add($"{label} : {ex.Message}"); }
        }

        Set(caps.ICapXferMech, XferMech.Native, "Transfert natif");
        Set(caps.ICapPixelType, p.ColorMode switch
        {
            ScanColorMode.Gray => PixelType.Gray,
            ScanColorMode.BlackWhite => PixelType.BlackWhite,
            _ => PixelType.RGB
        }, "Mode couleur");
        Set(caps.ICapXResolution, (TWFix32)(float)p.Resolution, "Résolution X");
        Set(caps.ICapYResolution, (TWFix32)(float)p.Resolution, "Résolution Y");
        if (p.UseFeeder)
        {
            Set(caps.CapFeederEnabled, BoolType.True, "Chargeur");
            Set(caps.CapAutoFeed, BoolType.True, "Alimentation automatique");
        }
        else if (caps.CapFeederEnabled.IsSupported)
        {
            Set(caps.CapFeederEnabled, BoolType.False, "Vitre");
        }
        if (caps.CapDuplexEnabled.IsSupported)
            Set(caps.CapDuplexEnabled, p.Duplex ? BoolType.True : BoolType.False, "Recto-verso");
        if (p.AutoDeskew) Set(caps.ICapAutomaticDeskew, BoolType.True, "Redressement automatique");
        if (p.AutoBorderDetection) Set(caps.ICapAutomaticBorderDetection, BoolType.True, "Détection des bords");
        return warnings;
    }

    private void OnTransferReady(object? sender, TransferReadyEventArgs e)
    {
        if (_cancel.IsCancellationRequested) e.CancelAll = true;
    }

    private void OnDataTransferred(object? sender, DataTransferredEventArgs e)
    {
        try
        {
            byte[]? data = null;
            if (e.NativeData != IntPtr.Zero)
            {
                using var stream = e.GetNativeImageStream(); // BMP (ou TIFF selon le pilote)
                if (stream != null)
                {
                    using var ms = new MemoryStream();
                    stream.CopyTo(ms);
                    data = ms.ToArray();
                }
            }
            else if (!string.IsNullOrEmpty(e.FileDataPath) && File.Exists(e.FileDataPath))
            {
                data = File.ReadAllBytes(e.FileDataPath);
            }
            if (data != null)
                _channel?.Writer.TryWrite(new ScannedImage
                {
                    Data = data,
                    DpiHint = _profile?.Resolution,
                    SourceName = $"Scanner p{Interlocked.Increment(ref _pageCount)}"
                });
        }
        catch (Exception ex)
        {
            _channel?.Writer.TryComplete(ex);
        }
    }

    private void OnTransferError(object? sender, TransferErrorEventArgs e)
    {
        var message = e.Exception?.Message ?? $"code {e.ReturnCode}";
        _channel?.Writer.TryComplete(new InvalidOperationException($"Erreur de transfert du scanner : {message}"));
    }

    private void OnSourceDisabled(object? sender, EventArgs e)
    {
        // Fin du lot (chargeur vide, annulation ou fermeture de l'interface du pilote)
        _channel?.Writer.TryComplete();
    }

    public void Dispose()
    {
        try
        {
            if (_session.State >= 4) _session.CurrentSource?.Close();
            if (IsOpen) _session.Close();
        }
        catch { /* fermeture best effort */ }
        IsOpen = false;
    }
}
