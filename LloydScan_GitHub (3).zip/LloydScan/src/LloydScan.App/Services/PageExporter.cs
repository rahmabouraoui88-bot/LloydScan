using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using LloydScan.Core.Imaging;

namespace LloydScan.App.Services;

/// <summary>
/// « Imprimer » et « Enregistrer les images » : à partir du PDF final du document (exactement ce qui part vers ELISE),
/// page par page pour ne jamais saturer la mémoire du processus 32 bits.
/// </summary>
public static class PageExporter
{
    /// <summary>Résolution des images enregistrées (qualité archive).</summary>
    public const double ExportDpi = 300;
    /// <summary>Résolution d'impression : nette sur laser et rapide à envoyer à l'imprimante.</summary>
    public const double PrintDpi = 200;

    /// <summary>Une image JPEG par page : « nom.jpg » si une seule page, sinon « nom_p01.jpg », « nom_p02.jpg »…</summary>
    public static List<string> SaveJpeg(byte[] pdf, string path, IProgress<string>? progress = null, CancellationToken ct = default)
    {
        var codec = new WicImageCodec();
        var files = new List<string>();
        using var pages = PdfPages.Open(pdf);
        string dir = Path.GetDirectoryName(path) ?? ".";
        string stem = Path.GetFileNameWithoutExtension(path);
        for (int i = 0; i < pages.Count; i++)
        {
            ct.ThrowIfCancellationRequested();
            progress?.Report($"Enregistrement JPEG : page {i + 1}/{pages.Count}…");
            var raster = ImageExport.Simplify(codec.DecodeRendered(pages.RenderPng(i, ExportDpi), ExportDpi));
            var target = pages.Count == 1 ? path : Path.Combine(dir, $"{stem}_p{i + 1:00}.jpg");
            File.WriteAllBytes(target, codec.EncodeJpeg(raster, 90));
            files.Add(target);
        }
        return files;
    }

    /// <summary>Un seul fichier TIFF multipage (sans perte : G4 pour le noir et blanc, Deflate sinon).</summary>
    public static void SaveTiff(byte[] pdf, string path, IProgress<string>? progress = null, CancellationToken ct = default)
    {
        var codec = new WicImageCodec();
        using var pages = PdfPages.Open(pdf);
        var temp = path + ".tmp";
        try
        {
            using (var fs = File.Create(temp))
            using (var tiff = new TiffWriter(fs))
            {
                for (int i = 0; i < pages.Count; i++)
                {
                    ct.ThrowIfCancellationRequested();
                    progress?.Report($"Enregistrement TIFF : page {i + 1}/{pages.Count}…");
                    tiff.AddPage(codec.DecodeRendered(pages.RenderPng(i, ExportDpi), ExportDpi));
                }
            }
            File.Move(temp, path, overwrite: true);
        }
        finally
        {
            if (File.Exists(temp)) File.Delete(temp);
        }
    }

    /// <summary>Boîte de dialogue Windows « Imprimer » puis impression des pages choisies. Faux si annulé.</summary>
    public static bool Print(byte[] pdf, string title, Window? owner)
    {
        using var pages = PdfPages.Open(pdf);
        var dialog = new PrintDialog
        {
            UserPageRangeEnabled = true,
            MinPage = 1,
            MaxPage = (uint)pages.Count,
            PageRange = new PageRange(1, pages.Count)
        };
        if (dialog.ShowDialog() != true) return false;

        int from = 1, to = pages.Count;
        if (dialog.PageRangeSelection == PageRangeSelection.UserPages)
        {
            from = Math.Clamp(dialog.PageRange.PageFrom, 1, pages.Count);
            to = Math.Clamp(dialog.PageRange.PageTo, from, pages.Count);
        }
        var size = new Size(dialog.PrintableAreaWidth, dialog.PrintableAreaHeight);
        dialog.PrintDocument(new PagePaginator(pages, from - 1, to - from + 1, size), title);
        return true;
    }

    /// <summary>Fournit les pages à l'imprimante une par une (rendu à la demande, rien n'est gardé en mémoire).</summary>
    private sealed class PagePaginator : DocumentPaginator
    {
        private readonly PdfPages _pages;
        private readonly int _first, _count;
        private Size _size;

        public PagePaginator(PdfPages pages, int first, int count, Size size)
        {
            _pages = pages; _first = first; _count = count; _size = size;
        }

        public override DocumentPage GetPage(int pageNumber)
        {
            var bitmap = WicImageCodec.LoadFrozen(_pages.RenderPng(_first + pageNumber, PrintDpi));
            var image = new Image { Source = bitmap, Stretch = Stretch.Uniform };
            RenderOptions.SetBitmapScalingMode(image, BitmapScalingMode.HighQuality);
            // Page paysage sur papier portrait (ou l'inverse) : on la tourne pour qu'elle remplisse la feuille
            bool landscapeImage = bitmap.PixelWidth > bitmap.PixelHeight;
            bool landscapePaper = _size.Width > _size.Height;
            if (landscapeImage != landscapePaper) image.LayoutTransform = new RotateTransform(90);

            var border = new Border { Width = _size.Width, Height = _size.Height, Child = image, Background = Brushes.White };
            border.Measure(_size);
            border.Arrange(new Rect(_size));
            border.UpdateLayout();
            return new DocumentPage(border, _size, new Rect(_size), new Rect(_size));
        }

        public override bool IsPageCountValid => true;
        public override int PageCount => _count;
        public override Size PageSize { get => _size; set => _size = value; }
        public override IDocumentPaginatorSource? Source => null;
    }
}
