using System.IO;

namespace LloydScan.App.Services;

/// <summary>
/// Verrouillage des paramètres : la configuration (profils de numérisation, optimisation, routage, URL WebDAV)
/// doit être installée dans un dossier que les agents ne peuvent pas modifier (ex. C:\Program Files\LloydScan).
/// Ce contrôle vérifie au démarrage que l'agent connecté n'a pas les droits d'écriture.
/// </summary>
public static class ConfigGuard
{
    public static bool IsWritableByCurrentUser(string configPath)
    {
        // 1. Le fichier peut-il être ouvert en écriture ? (ouvert puis refermé sans rien écrire)
        try
        {
            using var fs = new FileStream(configPath, FileMode.Open, FileAccess.Write, FileShare.ReadWrite | FileShare.Delete);
            return true;
        }
        catch (UnauthorizedAccessException) { }
        catch (IOException) { }

        // 2. Le dossier permet-il de créer un fichier (donc de remplacer la configuration) ?
        try
        {
            var probe = Path.Combine(Path.GetDirectoryName(configPath)!, $".lloydscan-{Guid.NewGuid():N}.tmp");
            using (new FileStream(probe, FileMode.CreateNew, FileAccess.Write, FileShare.None, 1, FileOptions.DeleteOnClose)) { }
            return true;
        }
        catch (UnauthorizedAccessException) { return false; }
        catch (IOException) { return false; }
    }
}
