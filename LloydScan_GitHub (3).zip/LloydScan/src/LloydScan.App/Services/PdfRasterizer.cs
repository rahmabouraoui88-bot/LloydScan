using System.IO;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Data.Pdf;
using Windows.Storage.Streams;

namespace LloydScan.App.Services;

/// <summary>
/// Lecture des PDF déposés par les copieurs multifonctions, avec le moteur PDF intégré à Windows 10/11
/// (Windows.Data.Pdf) : aucune bibliothèque tierce. Chaque page est rendue en image puis optimisée comme un scan.
/// </summary>
public static class PdfRasterizer
{
    public static bool IsPdf(byte[] data) =>
        data.Length > 4 && data[0] == (byte)'%' && data[1] == (byte)'P' && data[2] == (byte)'D' && data[3] == (byte)'F';

    /// <summary>Rend chaque page en PNG à la résolution demandée. À appeler hors du thread de l'interface.</summary>
    public static List<byte[]> RenderPages(byte[] pdf, double dpi, int maxPages = int.MaxValue) =>
        Task.Run(() => RenderAsync(pdf, dpi, maxPages)).GetAwaiter().GetResult();

    private static async Task<List<byte[]>> RenderAsync(byte[] pdf, double dpi, int maxPages)
    {
        using var input = new InMemoryRandomAccessStream();
        await input.WriteAsync(pdf.AsBuffer());
        input.Seek(0);
        var document = await PdfDocument.LoadFromStreamAsync(input);

        var pages = new List<byte[]>((int)document.PageCount);
        for (uint i = 0; i < document.PageCount && i < maxPages; i++)
        {
            using var page = document.GetPage(i);
            // page.Size est en unités indépendantes (1/96 de pouce)
            var options = new PdfPageRenderOptions
            {
                DestinationWidth = (uint)Math.Round(page.Size.Width * dpi / 96.0),
                DestinationHeight = (uint)Math.Round(page.Size.Height * dpi / 96.0)
            };
            using var output = new InMemoryRandomAccessStream();
            await page.RenderToStreamAsync(output, options); // PNG par défaut
            output.Seek(0);
            using var ms = new MemoryStream();
            await output.AsStreamForRead().CopyToAsync(ms);
            pages.Add(ms.ToArray());
        }
        return pages;
    }
}

/// <summary>
/// PDF ouvert une seule fois pour l'aperçu, l'impression et l'export d'images : chaque page est rendue à la demande
/// (jamais toutes en mémoire, important dans le processus 32 bits).
/// </summary>
public sealed class PdfPages : IDisposable
{
    private readonly InMemoryRandomAccessStream _stream;
    private readonly PdfDocument _document;
    private readonly object _gate = new();

    private PdfPages(InMemoryRandomAccessStream stream, PdfDocument document)
    {
        _stream = stream;
        _document = document;
        Count = (int)document.PageCount;
    }

    public int Count { get; }

    public static PdfPages Open(byte[] pdf) => Task.Run(async () =>
    {
        var stream = new InMemoryRandomAccessStream();
        await stream.WriteAsync(pdf.AsBuffer());
        stream.Seek(0);
        var document = await PdfDocument.LoadFromStreamAsync(stream);
        return new PdfPages(stream, document);
    }).GetAwaiter().GetResult();

    /// <summary>Taille de la page en pouces (rotation comprise).</summary>
    public (double Width, double Height) SizeInches(int index)
    {
        lock (_gate)
        {
            using var page = _document.GetPage((uint)index);
            return (page.Size.Width / 96.0, page.Size.Height / 96.0);
        }
    }

    /// <summary>Rend une page en PNG à la résolution demandée. Utilisable depuis n'importe quel thread.</summary>
    public byte[] RenderPng(int index, double dpi)
    {
        lock (_gate)
        {
            return Task.Run(async () =>
            {
                using var page = _document.GetPage((uint)index);
                var options = new PdfPageRenderOptions
                {
                    DestinationWidth = (uint)Math.Max(1, Math.Round(page.Size.Width * dpi / 96.0)),
                    DestinationHeight = (uint)Math.Max(1, Math.Round(page.Size.Height * dpi / 96.0))
                };
                using var output = new InMemoryRandomAccessStream();
                await page.RenderToStreamAsync(output, options);
                output.Seek(0);
                using var ms = new MemoryStream();
                await output.AsStreamForRead().CopyToAsync(ms);
                return ms.ToArray();
            }).GetAwaiter().GetResult();
        }
    }

    public void Dispose() => _stream.Dispose();
}
