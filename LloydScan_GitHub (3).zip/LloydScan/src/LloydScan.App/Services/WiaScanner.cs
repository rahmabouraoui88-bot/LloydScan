using System.Runtime.InteropServices;
using System.Threading.Channels;
using LloydScan.Core.Configuration;
using LloydScan.Core.Processing;

namespace LloydScan.App.Services;

/// <summary>
/// Numérisation via WIA (Windows Image Acquisition), le pilote intégré à Windows.
/// Couvre les scanners sans pilote TWAIN (modèles grand public, multifonctions USB) et fonctionne
/// quel que soit le 32/64 bits de l'application (le service WIA tourne hors processus).
/// Accès par la bibliothèque d'automatisation WIA 2.0 (wiaaut.dll, présente dans Windows) en COM tardif.
/// </summary>
public sealed class WiaScanner
{
    private const string FormatBmp = "{B96B3CAB-0728-11D3-9D7B-0000F81EF32E}";
    private const int ScannerDeviceType = 1;

    // Propriétés WIA
    private const int DeviceName = 7;                 // WIA_DIP_DEV_NAME
    private const int DocumentHandlingSelect = 3088;  // WIA_DPS_DOCUMENT_HANDLING_SELECT
    private const int Pages = 3096;                   // WIA_DPS_PAGES
    private const int CurrentIntent = 6146;           // WIA_IPS_CUR_INTENT
    private const int XResolution = 6147;             // WIA_IPS_XRES
    private const int YResolution = 6148;             // WIA_IPS_YRES

    private const int Feeder = 1, Flatbed = 2, Duplex = 4;
    private const int IntentColor = 1, IntentGray = 2, IntentText = 4;

    // Codes d'erreur WIA
    private const uint PaperEmpty = 0x80210003;
    private const uint PaperJam = 0x80210002;
    private const uint Offline = 0x80210005;
    private const uint Busy = 0x80210006;
    private const uint WarmingUp = 0x80210007;
    private const uint Communication = 0x8021000A;
    private const uint CoverOpen = 0x80210016;

    public static bool IsAvailable => Type.GetTypeFromProgID("WIA.DeviceManager") != null;

    public sealed record WiaDevice(string Id, string Name);

    /// <summary>Liste les scanners WIA (exécuté sur un thread STA, exigé par la bibliothèque COM).</summary>
    public static IReadOnlyList<WiaDevice> GetDevices()
    {
        if (!IsAvailable) return Array.Empty<WiaDevice>();
        return RunSta(() =>
        {
            var list = new List<WiaDevice>();
            dynamic manager = Activator.CreateInstance(Type.GetTypeFromProgID("WIA.DeviceManager")!)!;
            dynamic infos = manager.DeviceInfos;
            int count = infos.Count;
            for (int i = 1; i <= count; i++) // collections WIA indexées à partir de 1
            {
                dynamic info = infos[i];
                if ((int)info.Type != ScannerDeviceType) continue;
                string name = GetProperty(info.Properties, DeviceName) as string ?? (string)info.DeviceID;
                list.Add(new WiaDevice((string)info.DeviceID, name));
            }
            return list;
        });
    }

    /// <summary>Numérise : les pages sont renvoyées au fil de l'eau (chargeur) ; une seule page à plat.</summary>
    public IAsyncEnumerable<ScannedImage> Scan(string deviceId, ScanProfile profile, CancellationToken ct)
    {
        var channel = Channel.CreateUnbounded<ScannedImage>(new UnboundedChannelOptions { SingleReader = true, SingleWriter = true });
        var thread = new Thread(() =>
        {
            try
            {
                ScanLoop(deviceId, profile, channel.Writer, ct);
                channel.Writer.TryComplete();
            }
            catch (Exception ex)
            {
                channel.Writer.TryComplete(ex);
            }
        })
        { IsBackground = true, Name = "WIA" };
        thread.SetApartmentState(ApartmentState.STA);
        thread.Start();
        return channel.Reader.ReadAllAsync(ct);
    }

    private static void ScanLoop(string deviceId, ScanProfile profile, ChannelWriter<ScannedImage> writer, CancellationToken ct)
    {
        dynamic manager = Activator.CreateInstance(Type.GetTypeFromProgID("WIA.DeviceManager")!)!;
        dynamic? device = null;
        dynamic infos = manager.DeviceInfos;
        int count = infos.Count;
        for (int i = 1; i <= count; i++)
        {
            dynamic info = infos[i];
            if ((string)info.DeviceID == deviceId) { device = info.Connect(); break; }
        }
        if (device is null) throw new InvalidOperationException("Scanner WIA introuvable. Est-il allumé et connecté ?");

        // Source : chargeur (+ recto-verso) ou vitre — réglages issus du profil verrouillé uniquement
        bool feeder = profile.UseFeeder;
        int handling = feeder ? Feeder | (profile.Duplex ? Duplex : 0) : Flatbed;
        if (!SetProperty(device.Properties, DocumentHandlingSelect, handling) && feeder && profile.Duplex)
            SetProperty(device.Properties, DocumentHandlingSelect, Feeder); // recto-verso non géré : recto seul
        SetProperty(device.Properties, Pages, 1);

        dynamic item = device.Items[1];
        SetProperty(item.Properties, CurrentIntent, profile.ColorMode switch
        {
            ScanColorMode.Gray => IntentGray,
            ScanColorMode.BlackWhite => IntentText,
            _ => IntentColor
        });
        SetProperty(item.Properties, XResolution, profile.Resolution);
        SetProperty(item.Properties, YResolution, profile.Resolution);

        int page = 0;
        while (!ct.IsCancellationRequested)
        {
            byte[] data;
            try
            {
                dynamic image = item.Transfer(FormatBmp);
                data = (byte[])image.FileData.BinaryData;
            }
            catch (COMException ex) when ((uint)ex.HResult == PaperEmpty)
            {
                break; // fin du lot (ou chargeur vide au démarrage → « aucune page reçue »)
            }
            catch (COMException ex)
            {
                throw new InvalidOperationException(Describe((uint)ex.HResult, page), ex);
            }
            writer.TryWrite(new ScannedImage { Data = data, DpiHint = profile.Resolution, SourceName = $"WIA p{++page}" });
            if (!feeder) break; // vitre : une page par numérisation
        }
    }

    private static string Describe(uint hr, int pagesDone) => hr switch
    {
        PaperJam => $"Bourrage papier après {pagesDone} page(s). Retirer la feuille et relancer à partir de la page suivante.",
        Offline => "Scanner hors ligne : vérifier l'alimentation et le câble.",
        Busy => "Scanner occupé par une autre application.",
        WarmingUp => "Le scanner chauffe : patienter quelques secondes puis relancer.",
        Communication => "Communication interrompue avec le scanner : vérifier le câble USB ou le réseau.",
        CoverOpen => "Capot du scanner ouvert.",
        _ => $"Erreur du scanner WIA (0x{hr:X8}) après {pagesDone} page(s)."
    };

    private static object? GetProperty(dynamic properties, int id)
    {
        int count = properties.Count;
        for (int i = 1; i <= count; i++)
        {
            dynamic p = properties[i];
            if ((int)p.PropertyID == id) return p.Value;
        }
        return null;
    }

    /// <summary>Règle une propriété si le pilote l'expose ; renvoie false si elle est absente ou refusée.</summary>
    private static bool SetProperty(dynamic properties, int id, int value)
    {
        int count = properties.Count;
        for (int i = 1; i <= count; i++)
        {
            dynamic p = properties[i];
            if ((int)p.PropertyID != id) continue;
            try { p.Value = value; return true; }
            catch (COMException) { return false; }
        }
        return false;
    }

    private static T RunSta<T>(Func<T> func)
    {
        T result = default!;
        Exception? error = null;
        var t = new Thread(() =>
        {
            try { result = func(); }
            catch (Exception ex) { error = ex; }
        });
        t.SetApartmentState(ApartmentState.STA);
        t.Start();
        t.Join();
        if (error != null) throw error;
        return result;
    }
}
