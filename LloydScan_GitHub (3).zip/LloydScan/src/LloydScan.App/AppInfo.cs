namespace LloydScan.App;

/// <summary>Nom de l'application affiché aux agents (barre de titre, messages, propriétés du fichier).</summary>
internal static class AppInfo
{
    public const string Name = "NAPS++";
}
