using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using LloydScan.App.Services;

namespace LloydScan.App;

/// <summary>
/// Grand aperçu du document avec zoom : le PDF final, page par page.
/// Molette = défiler · Ctrl + molette = zoom · Page préc./suiv. = changer de page · double-clic = ajuster/100 %.
/// </summary>
public sealed class PreviewWindow : Window
{
    private static readonly double[] RenderSteps = { 100, 150, 200, 300 };

    private readonly PdfPages _pages;
    private readonly Dictionary<(int Page, double Dpi), BitmapSource> _cache = new();
    private readonly ScrollViewer _scroll;
    private readonly Image _image;
    private readonly TextBlock _pageText, _zoomText;
    private int _index;
    private double _zoom = 1;        // 1 = 100 % (taille réelle à l'écran)
    private bool _fitMode = true;
    private int _renderToken;

    public PreviewWindow(byte[] pdf, string title, int startPage = 0)
    {
        _pages = PdfPages.Open(pdf);
        _index = Math.Clamp(startPage, 0, Math.Max(0, _pages.Count - 1));

        Title = $"Aperçu — {title}";
        Width = 1000;
        Height = 860;
        WindowStartupLocation = WindowStartupLocation.CenterOwner;
        FontFamily = new FontFamily("Segoe UI");
        FontSize = 13;

        var bar = new WrapPanel { Margin = new Thickness(8, 6, 8, 6) };
        Button Btn(string text, string tip, Action click)
        {
            var b = new Button { Content = text, ToolTip = tip, MinWidth = 34, Padding = new Thickness(8, 3, 8, 3), Margin = new Thickness(2) };
            b.Click += (_, _) => click();
            bar.Children.Add(b);
            return b;
        }
        Btn("⏮", "Première page", () => GoTo(0));
        Btn("◀", "Page précédente (Page préc.)", () => GoTo(_index - 1));
        _pageText = new TextBlock { VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(8, 0, 8, 0), MinWidth = 90, TextAlignment = TextAlignment.Center };
        bar.Children.Add(_pageText);
        Btn("▶", "Page suivante (Page suiv.)", () => GoTo(_index + 1));
        Btn("⏭", "Dernière page", () => GoTo(_pages.Count - 1));
        bar.Children.Add(new System.Windows.Shapes.Rectangle { Width = 1, Height = 22, Fill = Brushes.LightGray, Margin = new Thickness(10, 2, 10, 2) });
        Btn("−", "Zoom arrière (Ctrl + molette)", () => SetZoom(_zoom / 1.25));
        _zoomText = new TextBlock { VerticalAlignment = VerticalAlignment.Center, MinWidth = 56, TextAlignment = TextAlignment.Center };
        bar.Children.Add(_zoomText);
        Btn("+", "Zoom avant (Ctrl + molette)", () => SetZoom(_zoom * 1.25));
        Btn("Page entière", "Afficher toute la page", Fit);
        Btn("Largeur", "Ajuster à la largeur de la fenêtre", FitWidth);
        Btn("100 %", "Taille réelle", () => SetZoom(1));
        Btn("200 %", "Lire les petits caractères", () => SetZoom(2));

        _image = new Image { Stretch = Stretch.Fill, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
        RenderOptions.SetBitmapScalingMode(_image, BitmapScalingMode.HighQuality);
        var paper = new Border
        {
            Child = _image,
            Background = Brushes.White,
            Margin = new Thickness(16),
            HorizontalAlignment = HorizontalAlignment.Center,
            VerticalAlignment = VerticalAlignment.Center,
            Effect = new System.Windows.Media.Effects.DropShadowEffect { BlurRadius = 8, ShadowDepth = 1, Opacity = 0.35 }
        };
        _scroll = new ScrollViewer
        {
            Content = paper,
            HorizontalScrollBarVisibility = ScrollBarVisibility.Auto,
            VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
            Background = new SolidColorBrush(Color.FromRgb(0x6B, 0x6F, 0x75)),
            Focusable = true
        };
        _scroll.PreviewMouseWheel += OnWheel;
        _scroll.SizeChanged += (_, _) => { if (_fitMode) Fit(); };
        paper.MouseLeftButtonDown += (_, e) =>
        {
            if (e.ClickCount == 2) { if (_fitMode || _zoom < 0.99) SetZoom(1); else Fit(); }
        };

        var hint = new TextBlock
        {
            Text = "Ctrl + molette : zoom · Molette : défiler · Page préc./suiv. : changer de page · Double-clic : page entière / 100 %",
            Foreground = Brushes.DimGray, FontSize = 11, Margin = new Thickness(10, 3, 10, 4)
        };

        var root = new DockPanel();
        DockPanel.SetDock(bar, Dock.Top);
        DockPanel.SetDock(hint, Dock.Bottom);
        root.Children.Add(bar);
        root.Children.Add(hint);
        root.Children.Add(_scroll);
        Content = root;

        PreviewKeyDown += OnKey;
        Loaded += (_, _) => { ShowPage(); _scroll.Focus(); };
        Closed += (_, _) => _pages.Dispose();
    }

    private (double W, double H) PageInches() => _pages.SizeInches(_index);

    private void GoTo(int index)
    {
        index = Math.Clamp(index, 0, _pages.Count - 1);
        if (index == _index && _image.Source != null) return;
        _index = index;
        ShowPage();
        _scroll.ScrollToTop();
        _scroll.ScrollToLeftEnd();
    }

    private void ShowPage()
    {
        _pageText.Text = $"Page {_index + 1} / {_pages.Count}";
        if (_fitMode) Fit(); else ApplyZoom();
    }

    private void Fit()
    {
        var (w, h) = PageInches();
        double vw = Math.Max(100, _scroll.ViewportWidth > 0 ? _scroll.ViewportWidth : _scroll.ActualWidth) - 40;
        double vh = Math.Max(100, _scroll.ViewportHeight > 0 ? _scroll.ViewportHeight : _scroll.ActualHeight) - 40;
        _zoom = Math.Min(vw / (w * 96), vh / (h * 96));
        _fitMode = true;
        ApplyZoom();
    }

    private void FitWidth()
    {
        var (w, _) = PageInches();
        double vw = Math.Max(100, _scroll.ActualWidth) - 60;
        SetZoom(vw / (w * 96));
    }

    private void SetZoom(double zoom)
    {
        _fitMode = false;
        _zoom = Math.Clamp(zoom, 0.1, 6);
        ApplyZoom();
    }

    /// <summary>Redimensionne tout de suite (image existante), puis recharge une image plus fine si le zoom l'exige.</summary>
    private void ApplyZoom()
    {
        var (w, h) = PageInches();
        _image.Width = w * 96 * _zoom;
        _image.Height = h * 96 * _zoom;
        _zoomText.Text = $"{_zoom * 100:0} %";

        double scale = VisualTreeHelper.GetDpi(this).DpiScaleX;
        double wanted = 96 * _zoom * scale;
        double dpi = RenderSteps.FirstOrDefault(s => s >= wanted * 0.9, RenderSteps[^1]);
        _ = RenderAsync(_index, dpi);
    }

    private async Task RenderAsync(int index, double dpi)
    {
        int token = ++_renderToken;
        if (!_cache.TryGetValue((index, dpi), out var bitmap))
        {
            // Image provisoire (autre résolution déjà prête) pendant le rendu
            var any = _cache.Where(kv => kv.Key.Page == index).OrderByDescending(kv => kv.Key.Dpi).Select(kv => kv.Value).FirstOrDefault();
            if (any != null) _image.Source = any;
            try
            {
                bitmap = await Task.Run(() => WicImageCodec.LoadFrozen(_pages.RenderPng(index, dpi)));
            }
            catch (Exception ex)
            {
                if (token == _renderToken) _pageText.Text = $"Page {index + 1} : aperçu impossible ({ex.Message})";
                return;
            }
            // On garde peu d'images en mémoire (processus 32 bits)
            if (_cache.Count >= 6) _cache.Remove(_cache.Keys.First());
            _cache[(index, dpi)] = bitmap;
        }
        if (token == _renderToken && index == _index) _image.Source = bitmap;
    }

    private void OnWheel(object sender, MouseWheelEventArgs e)
    {
        if ((Keyboard.Modifiers & ModifierKeys.Control) == 0) return;
        e.Handled = true;
        SetZoom(e.Delta > 0 ? _zoom * 1.15 : _zoom / 1.15);
    }

    private void OnKey(object sender, KeyEventArgs e)
    {
        switch (e.Key)
        {
            case Key.PageDown: GoTo(_index + 1); e.Handled = true; break;
            case Key.PageUp: GoTo(_index - 1); e.Handled = true; break;
            case Key.Home when Keyboard.Modifiers == ModifierKeys.Control: GoTo(0); e.Handled = true; break;
            case Key.End when Keyboard.Modifiers == ModifierKeys.Control: GoTo(_pages.Count - 1); e.Handled = true; break;
            case Key.Add or Key.OemPlus: SetZoom(_zoom * 1.25); e.Handled = true; break;
            case Key.Subtract or Key.OemMinus: SetZoom(_zoom / 1.25); e.Handled = true; break;
            case Key.Escape: Close(); e.Handled = true; break;
        }
    }
}
