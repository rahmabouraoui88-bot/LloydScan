using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using LloydScan.App.Services;
using LloydScan.Core.Configuration;
using LloydScan.Core.Upload;

namespace LloydScan.App;

/// <summary>
/// Fenêtre « Mes identifiants » : l'agent saisit SES comptes WebDAV (ELISE Lloyd, Lloyd Vie), les teste et les enregistre.
/// Seuls les identifiants sont modifiables ici ; aucun paramètre de numérisation n'est exposé.
/// </summary>
public sealed class CredentialsWindow : Window
{
    private sealed record Row(string Name, WebDavTarget Target, TextBox User, PasswordBox Password, TextBlock Status);

    private readonly AgentCredentialStore _store;
    private readonly List<Row> _rows = new();

    public CredentialsWindow(AppSettings settings, AgentCredentialStore store, string? intro = null)
    {
        _store = store;
        Title = "Mes identifiants WebDAV";
        Width = 540;
        SizeToContent = SizeToContent.Height;
        ResizeMode = ResizeMode.NoResize;
        WindowStartupLocation = WindowStartupLocation.CenterOwner;
        FontFamily = new FontFamily("Segoe UI");
        FontSize = 13;

        var root = new StackPanel { Margin = new Thickness(16) };
        root.Children.Add(new TextBlock
        {
            Text = (intro != null ? intro + "\n\n" : "") +
                   $"Agent : {Environment.UserDomainName}\\{Environment.UserName}\n" +
                   "Saisissez vos comptes personnels. Ils sont chiffrés et utilisables uniquement dans votre session Windows.",
            TextWrapping = TextWrapping.Wrap,
            Margin = new Thickness(0, 0, 0, 12)
        });

        foreach (var (name, target) in settings.Targets.Where(t => t.Value.Authentication == WebDavAuthentication.Agent))
            root.Children.Add(BuildGroup(name, target));

        if (_rows.Count == 0)
            root.Children.Add(new TextBlock
            {
                Text = "Aucune destination ne demande d'identifiant personnel (authentification Windows ou compte de service).",
                TextWrapping = TextWrapping.Wrap
            });

        var buttons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 12, 0, 0) };
        var save = new Button { Content = "Enregistrer", IsDefault = true, MinWidth = 100, Padding = new Thickness(10, 4, 10, 4), Margin = new Thickness(0, 0, 8, 0) };
        var cancel = new Button { Content = "Annuler", IsCancel = true, MinWidth = 90, Padding = new Thickness(10, 4, 10, 4) };
        save.Click += (_, _) => Save();
        buttons.Children.Add(save);
        buttons.Children.Add(cancel);
        root.Children.Add(buttons);
        Content = root;
    }

    private GroupBox BuildGroup(string name, WebDavTarget target)
    {
        var grid = new Grid { Margin = new Thickness(6) };
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(110) });
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        for (int i = 0; i < 3; i++) grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

        var user = new TextBox { Text = _store.GetUsername(name) ?? "", Margin = new Thickness(0, 2, 0, 2), Padding = new Thickness(2) };
        var password = new PasswordBox { Margin = new Thickness(0, 2, 0, 2), Padding = new Thickness(2) };
        var test = new Button { Content = "Tester", Margin = new Thickness(8, 2, 0, 2), Padding = new Thickness(10, 2, 10, 2) };
        var status = new TextBlock { TextWrapping = TextWrapping.Wrap, Foreground = Brushes.Gray, Margin = new Thickness(0, 4, 0, 0) };
        if (!string.IsNullOrEmpty(user.Text))
            status.Text = "Compte enregistré. Laisser le mot de passe vide pour le conserver.";

        void Place(UIElement e, int row, int col, int span = 1)
        {
            Grid.SetRow(e, row); Grid.SetColumn(e, col); Grid.SetColumnSpan(e, span);
            grid.Children.Add(e);
        }
        Place(new TextBlock { Text = "Identifiant", VerticalAlignment = VerticalAlignment.Center }, 0, 0);
        Place(user, 0, 1, 2);
        Place(new TextBlock { Text = "Mot de passe", VerticalAlignment = VerticalAlignment.Center }, 1, 0);
        Place(password, 1, 1);
        Place(test, 1, 2);
        Place(status, 2, 0, 3);

        var row = new Row(name, target, user, password, status);
        _rows.Add(row);
        test.Click += async (_, _) => await TestAsync(row, test);

        return new GroupBox
        {
            Header = $"{target.DisplayName}  —  {target.Url}",
            Content = grid,
            Margin = new Thickness(0, 0, 0, 10),
            Padding = new Thickness(4)
        };
    }

    private WebDavCredential? CredentialFor(Row row)
    {
        var user = row.User.Text.Trim();
        if (user.Length == 0) return null;
        if (row.Password.Password.Length > 0) return new WebDavCredential(user, row.Password.Password);
        // Mot de passe vide : on réutilise celui déjà enregistré pour le même identifiant
        var stored = _store.Get(row.Name, row.Target);
        return stored != null && string.Equals(stored.Username, user, StringComparison.OrdinalIgnoreCase) ? stored : null;
    }

    private async Task TestAsync(Row row, Button button)
    {
        var credential = CredentialFor(row);
        if (credential is null)
        {
            row.Status.Foreground = Brushes.DarkOrange;
            row.Status.Text = "Saisir l'identifiant et le mot de passe.";
            return;
        }
        button.IsEnabled = false;
        row.Status.Foreground = Brushes.Gray;
        row.Status.Text = "Test de connexion en cours…";
        try
        {
            await DocumentSender.TestAsync(row.Target, credential, CancellationToken.None);
            row.Status.Foreground = Brushes.SeaGreen;
            row.Status.Text = "✔ Connexion réussie.";
        }
        catch (Exception ex)
        {
            row.Status.Foreground = Brushes.Firebrick;
            row.Status.Text = "✖ " + ex.Message;
        }
        finally { button.IsEnabled = true; }
    }

    private void Save()
    {
        var missing = new List<string>();
        var toSave = new List<(Row row, WebDavCredential credential)>();
        foreach (var row in _rows)
        {
            if (row.User.Text.Trim().Length == 0) { missing.Add(row.Target.DisplayName); continue; }
            var credential = CredentialFor(row);
            if (credential is null) { missing.Add(row.Target.DisplayName); continue; }
            toSave.Add((row, credential));
        }
        if (missing.Count > 0 &&
            MessageBox.Show(this, $"Identifiants incomplets pour : {string.Join(", ", missing)}.\n" +
                                  "Vous ne pourrez pas envoyer vers ces destinations. Enregistrer quand même ?",
                "Mes identifiants", MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes)
            return;

        foreach (var (row, credential) in toSave) _store.Save(row.Name, credential.Username, credential.Password);
        DialogResult = true;
    }
}
