using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;
using LloydScan.App.Services;
using LloydScan.Core.Imaging;

namespace LloydScan.App;

/// <summary>
/// Fenêtre « Image » : recadrer, luminosité/contraste, teinte/saturation, netteté, noir et blanc.
/// L'aperçu est calculé sur une copie réduite ; à la validation, les retouches sont rejouées à pleine résolution
/// sur la copie de la page numérisée (aucune perte cumulée), puis la page est recompressée.
/// </summary>
public sealed class ImageEditWindow : Window
{
    private readonly Func<RasterImage> _loadPreview;
    private readonly int _rotation;
    private readonly ImageAdjustments _adj;
    private RasterImage? _base;

    private readonly Image _image = new() { Stretch = Stretch.Uniform };
    private readonly Canvas _overlay = new() { Background = Brushes.Transparent, Cursor = Cursors.Cross };
    private readonly TextBlock _status = new() { Foreground = Brushes.DimGray, Margin = new Thickness(0, 6, 0, 0), TextWrapping = TextWrapping.Wrap };
    private readonly DispatcherTimer _debounce = new() { Interval = TimeSpan.FromMilliseconds(140) };
    private Slider _left = null!, _top = null!, _right = null!, _bottom = null!;
    private Slider _brightness = null!, _contrast = null!, _hue = null!, _saturation = null!, _sharpen = null!;
    private CheckBox _auto = null!, _bw = null!;
    private Point? _dragStart;
    private bool _loading = true;
    private int _token;

    /// <summary>Retouches choisies (identité = toutes les retouches retirées).</summary>
    public ImageAdjustments Result => _adj.Clone();

    public ImageEditWindow(Func<RasterImage> loadPreview, ImageAdjustments? current, int rotation, string pageLabel)
    {
        _loadPreview = loadPreview;
        _rotation = ((rotation % 360) + 360) % 360;
        _adj = current?.Clone() ?? new ImageAdjustments();

        Title = $"Image — {pageLabel}";
        Width = 1060;
        Height = 820;
        MinWidth = 820;
        MinHeight = 600;
        WindowStartupLocation = WindowStartupLocation.CenterOwner;
        FontFamily = new FontFamily("Segoe UI");
        FontSize = 13;

        // ----- Aperçu (gauche) -----
        var stage = new Grid { HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
        stage.Children.Add(_image);
        stage.Children.Add(_overlay);
        RenderOptions.SetBitmapScalingMode(_image, BitmapScalingMode.HighQuality);
        var preview = new Border
        {
            Background = new SolidColorBrush(Color.FromRgb(0x6B, 0x6F, 0x75)),
            Padding = new Thickness(14),
            Child = stage
        };
        _overlay.SizeChanged += (_, _) => DrawCrop();
        _overlay.MouseLeftButtonDown += StartDrag;
        _overlay.MouseMove += Drag;
        _overlay.MouseLeftButtonUp += EndDrag;

        // ----- Réglages (droite) -----
        var panel = new StackPanel { Margin = new Thickness(12, 4, 4, 4) };

        var crop = new StackPanel();
        crop.Children.Add(new TextBlock
        {
            Text = "Tracez un cadre sur l'image avec la souris, ou réglez chaque bord :",
            TextWrapping = TextWrapping.Wrap, Foreground = Brushes.DimGray, Margin = new Thickness(0, 0, 0, 4)
        });
        var (l, t, r, b) = _adj.DisplayCrop(_rotation);
        _left = AddSlider(crop, "Gauche", 0, 45, l * 100, "%");
        _top = AddSlider(crop, "Haut", 0, 45, t * 100, "%");
        _right = AddSlider(crop, "Droite", 0, 45, r * 100, "%");
        _bottom = AddSlider(crop, "Bas", 0, 45, b * 100, "%");
        var noCrop = SmallButton("Sans recadrage", () => { foreach (var s in new[] { _left, _top, _right, _bottom }) s.Value = 0; });
        crop.Children.Add(noCrop);
        panel.Children.Add(new GroupBox { Header = "Recadrer", Content = crop, Padding = new Thickness(6), Margin = new Thickness(0, 0, 0, 8) });

        var color = new StackPanel();
        _auto = new CheckBox { Content = "Niveaux automatiques (blanc bien blanc, noir bien noir)", IsChecked = _adj.AutoLevels, Margin = new Thickness(0, 0, 0, 6) };
        _auto.Checked += (_, _) => Changed();
        _auto.Unchecked += (_, _) => Changed();
        color.Children.Add(_auto);
        _brightness = AddSlider(color, "Luminosité", -100, 100, _adj.Brightness, "");
        _contrast = AddSlider(color, "Contraste", -100, 100, _adj.Contrast, "");
        _hue = AddSlider(color, "Teinte", -180, 180, _adj.Hue, "°");
        _saturation = AddSlider(color, "Saturation", -100, 100, _adj.Saturation, "");
        _sharpen = AddSlider(color, "Netteté", 0, 100, _adj.Sharpen, "");
        _bw = new CheckBox { Content = "Noir et blanc (texte net, fichier très léger)", IsChecked = _adj.BlackWhite, Margin = new Thickness(0, 6, 0, 0) };
        _bw.Checked += (_, _) => Changed();
        _bw.Unchecked += (_, _) => Changed();
        color.Children.Add(_bw);
        panel.Children.Add(new GroupBox { Header = "Couleurs et netteté", Content = color, Padding = new Thickness(6) });

        panel.Children.Add(new TextBlock
        {
            Text = "Astuce : double-clic sur un curseur = remise à zéro.",
            Foreground = Brushes.DimGray, FontSize = 11, Margin = new Thickness(0, 6, 0, 0)
        });
        panel.Children.Add(_status);

        var buttons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 10, 0, 0) };
        var reset = new Button { Content = "Tout réinitialiser", Padding = new Thickness(10, 4, 10, 4), Margin = new Thickness(0, 0, 8, 0) };
        reset.Click += (_, _) => ResetAll();
        var ok = new Button { Content = "Appliquer", IsDefault = true, MinWidth = 100, Padding = new Thickness(10, 4, 10, 4), Margin = new Thickness(0, 0, 8, 0) };
        ok.Click += (_, _) => { Collect(); DialogResult = true; };
        var cancel = new Button { Content = "Annuler", IsCancel = true, MinWidth = 90, Padding = new Thickness(10, 4, 10, 4) };
        buttons.Children.Add(reset);
        buttons.Children.Add(ok);
        buttons.Children.Add(cancel);
        panel.Children.Add(buttons);

        var side = new ScrollViewer { Content = panel, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Width = 360 };
        var root = new DockPanel();
        DockPanel.SetDock(side, Dock.Right);
        root.Children.Add(side);
        root.Children.Add(preview);
        Content = root;

        _debounce.Tick += (_, _) => { _debounce.Stop(); _ = RefreshAsync(); };
        Loaded += async (_, _) => await LoadAsync();
    }

    private Slider AddSlider(Panel parent, string label, double min, double max, double value, string unit)
    {
        var grid = new Grid { Margin = new Thickness(0, 2, 0, 2) };
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(78) });
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(48) });
        var text = new TextBlock { Text = label, VerticalAlignment = VerticalAlignment.Center };
        var slider = new Slider
        {
            Minimum = min, Maximum = max, Value = Math.Round(value), IsSnapToTickEnabled = true, TickFrequency = 1,
            SmallChange = 1, LargeChange = 10, VerticalAlignment = VerticalAlignment.Center,
            AutoToolTipPlacement = AutoToolTipPlacement.TopLeft
        };
        var shown = new TextBlock { VerticalAlignment = VerticalAlignment.Center, TextAlignment = TextAlignment.Right };
        void UpdateText() => shown.Text = $"{slider.Value:+0;-0;0}{unit}".Replace("+", min < 0 ? "+" : "");
        UpdateText();
        slider.ValueChanged += (_, _) => { UpdateText(); Changed(); };
        slider.MouseDoubleClick += (_, _) => slider.Value = 0;
        Grid.SetColumn(slider, 1);
        Grid.SetColumn(shown, 2);
        grid.Children.Add(text);
        grid.Children.Add(slider);
        grid.Children.Add(shown);
        parent.Children.Add(grid);
        return slider;
    }

    private static Button SmallButton(string text, Action click)
    {
        var b = new Button { Content = text, HorizontalAlignment = HorizontalAlignment.Left, Padding = new Thickness(8, 2, 8, 2), Margin = new Thickness(0, 4, 0, 0) };
        b.Click += (_, _) => click();
        return b;
    }

    private async Task LoadAsync()
    {
        _status.Text = "Chargement de la page…";
        try
        {
            _base = await Task.Run(_loadPreview);
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Retouche impossible", MessageBoxButton.OK, MessageBoxImage.Information);
            DialogResult = false;
            return;
        }
        if (_base.IsGray)
        {
            _hue.IsEnabled = _saturation.IsEnabled = false;
            _hue.ToolTip = _saturation.ToolTip = "Page en niveaux de gris : pas de couleur à régler.";
        }
        _loading = false;
        await RefreshAsync();
    }

    private void Changed()
    {
        if (_loading) return;
        DrawCrop();
        _debounce.Stop();
        _debounce.Start();
    }

    private void Collect()
    {
        _adj.SetDisplayCrop(_rotation, _left.Value / 100, _top.Value / 100, _right.Value / 100, _bottom.Value / 100);
        _adj.AutoLevels = _auto.IsChecked == true;
        _adj.Brightness = (int)_brightness.Value;
        _adj.Contrast = (int)_contrast.Value;
        _adj.Hue = (int)_hue.Value;
        _adj.Saturation = (int)_saturation.Value;
        _adj.Sharpen = (int)_sharpen.Value;
        _adj.BlackWhite = _bw.IsChecked == true;
    }

    private void ResetAll()
    {
        _loading = true;
        foreach (var s in new[] { _left, _top, _right, _bottom, _brightness, _contrast, _hue, _saturation, _sharpen }) s.Value = 0;
        _auto.IsChecked = _bw.IsChecked = false;
        _loading = false;
        Changed();
    }

    /// <summary>Recalcule l'aperçu (sans le recadrage, affiché en grisé par-dessus pour rester ajustable).</summary>
    private async Task RefreshAsync()
    {
        if (_base == null) return;
        Collect();
        var colors = _adj.Clone();
        colors.CropLeft = colors.CropTop = colors.CropRight = colors.CropBottom = 0;
        int token = ++_token;
        _status.Text = "Calcul de l'aperçu…";
        var src = _base;
        var bitmap = await Task.Run(() =>
        {
            var img = colors.IsIdentity ? src : ImageAdjust.Apply(src, colors);
            BitmapSource bmp = WicImageCodec.ToBitmapSource(img);
            if (_rotation != 0) bmp = new TransformedBitmap(bmp, new RotateTransform(_rotation));
            bmp.Freeze();
            return bmp;
        });
        if (token != _token) return;
        _image.Source = bitmap;
        DrawCrop();
        Collect();
        _status.Text = _adj.IsIdentity ? "Aucune retouche." : $"Retouches : {_adj}.";
    }

    // ------------------------------------------------------------------ recadrage à la souris

    private void DrawCrop()
    {
        _overlay.Children.Clear();
        double w = _overlay.ActualWidth, h = _overlay.ActualHeight;
        if (w <= 0 || h <= 0) return;
        double x0 = w * _left.Value / 100, x1 = w * (1 - _right.Value / 100);
        double y0 = h * _top.Value / 100, y1 = h * (1 - _bottom.Value / 100);
        var shade = new SolidColorBrush(Color.FromArgb(150, 0, 0, 0));
        void Box(double x, double y, double bw, double bh)
        {
            if (bw <= 0 || bh <= 0) return;
            var rect = new Rectangle { Width = bw, Height = bh, Fill = shade, IsHitTestVisible = false };
            Canvas.SetLeft(rect, x); Canvas.SetTop(rect, y);
            _overlay.Children.Add(rect);
        }
        Box(0, 0, w, y0);
        Box(0, y1, w, h - y1);
        Box(0, y0, x0, y1 - y0);
        Box(x1, y0, w - x1, y1 - y0);
        if (_left.Value + _top.Value + _right.Value + _bottom.Value > 0)
        {
            var frame = new Rectangle
            {
                Width = Math.Max(1, x1 - x0), Height = Math.Max(1, y1 - y0), Stroke = Brushes.DeepSkyBlue,
                StrokeThickness = 2, StrokeDashArray = new DoubleCollection { 4, 3 }, IsHitTestVisible = false
            };
            Canvas.SetLeft(frame, x0); Canvas.SetTop(frame, y0);
            _overlay.Children.Add(frame);
        }
    }

    private void StartDrag(object sender, MouseButtonEventArgs e)
    {
        if (_base == null) return;
        _dragStart = e.GetPosition(_overlay);
        _overlay.CaptureMouse();
    }

    private void Drag(object sender, MouseEventArgs e)
    {
        if (_dragStart is not Point start || e.LeftButton != MouseButtonState.Pressed) return;
        var p = e.GetPosition(_overlay);
        double w = _overlay.ActualWidth, h = _overlay.ActualHeight;
        if (Math.Abs(p.X - start.X) < 8 || Math.Abs(p.Y - start.Y) < 8) return;
        double x0 = Math.Clamp(Math.Min(start.X, p.X), 0, w), x1 = Math.Clamp(Math.Max(start.X, p.X), 0, w);
        double y0 = Math.Clamp(Math.Min(start.Y, p.Y), 0, h), y1 = Math.Clamp(Math.Max(start.Y, p.Y), 0, h);
        _loading = true; // une seule mise à jour pour les quatre bords
        _left.Value = Math.Min(45, Math.Round(100 * x0 / w));
        _right.Value = Math.Min(45, Math.Round(100 * (w - x1) / w));
        _top.Value = Math.Min(45, Math.Round(100 * y0 / h));
        _bottom.Value = Math.Min(45, Math.Round(100 * (h - y1) / h));
        _loading = false;
        DrawCrop();
    }

    private void EndDrag(object sender, MouseButtonEventArgs e)
    {
        _dragStart = null;
        _overlay.ReleaseMouseCapture();
        Collect();
        _status.Text = _adj.IsIdentity ? "Aucune retouche." : $"Retouches : {_adj}.";
    }
}
