using System.Diagnostics;
using System.Text.Json;
using LloydScan.Core.Imaging;

namespace LloydScan.Core.Pdf;

public enum PdfKind
{
    /// <summary>PDF produit par un logiciel (texte, vectoriel) : à conserver, optimisé sans perte.</summary>
    Native,
    /// <summary>PDF de scanner ou de copieur (une image par page) : à traiter comme une numérisation (MRC).</summary>
    Scanned,
    /// <summary>PDF protégé par mot de passe ou endommagé : transmis tel quel.</summary>
    Unreadable
}

/// <summary>Outils PDF : classification natif / scanné, optimisation sans perte, vignette.</summary>
public interface IPdfTool
{
    bool IsAvailable { get; }
    (PdfKind kind, int pages) Classify(byte[] pdf);
    /// <summary>Optimisation sans perte ; renvoie l'original si le résultat n'est pas plus petit.</summary>
    byte[] OptimizeLossless(byte[] pdf);
    RasterImage? RenderThumbnail(byte[] pdf, int width);
    /// <summary>Place les pages de <paramref name="first"/> devant celles de <paramref name="rest"/>, sans recompression ; null si impossible.</summary>
    byte[]? Prepend(byte[] first, byte[] rest) => null;
}

/// <summary>
/// Implémentation basée sur qpdf (Apache 2.0, livré dans tools\qpdf) :
/// regroupe les objets en flux compressés et recompresse au niveau maximal, sans toucher au contenu
/// (texte, polices, images et rendu identiques au pixel près).
/// </summary>
public class QpdfTool : IPdfTool
{
    private readonly string _exe;

    public QpdfTool(string executablePath) => _exe = executablePath;

    public bool IsAvailable
    {
        get
        {
            if (Path.IsPathRooted(_exe)) return File.Exists(_exe);
            try { return Run(new[] { "--version" }, null, out _) == 0; } catch { return false; }
        }
    }

    public (PdfKind kind, int pages) Classify(byte[] pdf)
    {
        var input = Temp(pdf);
        try
        {
            int code = Run(new[] { "--json=2", "--json-key=pages", input }, null, out var json);
            if (code is not (0 or 3) || string.IsNullOrWhiteSpace(json)) return (PdfKind.Unreadable, 0);
            using var doc = JsonDocument.Parse(json);
            var pages = doc.RootElement.GetProperty("pages");
            int total = 0, scanned = 0;
            foreach (var page in pages.EnumerateArray())
            {
                total++;
                foreach (var img in page.GetProperty("images").EnumerateArray())
                {
                    double w = img.GetProperty("width").GetDouble(), h = img.GetProperty("height").GetDouble();
                    double ratio = h / Math.Max(1, w);
                    // Image couvrant une page à ≥ ~100 dpi (A4 : 827 × 1169) : page numérisée
                    if (w * h >= 900_000 && ratio is > 0.55 and < 1.8) { scanned++; break; }
                }
            }
            if (total == 0) return (PdfKind.Unreadable, 0);
            return (scanned * 2 >= total ? PdfKind.Scanned : PdfKind.Native, total);
        }
        catch { return (PdfKind.Unreadable, 0); }
        finally { TryDelete(input); }
    }

    public byte[] OptimizeLossless(byte[] pdf)
    {
        var input = Temp(pdf);
        var output = input + ".opt.pdf";
        try
        {
            int code = Run(new[] { "--object-streams=generate", "--compress-streams=y", "--recompress-flate",
                                   "--compression-level=9", "--warning-exit-0", input, output }, null, out _);
            if (code != 0 || !File.Exists(output)) return pdf;
            var optimized = File.ReadAllBytes(output);
            return optimized.Length > 0 && optimized.Length < pdf.Length ? optimized : pdf;
        }
        catch { return pdf; }
        finally { TryDelete(input); TryDelete(output); }
    }

    public byte[]? Prepend(byte[] first, byte[] rest)
    {
        var a = Temp(first); var b = Temp(rest); var output = b + ".merge.pdf";
        try
        {
            // Le PDF natif reste le fichier principal (métadonnées conservées) ; la fiche séparatrice passe en page 1
            int code = Run(new[] { "--warning-exit-0", b, "--pages", a, b, "--", "--object-streams=generate", output }, null, out _);
            return code == 0 && File.Exists(output) ? File.ReadAllBytes(output) : null;
        }
        catch { return null; }
        finally { TryDelete(a); TryDelete(b); TryDelete(output); }
    }

    /// <summary>La vignette nécessite un moteur de rendu (fourni par l'application Windows).</summary>
    public virtual RasterImage? RenderThumbnail(byte[] pdf, int width) => null;

    private int Run(string[] args, string? stdin, out string stdout)
    {
        var psi = new ProcessStartInfo(_exe)
        {
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            UseShellExecute = false,
            CreateNoWindow = true
        };
        foreach (var a in args) psi.ArgumentList.Add(a);
        using var p = Process.Start(psi) ?? throw new InvalidOperationException("qpdf introuvable");
        var outTask = p.StandardOutput.ReadToEndAsync();
        var errTask = p.StandardError.ReadToEndAsync();
        if (!p.WaitForExit(120_000)) { try { p.Kill(true); } catch { } throw new TimeoutException("qpdf : délai dépassé"); }
        stdout = outTask.GetAwaiter().GetResult();
        _ = errTask.GetAwaiter().GetResult();
        return p.ExitCode;
    }

    private static string Temp(byte[] data)
    {
        var path = Path.Combine(Path.GetTempPath(), $"lloydscan-{Guid.NewGuid():N}.pdf");
        File.WriteAllBytes(path, data);
        return path;
    }

    private static void TryDelete(string path) { try { if (File.Exists(path)) File.Delete(path); } catch { } }
}
