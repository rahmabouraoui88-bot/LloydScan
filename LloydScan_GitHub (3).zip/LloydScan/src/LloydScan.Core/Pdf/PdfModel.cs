namespace LloydScan.Core.Pdf;

public enum PdfImageKind
{
    /// <summary>Image JPEG (DCTDecode), couleur ou grise.</summary>
    Jpeg,
    /// <summary>Image 1 bit opaque (noir sur blanc).</summary>
    Bilevel,
    /// <summary>Masque 1 bit : peint la couleur courante (ou sert de /Mask à une autre image).</summary>
    StencilMask
}

/// <summary>Image déjà compressée, prête à être insérée telle quelle dans le PDF.</summary>
public sealed class PdfImage
{
    public PdfImageKind Kind { get; init; }
    public int Width { get; init; }
    public int Height { get; init; }
    /// <summary>1 ou 3 (Jpeg uniquement).</summary>
    public int Components { get; init; } = 1;
    /// <summary>"DCTDecode", "FlateDecode" ou "CCITTFaxDecode".</summary>
    public string Filter { get; init; } = "DCTDecode";
    public byte[] Data { get; init; } = Array.Empty<byte>();
}

/// <summary>Une couche de la page, dessinée sur toute la surface.</summary>
public sealed class PdfLayer
{
    public PdfImage Image { get; init; } = null!;
    /// <summary>Masque explicite : seules les zones d'encre de l'image sont peintes (couche avant-plan MRC).</summary>
    public PdfImage? Mask { get; init; }
    /// <summary>Couleur de remplissage d'un StencilMask (RGB 0..1).</summary>
    public (double R, double G, double B) FillColor { get; init; } = (0, 0, 0);
}

/// <summary>Page optimisée : quelques couches compressées (quelques dizaines de Ko).</summary>
public sealed class OptimizedPage
{
    public double WidthPt { get; init; }
    public double HeightPt { get; init; }
    /// <summary>Rotation d'affichage (0, 90, 180, 270, sens horaire) : appliquée sans recompression (/Rotate).</summary>
    public int Rotation { get; set; }
    public List<PdfLayer> Layers { get; } = new();
    /// <summary>Texte reconnu (OCR), écrit en texte invisible au-dessus des images.</summary>
    public List<Ocr.OcrWord> Text { get; } = new();
    /// <summary>Description courte de la stratégie appliquée (affichée et journalisée).</summary>
    public string Strategy { get; init; } = "";

    public long EncodedBytes => Layers.Sum(l => (long)l.Image.Data.Length + (l.Mask?.Data.Length ?? 0));
}

public sealed class PdfMetadata
{
    public string? Title { get; init; }
    public string? Author { get; init; }
    public string? Subject { get; init; }
    public string? Keywords { get; init; }
    public string Creator { get; init; } = "NAPS++";
    /// <summary>Produit un PDF/A-2b (métadonnées XMP + profil de couleur sRGB).</summary>
    public bool PdfA { get; init; }
    public DateTimeOffset CreationDate { get; init; } = DateTimeOffset.Now;
    /// <summary>Entrées personnalisées du dictionnaire Info (exploitables pour l'indexation GED).</summary>
    public Dictionary<string, string> Custom { get; } = new();
}
