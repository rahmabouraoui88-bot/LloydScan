using System.Diagnostics;
using System.Globalization;
using System.Text;
using LloydScan.Core.Imaging;

namespace LloydScan.Core.Ocr;

/// <summary>Mot reconnu, en points PDF (origine en bas à gauche de la page).</summary>
public sealed record OcrWord(string Text, double X, double Y, double Width, double Height, double Confidence);

public interface IOcrEngine
{
    bool IsAvailable { get; }
    /// <summary>Reconnaît le texte d'une page ; coordonnées converties en points PDF.</summary>
    IReadOnlyList<OcrWord> Recognize(RasterImage page);
}

/// <summary>
/// OCR par Tesseract (Apache 2.0), appelé en ligne de commande (sortie TSV : un mot par ligne avec sa position).
/// Langues par défaut : français + arabe (exigence ENF-06 de la spécification GED ELISE).
/// </summary>
public sealed class TesseractOcr : IOcrEngine
{
    private readonly string _exe;
    private readonly string _languages;
    private readonly string? _tessdata;
    private readonly double _minConfidence;

    public TesseractOcr(string executablePath, string languages, string? tessdataPath, double minConfidence)
    {
        _exe = executablePath;
        _languages = languages;
        _tessdata = tessdataPath;
        _minConfidence = minConfidence;
    }

    public bool IsAvailable
    {
        get
        {
            try
            {
                if (Path.IsPathRooted(_exe) && !File.Exists(_exe)) return false;
                var psi = new ProcessStartInfo(_exe) { RedirectStandardOutput = true, RedirectStandardError = true, UseShellExecute = false, CreateNoWindow = true };
                psi.ArgumentList.Add("--version");
                using var p = Process.Start(psi);
                if (p == null) return false;
                p.StandardOutput.ReadToEnd(); p.StandardError.ReadToEnd();
                p.WaitForExit(10_000);
                return p.ExitCode == 0;
            }
            catch { return false; }
        }
    }

    public IReadOnlyList<OcrWord> Recognize(RasterImage page)
    {
        // Tesseract travaille au mieux autour de 300 dpi, en niveaux de gris
        var gray = ImageOps.ToGray(ImageOps.ScaleToDpi(page, 300));
        var basePath = Path.Combine(Path.GetTempPath(), $"lloydscan-ocr-{Guid.NewGuid():N}");
        var input = basePath + ".pgm";
        try
        {
            using (var fs = File.Create(input))
            {
                var header = Encoding.ASCII.GetBytes($"P5\n{gray.Width} {gray.Height}\n255\n");
                fs.Write(header);
                fs.Write(gray.Pixels, 0, gray.Width * gray.Height);
            }
            var psi = new ProcessStartInfo(_exe)
            {
                RedirectStandardOutput = true, RedirectStandardError = true, UseShellExecute = false, CreateNoWindow = true,
                StandardOutputEncoding = Encoding.UTF8
            };
            foreach (var a in new[] { input, "stdout", "-l", _languages, "--dpi", ((int)Math.Round(gray.Dpi)).ToString(CultureInfo.InvariantCulture), "--psm", "3",
                                   "-c", "tessedit_create_txt=0", "-c", "tessedit_create_tsv=1" })
                psi.ArgumentList.Add(a);
            if (!string.IsNullOrEmpty(_tessdata)) psi.Environment["TESSDATA_PREFIX"] = _tessdata;
            psi.Environment["OMP_THREAD_LIMIT"] = "1"; // les pages sont déjà traitées en parallèle

            using var p = Process.Start(psi) ?? throw new InvalidOperationException("Tesseract introuvable");
            var stdout = p.StandardOutput.ReadToEndAsync();
            var stderr = p.StandardError.ReadToEndAsync();
            if (!p.WaitForExit(180_000)) { try { p.Kill(true); } catch { } throw new TimeoutException("OCR : délai dépassé"); }
            if (p.ExitCode != 0) throw new InvalidOperationException("OCR en échec : " + stderr.Result.Trim());
            return ParseTsv(stdout.Result, gray.Height, 72.0 / gray.Dpi, _minConfidence);
        }
        finally
        {
            try { File.Delete(input); } catch { }
        }
    }

    /// <summary>TSV Tesseract : level page_num block_num par_num line_num word_num left top width height conf text.</summary>
    public static List<OcrWord> ParseTsv(string tsv, int imageHeight, double ptPerPixel, double minConfidence)
    {
        var words = new List<OcrWord>();
        foreach (var line in tsv.Split('\n'))
        {
            var f = line.TrimEnd('\r').Split('\t');
            if (f.Length < 12 || f[0] != "5") continue; // niveau 5 = mot
            var text = f[11].Trim();
            if (text.Length == 0) continue;
            if (!double.TryParse(f[10], NumberStyles.Float, CultureInfo.InvariantCulture, out var conf) || conf < minConfidence) continue;
            int left = int.Parse(f[6], CultureInfo.InvariantCulture), top = int.Parse(f[7], CultureInfo.InvariantCulture);
            int w = int.Parse(f[8], CultureInfo.InvariantCulture), h = int.Parse(f[9], CultureInfo.InvariantCulture);
            if (w <= 0 || h <= 0) continue;
            words.Add(new OcrWord(text,
                X: left * ptPerPixel,
                Y: (imageHeight - top - h) * ptPerPixel,
                Width: w * ptPerPixel,
                Height: h * ptPerPixel,
                Confidence: conf));
        }
        return words;
    }
}
