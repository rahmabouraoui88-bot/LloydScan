using System.Text.RegularExpressions;
using LloydScan.Core.Configuration;

namespace LloydScan.Core.Routing;

public sealed record RoutingDecision(string Target, string Reason, bool NeedsAttention);

/// <summary>
/// Règle métier : si le QR de la page séparatrice contient « VIE » → WebDAV Vie, sinon → WebDAV Lloyd.
/// </summary>
public sealed class RoutingRule
{
    private readonly RoutingSettings _s;
    private readonly Regex _matcher;

    public RoutingRule(RoutingSettings settings)
    {
        _s = settings;
        var opts = RegexOptions.CultureInvariant | (settings.IgnoreCase ? RegexOptions.IgnoreCase : RegexOptions.None);
        string pattern = settings.MatchMode switch
        {
            KeywordMatchMode.Regex => settings.VieKeyword,
            // « mot entier » : non entouré de lettres/chiffres (VIE dans ENTITE=VIE, pas dans SERVIETTE)
            KeywordMatchMode.WholeWord => $@"(?<![\p{{L}}\p{{N}}]){Regex.Escape(settings.VieKeyword)}(?![\p{{L}}\p{{N}}])",
            _ => Regex.Escape(settings.VieKeyword)
        };
        _matcher = new Regex(pattern, opts, TimeSpan.FromMilliseconds(200));
    }

    public RoutingDecision Decide(string? qrText)
    {
        if (qrText is null)
            return new RoutingDecision(_s.NoSeparatorTarget,
                "Pages numérisées sans page séparatrice : destination par défaut, à vérifier", true);

        return _matcher.IsMatch(qrText)
            ? new RoutingDecision(_s.VieTarget, $"QR contient « {_s.VieKeyword} »", false)
            : new RoutingDecision(_s.DefaultTarget, $"QR sans « {_s.VieKeyword} »", false);
    }
}
