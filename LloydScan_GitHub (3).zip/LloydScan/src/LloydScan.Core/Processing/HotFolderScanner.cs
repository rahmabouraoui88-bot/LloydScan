using LloydScan.Core.Configuration;

namespace LloydScan.Core.Processing;

/// <summary>
/// Repère les fichiers complets d'un dossier surveillé et les archive après traitement.
/// Fonctionne par scrutation (plus fiable que les notifications sur les partages réseau).
/// </summary>
public sealed class HotFolderScanner
{
    public static readonly string[] Extensions = { ".pdf", ".tif", ".tiff", ".jpg", ".jpeg", ".png", ".bmp" };

    private readonly HotFolderSettings _settings;

    public HotFolderScanner(HotFolderSettings settings) => _settings = settings;

    public HotFolderSettings Settings => _settings;
    public string Folder => _settings.ResolvePath();
    public string ProcessedFolder => Path.Combine(Folder, "Traites");
    public string ErrorFolder => Path.Combine(Folder, "Erreurs");

    /// <summary>Fichiers prêts : extension reconnue, plus modifiés depuis SettleSeconds, non verrouillés par le copieur.</summary>
    public List<string> FindReadyFiles(DateTime? nowUtc = null)
    {
        var now = nowUtc ?? DateTime.UtcNow;
        var dir = Folder;
        if (!Directory.Exists(dir)) return new List<string>();
        var ready = new List<string>();
        foreach (var file in Directory.EnumerateFiles(dir).OrderBy(f => File.GetLastWriteTimeUtc(f)))
        {
            if (!Extensions.Contains(Path.GetExtension(file), StringComparer.OrdinalIgnoreCase)) continue;
            var info = new FileInfo(file);
            if (info.Length == 0 || (now - info.LastWriteTimeUtc).TotalSeconds < _settings.SettleSeconds) continue;
            if (IsLocked(file)) continue;
            ready.Add(file);
        }
        return ready;
    }

    private static bool IsLocked(string file)
    {
        try
        {
            using var fs = new FileStream(file, FileMode.Open, FileAccess.Read, FileShare.None);
            return false;
        }
        catch (IOException) { return true; }
        catch (UnauthorizedAccessException) { return true; }
    }

    /// <summary>Déplace le fichier source vers Traites\AAAA-MM-JJ ou Erreurs (avec un nom unique).</summary>
    public string Archive(string file, bool success)
    {
        var target = Path.Combine(success ? ProcessedFolder : ErrorFolder, DateTime.Now.ToString("yyyy-MM-dd"));
        Directory.CreateDirectory(target);
        var dest = Path.Combine(target, Path.GetFileName(file));
        if (File.Exists(dest))
            dest = Path.Combine(target, $"{Path.GetFileNameWithoutExtension(file)}_{DateTime.Now:HHmmssfff}{Path.GetExtension(file)}");
        File.Move(file, dest);
        return dest;
    }
}
