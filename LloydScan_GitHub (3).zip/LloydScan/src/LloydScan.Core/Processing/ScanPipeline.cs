using System.Text.RegularExpressions;
using LloydScan.Core.Configuration;
using LloydScan.Core.Imaging;
using LloydScan.Core.Ocr;
using LloydScan.Core.Pdf;
using LloydScan.Core.Routing;

namespace LloydScan.Core.Processing;

/// <summary>
/// Chaîne de traitement d'un lot :
/// réception page à page → détection QR / page blanche → optimisation immédiate (mémoire maîtrisée)
/// → découpe en documents sur les pages séparatrices → routage Vie / Lloyd → génération des PDF.
/// </summary>
public sealed class ScanPipeline
{
    private readonly AppSettings _settings;
    private readonly IImageCodec _codec;
    private readonly IQrDecoder _qr;
    private readonly PageOptimizer _optimizer;
    private readonly RoutingRule _routing;
    private readonly Regex? _separatorPattern;
    private readonly string _sourceFolder;
    private readonly IPdfTool? _pdf;
    private readonly IOcrEngine? _ocr;
    private readonly Lazy<bool> _ocrReady;

    public ScanPipeline(AppSettings settings, IImageCodec codec, IQrDecoder qr, IPdfTool? pdfTool = null, IOcrEngine? ocr = null)
    {
        _pdf = pdfTool;
        _ocr = ocr;
        _ocrReady = new Lazy<bool>(() => settings.Ocr.Enabled && _ocr is { IsAvailable: true });
        _settings = settings;
        _codec = codec;
        _qr = qr;
        _optimizer = new PageOptimizer(codec);
        _routing = new RoutingRule(settings.Routing);
        _sourceFolder = Path.Combine(settings.Storage.ResolveWorkFolder(), "Travail");
        if (!string.IsNullOrWhiteSpace(settings.Separator.Pattern))
            _separatorPattern = new Regex(settings.Separator.Pattern,
                RegexOptions.IgnoreCase | RegexOptions.CultureInvariant, TimeSpan.FromMilliseconds(200));
    }

    public async Task<BatchResult> ProcessAsync(IAsyncEnumerable<ScannedImage> source, ScanProfile profile,
        IProgress<string>? progress = null, CancellationToken ct = default)
    {
        var started = DateTimeOffset.Now;
        var batch = new BatchResult
        {
            BatchId = $"{started:yyyyMMdd-HHmmss}-{Environment.MachineName}",
            StartedAt = started,
            ProfileName = profile.Name
        };

        // Traitement en parallèle borné : chaque page est réduite à quelques dizaines de Ko dès sa réception.
        int parallel = _settings.MaxParallelPages > 0
            ? _settings.MaxParallelPages
            : Math.Clamp(Environment.ProcessorCount / 2, 1, Environment.Is64BitProcess ? 4 : 2); // 32 bits : mémoire limitée
        using var gate = new SemaphoreSlim(parallel);
        var tasks = new List<Task<List<ProcessedPage>>>();
        int received = 0, done = 0;

        await foreach (var image in source.WithCancellation(ct))
        {
            await gate.WaitAsync(ct);
            int n = ++received;
            progress?.Report($"Page {n} reçue…");
            tasks.Add(Task.Run(() =>
            {
                try { return ProcessImage(image, profile); }
                finally
                {
                    gate.Release();
                    progress?.Report($"Pages traitées : {Interlocked.Increment(ref done)} / {received}");
                }
            }, ct));
        }

        var pages = (await Task.WhenAll(tasks)).SelectMany(p => p).ToList();
        for (int i = 0; i < pages.Count; i++) pages[i].Index = i + 1;
        batch.TotalPages = pages.Count;

        Split(pages, batch);

        // Profil à destination imposée (ex. « Enregistrer sur mon PC ») : remplace la règle VIE / Lloyd
        if (!string.IsNullOrWhiteSpace(profile.Target) && _settings.Targets.TryGetValue(profile.Target, out var forced))
            foreach (var doc in batch.Documents)
            {
                doc.RoutedTarget ??= doc.Target;
                doc.Target = profile.Target;
                doc.RoutingReason = $"Profil « {profile.Name} » : enregistrement dans {forced.DisplayName}";
                doc.Warnings.RemoveAll(w => w.StartsWith("Pages numérisées sans page séparatrice", StringComparison.Ordinal));
            }

        foreach (var doc in batch.Documents)
        {
            ct.ThrowIfCancellationRequested();
            BuildPdf(doc, batch, doc.Sequence);
        }
        progress?.Report($"{batch.Documents.Count} document(s) prêt(s) — {batch.TotalPages} page(s) lue(s), " +
                         $"{batch.BlankPagesRemoved} blanche(s) retirée(s).");
        return batch;
    }

    /// <summary>Analyse et optimisation d'une image (un TIFF multipage peut produire plusieurs pages).</summary>
    public List<ProcessedPage> ProcessImage(ScannedImage image, ScanProfile profile)
    {
        var result = new List<ProcessedPage>();

        // PDF natif (texte, vectoriel) : conservé et optimisé sans perte plutôt que converti en images
        if (IsPdf(image.Data) && _settings.Pdf.NativePdfMode == NativePdfMode.Optimize && _pdf is { IsAvailable: true })
        {
            var (kind, pageCount) = _pdf.Classify(image.Data);
            if (kind != PdfKind.Scanned)
            {
                var optimized = kind == PdfKind.Native ? _pdf.OptimizeLossless(image.Data) : image.Data;
                // Jamais plus lourd que l'original : un PDF déjà optimisé est conservé tel quel
                bool already = optimized.Length >= image.Data.Length;
                if (already) optimized = image.Data;
                double gain = 100.0 * (1 - (double)optimized.Length / image.Data.Length);
                result.Add(new ProcessedPage
                {
                    SourceName = image.SourceName,
                    NativePdf = optimized,
                    NativePageCount = Math.Max(1, pageCount),
                    RawBytes = image.Data.LongLength,
                    InputBytes = image.Data.LongLength,
                    Thumbnail = SafeThumbnail(image.Data),
                    CleanupNote = kind != PdfKind.Native ? "PDF protégé ou endommagé : transmis tel quel"
                        : already ? "PDF natif déjà optimisé : conservé tel quel"
                        : $"PDF natif conservé, optimisé sans perte ({gain:0} %)",
                    Profile = profile
                });
                return result;
            }
        }

        IReadOnlyList<RasterImage> frames;
        try { frames = _codec.Decode(image.Data); }
        catch (Exception ex)
        {
            result.Add(new ProcessedPage
            {
                SourceName = image.SourceName, Error = $"Image illisible : {ex.Message}",
                Thumbnail = new RasterImage(1, 1, 1, new byte[] { 255 }, 72)
            });
            return result;
        }

        // PDF importé (scan de copieur…) : gardé en mémoire pour le déposer tel quel s'il est déjà plus léger
        var origin = IsPdf(image.Data) ? new ImportSource { Data = image.Data, PageCount = frames.Count } : null;
        for (int i = 0; i < frames.Count; i++)
        {
            var frame = frames[i];
            // Les BMP sans résolution déclarent souvent 96 dpi : on fait alors confiance au profil.
            if (frame.Dpi < 100 || Math.Abs(frame.Dpi - 96) < 0.5)
                frame.Dpi = image.DpiHint ?? profile.Resolution;
            result.Add(ProcessFrame(frame, image.SourceName, profile, image.Data.LongLength / Math.Max(1, frames.Count), origin, i));
        }
        return result;
    }

    private ProcessedPage ProcessFrame(RasterImage frame, string? sourceName, ScanProfile profile, long inputBytes,
                                       ImportSource? origin = null, int originIndex = 0)
    {
        // Nettoyage automatique (bords sombres, trous, redressement) avant toute analyse
        var c = profile.Cleanup;
        RasterImage page = frame;
        string note = "";
        if (c.RemoveBorders || c.RemovePunchHoles || c.Deskew)
        {
            var (cleaned, report) = ImageCleaner.Clean(frame, c);
            page = cleaned;
            note = report.ToString();
        }

        // Image d'analyse légère : QR et détection de page blanche
        var analysis = ImageOps.ToGray(ImageOps.ScaleToDpi(page, _settings.Separator.QrDecodeDpi));
        string? qr = SafeDecodeQr(analysis);
        bool isSeparator = qr != null && (_separatorPattern?.IsMatch(qr) ?? true);

        double inkRatio = InkRatio(analysis);
        bool isBlank = qr == null && profile.RemoveBlankPages && inkRatio < profile.BlankInkRatio;

        OptimizedPage? optimized = null;
        string? sourcePath = null;
        bool skip = isBlank || (isSeparator && _settings.Separator.RemoveSeparatorPages);
        if (!skip)
        {
            optimized = _optimizer.Optimize(page, profile.Output);
            note = AddText(optimized, page, profile, note);
            if (profile.KeepSourceForEditing) sourcePath = SaveSource(frame);
        }
        else if (isBlank) sourcePath = SaveSource(frame); // page blanche : copie gardée pour une réintégration éventuelle

        return new ProcessedPage
        {
            SourceName = sourceName,
            QrText = qr,
            IsSeparator = isSeparator,
            IsBlank = isBlank,
            InkRatio = inkRatio,
            Optimized = optimized,
            Thumbnail = ImageOps.ScaleToWidth(page, 180),
            RawBytes = frame.ByteSize,
            InputBytes = inputBytes,
            CleanupNote = note,
            SourcePath = sourcePath,
            SourceDpi = frame.Dpi,
            Profile = profile,
            Origin = origin,
            OriginIndex = originIndex
        };
    }

    /// <summary>OCR de la page (texte invisible dans le PDF). Une erreur d'OCR n'empêche jamais l'envoi.</summary>
    private string AddText(OptimizedPage optimized, RasterImage page, ScanProfile profile, string note)
    {
        if (!profile.UseOcr || !_ocrReady.Value) return note;
        try
        {
            optimized.Text.AddRange(_ocr!.Recognize(page));
            return note;
        }
        catch (Exception ex)
        {
            var msg = $"OCR non effectué ({ex.Message})";
            return note.Length == 0 ? msg : note + ", " + msg;
        }
    }

    /// <summary>OCR disponible et activé (affichage à l'agent).</summary>
    public bool OcrActive => _ocrReady.Value;

    /// <summary>Copie de la page brute (JPEG haute qualité) pour un nettoyage manuel ultérieur.</summary>
    private string? SaveSource(RasterImage frame)
    {
        try
        {
            Directory.CreateDirectory(_sourceFolder);
            var path = Path.Combine(_sourceFolder, $"{Guid.NewGuid():N}.jpg");
            File.WriteAllBytes(path, _codec.EncodeJpeg(frame, 92));
            return path;
        }
        catch { return null; } // la page reste exploitable, seul le nettoyage manuel sera indisponible
    }

    /// <summary>
    /// Nettoyage manuel d'une page depuis sa copie source : nettoyage complet puis nouvelle optimisation.
    /// La rotation manuelle éventuelle est conservée.
    /// </summary>
    public void Reprocess(ProcessedPage page, CleanupSettings cleanup)
    {
        var profile = page.Profile ?? _settings.GetProfile(null);
        var (cleaned, report) = LoadCleaned(page, cleanup);
        page.AppliedCleanup = cleanup;
        // Retouches manuelles (recadrage, niveaux, couleurs, netteté, noir et blanc) rejouées sur la pleine résolution
        var final = page.Adjustments is { IsIdentity: false } adj ? ImageAdjust.Apply(cleaned, adj) : cleaned;
        int rotation = page.Rotation;
        page.Optimized = _optimizer.Optimize(final, profile.Output);
        page.Rotation = rotation;
        var ocrNote = AddText(page.Optimized, final, profile, "");
        page.Thumbnail = ImageOps.ScaleToWidth(final, 180);
        var r = report.ToString();
        var parts = new List<string> { r.Length == 0 ? "nettoyée (rien à corriger)" : r };
        if (page.Adjustments is { IsIdentity: false } a) parts.Add("retouchée : " + a);
        if (ocrNote.Length > 0) parts.Add(ocrNote);
        page.CleanupNote = string.Join(", ", parts);
    }

    /// <summary>
    /// Image de la page avant retouches (copie source + nettoyage), pour la fenêtre « Image » :
    /// l'aperçu est réduit à <paramref name="maxWidth"/> pixels pour rester fluide.
    /// </summary>
    public RasterImage LoadForEditing(ProcessedPage page, int maxWidth = 1400)
    {
        var (cleaned, _) = LoadCleaned(page, page.AppliedCleanup ?? (page.Profile ?? _settings.GetProfile(null)).Cleanup);
        return ImageOps.ScaleToWidth(cleaned, maxWidth);
    }

    private (RasterImage image, CleanupReport report) LoadCleaned(ProcessedPage page, CleanupSettings cleanup)
    {
        if (page.SourcePath is null || !File.Exists(page.SourcePath))
            throw new InvalidOperationException("La copie de cette page n'est pas disponible : retouche impossible (page déjà envoyée, ou profil sans copie de travail).");
        var profile = page.Profile ?? _settings.GetProfile(null);
        var frame = _codec.Decode(File.ReadAllBytes(page.SourcePath))[0];
        frame.Dpi = page.SourceDpi > 0 ? page.SourceDpi
                  : page.Optimized != null && page.Optimized.WidthPt > 0 ? frame.Width * 72.0 / page.Optimized.WidthPt
                  : profile.Resolution;
        return ImageCleaner.Clean(frame, cleanup);
    }

    /// <summary>Supprime les copies de travail des pages (après envoi ou abandon).</summary>
    public static void DeleteSources(IEnumerable<ProcessedPage> pages)
    {
        foreach (var p in pages)
        {
            if (p.SourcePath is null) continue;
            try { File.Delete(p.SourcePath); } catch { /* fichier verrouillé : purge au prochain démarrage */ }
            p.SourcePath = null;
        }
    }

    /// <summary>Purge des copies de travail orphelines (application fermée sans envoi, arrêt brutal).</summary>
    public void PurgeOldSources(TimeSpan maxAge)
    {
        if (!Directory.Exists(_sourceFolder)) return;
        foreach (var f in Directory.EnumerateFiles(_sourceFolder, "*.jpg"))
        {
            try { if (DateTime.UtcNow - File.GetLastWriteTimeUtc(f) > maxAge) File.Delete(f); } catch { }
        }
    }

    private static bool IsPdf(byte[] d) => d.Length > 4 && d[0] == '%' && d[1] == 'P' && d[2] == 'D' && d[3] == 'F';

    private RasterImage SafeThumbnail(byte[] pdf)
    {
        try { if (_pdf?.RenderThumbnail(pdf, 180) is { } t) return t; } catch { }
        // Vignette neutre si aucun moteur de rendu n'est disponible
        var px = new byte[180 * 254];
        Array.Fill(px, (byte)235);
        return new RasterImage(180, 254, 1, px, 22);
    }

    private string? SafeDecodeQr(RasterImage gray)
    {
        try { return _qr.Decode(gray)?.Trim(); }
        catch { return null; }
    }

    /// <summary>Part de pixels nettement sombres hors marges (bords, trous de perforation).</summary>
    public static double InkRatio(RasterImage gray)
    {
        var cropped = ImageOps.CropMargins(gray, 0.05);
        // Seuil relatif au fond local : une écriture pâle (crayon, fax délavé, encre claire) compte comme de l'encre ;
        // le grain du papier et le léger transfert du verso (contraste < 25) restent ignorés.
        var mask = ImageOps.LocalThreshold(cropped, sensitivity: 0.12, minContrast: 25, maxInk: 240);
        ImageOps.Despeckle(mask, cropped.Width, cropped.Height);
        long ink = 0;
        foreach (var b in mask) ink += b;
        return (double)ink / mask.Length;
    }

    /// <summary>Découpe le lot en documents : chaque page séparatrice ouvre un nouveau document.</summary>
    private void Split(List<ProcessedPage> pages, BatchResult batch)
    {
        ScanDocument? current = null;
        string? activeQr = null;     // QR de la dernière page séparatrice rencontrée
        bool hasSeparator = false;
        int seq = 0;
        foreach (var page in pages)
        {
            if (page.Error != null)
            {
                batch.Warnings.Add($"Page {page.Index} : {page.Error}");
                continue;
            }
            if (page.IsSeparator)
            {
                batch.SeparatorPages++;
                hasSeparator = true;
                activeQr = page.QrText;
                current = NewDocument(activeQr, ++seq);
                batch.Documents.Add(current);
                if (page.Optimized != null) current.Pages.Add(page); // séparatrice conservée si configuré
                continue;
            }
            if (page.IsBlank) { batch.BlankPagesRemoved++; batch.RemovedBlankPages.Add(page); continue; }

            if (page.NativePdf != null)
            {
                // Un PDF natif forme toujours son propre document, rattaché à la séparatrice en cours s'il y en a une
                ScanDocument native;
                // Séparatrice juste avant : le PDF natif rejoint son document (la fiche sera placée en 1re page)
                if (current != null && current.Pages.All(p => p.IsSeparator)) native = current;
                else
                {
                    native = NewDocument(hasSeparator ? activeQr : null, ++seq);
                    batch.Documents.Add(native);
                }
                if (!hasSeparator)
                {
                    native.Warnings.Clear();
                    native.RoutingReason = "PDF importé sans page séparatrice : destination par défaut, à vérifier";
                    native.Warnings.Add(native.RoutingReason);
                }
                native.Pages.Add(page);
                current = null; // les pages numérisées suivantes forment un nouveau document (même séparatrice)
                continue;
            }

            if (current == null)
            {
                current = NewDocument(hasSeparator ? activeQr : null, ++seq);
                batch.Documents.Add(current);
            }
            current.Pages.Add(page);
        }

        // Séparatrices consécutives ou en fin de lot : documents sans contenu (vides ou réduits à la fiche séparatrice)
        foreach (var empty in batch.Documents.Where(d => d.Pages.All(p => p.IsSeparator)).ToList())
        {
            batch.Warnings.Add($"Page séparatrice « {empty.QrText} » sans document à la suite : ignorée.");
            batch.Documents.Remove(empty);
        }
        for (int i = 0; i < batch.Documents.Count; i++) batch.Documents[i].Sequence = i + 1;
    }

    private ScanDocument NewDocument(string? qr, int seq)
    {
        var decision = _routing.Decide(qr);
        var doc = new ScanDocument
        {
            Sequence = seq,
            QrText = qr,
            Target = decision.Target,
            RoutingReason = decision.Reason
        };
        if (decision.NeedsAttention) doc.Warnings.Add(decision.Reason);
        return doc;
    }

    private void BuildPdf(ScanDocument doc, BatchResult batch, int seq)
    {
        var values = new Dictionary<string, object?>
        {
            ["date"] = batch.StartedAt,
            // Profil « Enregistrer sur mon PC » : le nom garde Vie / Lloyd (règle du QR) plutôt que « PC »
            ["target"] = doc.RoutedTarget ?? doc.Target,
            ["route"] = doc.RoutedTarget ?? doc.Target,
            ["qr"] = TemplateFormatter.SafeSegment(doc.QrText, _settings.Naming.MaxQrLength, "SANS-QR"),
            ["seq"] = seq,
            ["pages"] = doc.PageCount,
            ["batch"] = batch.BatchId,
            ["user"] = Environment.UserName,
            ["machine"] = Environment.MachineName
        };
        var name = TemplateFormatter.SafeSegment(
            TemplateFormatter.Format(_settings.Naming.FilePattern, values), 180, $"document-{seq:000}");
        doc.FileName = name + ".pdf";

        if (doc.IsNativePdf)
        {
            var nativePdf = doc.NativePage!.NativePdf!; // contenu d'origine préservé (optimisé sans perte)
            var separators = doc.Pages.Where(p => p.IsSeparator && p.Optimized != null).Select(p => p.Optimized!).ToList();
            doc.Pdf = nativePdf;
            if (separators.Count > 0)
            {
                var sepPdf = PdfDocumentWriter.Write(separators, new PdfMetadata { Title = name, Keywords = doc.QrText, CreationDate = batch.StartedAt });
                var merged = _pdf?.Prepend(sepPdf, nativePdf);
                if (merged != null) doc.Pdf = merged;
                else
                {
                    doc.Pages.RemoveAll(p => p.IsSeparator);
                    doc.Warnings.Add("Fiche séparatrice non insérée devant le PDF importé (qpdf indisponible) : orientation faite, PDF d'origine déposé seul.");
                }
            }
            return;
        }

        var meta = new PdfMetadata
        {
            PdfA = _settings.Pdf.PdfA,
            Title = name,
            Author = Environment.UserName,
            Subject = $"Numérisation {doc.Target} — lot {batch.BatchId}",
            Keywords = doc.QrText,
            CreationDate = batch.StartedAt
        };
        meta.Custom["LloydQr"] = doc.QrText ?? "";
        meta.Custom["LloydEntite"] = doc.Target;
        meta.Custom["LloydLot"] = batch.BatchId;
        meta.Custom["LloydProfil"] = batch.ProfileName;

        doc.Pdf = PdfDocumentWriter.Write(doc.Pages.Select(p => p.Optimized!).ToList(), meta);

        // Jamais plus lourd que l'original : un PDF importé entier, non retouché, déjà plus léger que le résultat
        // est déposé tel quel (il n'a alors ni OCR ajouté ni PDF/A : signalé à l'agent).
        const string keptOriginal = "PDF importé déjà plus léger que le résultat : déposé tel quel (OCR et PDF/A non ajoutés)";
        doc.Warnings.Remove(keptOriginal);
        var origin = doc.Pages.Count > 0 ? doc.Pages[0].Origin : null;
        if (origin != null && doc.Edits.Count == 0 && doc.Pages.Count == origin.PageCount
            && doc.Pages.Select((p, i) => p.Origin == origin && p.OriginIndex == i && p.Rotation == 0).All(ok => ok)
            && doc.Pdf.Length >= origin.Data.Length)
        {
            doc.Pdf = origin.Data;
            doc.Warnings.Add(keptOriginal);
        }
    }

    /// <summary>Régénère le nom et le PDF d'un document après modification de ses pages.</summary>
    public void Rebuild(ScanDocument doc, BatchResult batch) => BuildPdf(doc, batch, doc.Sequence);

    /// <summary>Change la destination d'un document (correction opérateur) et régénère son nom.</summary>
    public void Retarget(ScanDocument doc, BatchResult batch, string newTarget)
    {
        if (!_settings.Targets.ContainsKey(newTarget))
            throw new ArgumentException($"Destination inconnue : {newTarget}");
        doc.Target = newTarget;
        doc.RoutingReason = "Destination modifiée par l'opérateur";
        doc.Warnings.RemoveAll(w => w.StartsWith("Pages numérisées sans page séparatrice", StringComparison.Ordinal));
        BuildPdf(doc, batch, doc.Sequence);
    }
}
