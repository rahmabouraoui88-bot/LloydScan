using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;

namespace LloydScan.Core.Processing;

/// <summary>Remplace {nom} ou {nom:format} par les valeurs fournies (dates, compteurs, texte).</summary>
public static partial class TemplateFormatter
{
    [GeneratedRegex(@"\{(?<name>[a-zA-Z]+)(?::(?<fmt>[^}]+))?\}")]
    private static partial Regex Placeholder();

    public static string Format(string template, IReadOnlyDictionary<string, object?> values) =>
        Placeholder().Replace(template, m =>
        {
            var name = m.Groups["name"].Value;
            var fmt = m.Groups["fmt"].Success ? m.Groups["fmt"].Value : null;
            var key = values.Keys.FirstOrDefault(k => string.Equals(k, name, StringComparison.OrdinalIgnoreCase));
            if (key is null) return m.Value;
            return values[key] switch
            {
                null => "",
                IFormattable f => f.ToString(fmt, CultureInfo.InvariantCulture),
                var v => v.ToString() ?? ""
            };
        });

    /// <summary>Nettoie un texte pour l'utiliser dans un nom de fichier ou un chemin WebDAV.</summary>
    public static string SafeSegment(string? text, int maxLength, string fallback)
    {
        if (string.IsNullOrWhiteSpace(text)) return fallback;
        var normalized = text.Normalize(NormalizationForm.FormD);
        var sb = new StringBuilder();
        foreach (var ch in normalized)
        {
            if (CharUnicodeInfo.GetUnicodeCategory(ch) == UnicodeCategory.NonSpacingMark) continue; // é → e
            if (char.IsAsciiLetterOrDigit(ch) || ch is '-' or '_') sb.Append(ch);
            else if (sb.Length > 0 && sb[^1] != '-') sb.Append('-');
        }
        var s = sb.ToString().Trim('-');
        if (s.Length > maxLength) s = s[..maxLength].TrimEnd('-');
        return s.Length == 0 ? fallback : s;
    }

    /// <summary>Nettoie chaque segment d'un chemin relatif (a/b/c).</summary>
    public static string SafePath(string path) =>
        string.Join('/', path.Split('/', '\\', StringSplitOptions.RemoveEmptyEntries)
            .Select(seg => SafeSegment(seg, 80, "x")));
}
