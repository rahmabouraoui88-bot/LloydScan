using LloydScan.Core.Configuration;
using LloydScan.Core.Imaging;
using LloydScan.Core.Pdf;

namespace LloydScan.Core.Processing;

/// <summary>
/// Transforme une page numérisée en couches PDF compressées selon le profil.
///
/// Principe MRC (Mixed Raster Content) :
///  - couche texte : masque 1 bit à pleine résolution (300 dpi) compressé sans perte en G4 → traits nets ;
///  - couche fond : papier, logos, tampons pâles, à basse résolution (100 dpi) en JPEG → très léger ;
///  - couleur du texte : uniforme si la page est grise, sinon petite image JPEG (encre bleue, tampons).
/// Le rendu final superpose les couches : le texte reste net comme l'original pour 5 à 10 fois moins d'octets.
/// </summary>
public sealed class PageOptimizer
{
    private readonly IImageCodec _codec;

    public PageOptimizer(IImageCodec codec) => _codec = codec;

    public OptimizedPage Optimize(RasterImage src, OutputSettings o)
    {
        return o.Mode switch
        {
            OutputMode.Color => Jpeg(src, o, keepColor: true),
            OutputMode.Gray => Jpeg(src, o, keepColor: false),
            OutputMode.BlackWhite => BlackWhite(src, o),
            OutputMode.Mrc => Mrc(src, o, keepColor: !src.IsGray),
            _ => Auto(src, o)
        };
    }

    /// <summary>
    /// Mode Auto : une page à dominante photo passe en JPEG (le MRC n'apporte rien sur une photo),
    /// sinon MRC, en gris si la page n'a pas de couleur significative.
    /// </summary>
    private OptimizedPage Auto(RasterImage src, OutputSettings o)
    {
        bool colored = !src.IsGray && ImageOps.ColorRatio(src) >= o.ColorDetectionRatio;
        if (o.PhotoDetectionRatio > 0 && ImageOps.PictureRatio(src) >= o.PhotoDetectionRatio)
            return Jpeg(src, o, keepColor: colored, label: "photo détectée — ");
        return Mrc(src, o, keepColor: colored);
    }

    private OptimizedPage Jpeg(RasterImage src, OutputSettings o, bool keepColor, string label = "")
    {
        var img = ImageOps.ScaleToDpi(src, o.ImageDpi);
        if (!keepColor) img = ImageOps.ToGray(img);
        var page = new OptimizedPage
        {
            WidthPt = src.WidthPt, HeightPt = src.HeightPt,
            Strategy = $"{label}JPEG {(img.IsGray ? "gris" : "couleur")} {img.Dpi:0} dpi q{o.JpegQuality}"
        };
        page.Layers.Add(new PdfLayer { Image = ToJpeg(img, o.JpegQuality) });
        return page;
    }

    private OptimizedPage BlackWhite(RasterImage src, OutputSettings o)
    {
        var gray = ImageOps.ToGray(ImageOps.ScaleToDpi(src, o.BlackWhiteDpi));
        var mask = ImageOps.LocalThreshold(gray, o.ThresholdSensitivity, minContrast: 20, maxInk: 230, solidDark: 90);
        if (o.Despeckle) ImageOps.Despeckle(mask, gray.Width, gray.Height);
        var plane = BitPlane.FromMask(mask, gray.Width, gray.Height);
        var page = new OptimizedPage
        {
            WidthPt = src.WidthPt, HeightPt = src.HeightPt,
            Strategy = $"Noir et blanc {gray.Dpi:0} dpi {o.MaskCompression}"
        };
        page.Layers.Add(new PdfLayer { Image = ToBitImage(plane, PdfImageKind.Bilevel, o.MaskCompression) });
        return page;
    }

    private OptimizedPage Mrc(RasterImage src, OutputSettings o, bool keepColor)
    {
        var work = ImageOps.ScaleToDpi(src, o.MaskDpi);
        if (!keepColor) work = ImageOps.ToGray(work);
        var gray = ImageOps.ToGray(work);
        int w = gray.Width, h = gray.Height;

        // Couche texte : encre sombre (1) et texte clair sur aplat sombre (2)
        // Écriture pâle : seuil relatif au fond local, jusqu'à des gris très clairs si le rehaussement est actif
        // solidDark : un aplat franchement noir reste de l'encre (sinon le seuil local perce l'intérieur des
        // grands modules d'un QR code ou d'un gros titre, et le QR de la fiche séparatrice devient illisible)
        var mask = ImageOps.LocalThreshold(gray, o.ThresholdSensitivity, minContrast: 20,
                                           maxInk: o.EnhanceFaintText ? 238 : 215, solidDark: 80, detectInverse: true);
        // Page entièrement pâle (crayon, fax délavé) : le cœur des traits est clair, le seuil standard n'en garde
        // qu'un filet ; on reprend avec un seuil plus fin pour capter le trait entier, qui sera restitué foncé.
        bool faint = false;
        if (o.EnhanceFaintText && ImageOps.PercentileOver(gray, mask, 0.25, 1) > 150)
        {
            mask = ImageOps.LocalThreshold(gray, Math.Min(o.ThresholdSensitivity, 0.07), minContrast: 14, maxInk: 242, solidDark: 80, detectInverse: true);
            faint = true;
        }
        if (o.Despeckle) ImageOps.Despeckle(mask, w, h);
        var plane = BitPlane.FromMask(mask, w, h);
        long ink = plane.CountInk();

        var page = new OptimizedPage
        {
            WidthPt = src.WidthPt, HeightPt = src.HeightPt,
            Strategy = $"MRC {(keepColor ? "couleur" : "gris")} texte {work.Dpi:0} dpi / fond {o.BackgroundDpi} dpi" +
                       (faint ? " — écriture pâle rehaussée" : "")
        };

        // Couche fond : on ne moyenne que les pixels hors texte (masque dilaté pour exclure l'anticrénelage)
        int bgFactor = Math.Max(1, (int)Math.Round(work.Dpi / Math.Max(1, o.BackgroundDpi)));
        var exclusion = ink > 0 ? ImageOps.Dilate(mask, w, h) : mask;
        var background = ImageOps.MaskedDownscale(work, exclusion, bgFactor, takeInk: false, fallback: 255);
        page.Layers.Add(new PdfLayer { Image = ToJpeg(background, o.BackgroundQuality) });

        if (ink == 0) return page; // page sans texte : le fond suffit

        // Teinte « cœur de trait » de l'encre sombre (le noir réel du document, sans les bords plus clairs)
        int darkTone = Math.Min(ImageOps.PercentileOver(gray, mask, 0.05, 1), o.EnhanceFaintText ? Math.Clamp(o.MaxTextTone, 0, 120) : 120);
        if (!keepColor)
        {
            // Page sans couleur : un masque par teinte, peint d'une couleur unie (quasi gratuit en octets)
            var dark = BitPlane.FromMask(mask, w, h, 1);
            if (dark.CountInk() > 0)
            {
                double t = darkTone / 255.0;
                page.Layers.Add(new PdfLayer { Image = ToBitImage(dark, PdfImageKind.StencilMask, o.MaskCompression), FillColor = (t, t, t) });
            }
            var light = BitPlane.FromMask(mask, w, h, 2);
            if (light.CountInk() > 0)
            {
                double t = ImageOps.PercentileOver(gray, mask, 0.5, 2) / 255.0;
                page.Layers.Add(new PdfLayer { Image = ToBitImage(light, PdfImageKind.StencilMask, o.MaskCompression), FillColor = (t, t, t) });
            }
        }
        else
        {
            // Couleur du texte : petite image JPEG découpée par le masque de l'encre sombre (signatures, tampons).
            // Le texte clair sur fond sombre a son propre masque, peint d'une teinte unie : les deux ne se mélangent
            // jamais dans un même bloc de couleur (sinon les zones très contrastées, comme un QR code, se trouent).
            int fgFactor = Math.Max(1, (int)Math.Round(work.Dpi / Math.Max(1, o.ForegroundDpi)));
            var dark = BitPlane.FromMask(mask, w, h, 1);
            var light = BitPlane.FromMask(mask, w, h, 2);
            var inkOnly = light.CountInk() > 0 ? Array.ConvertAll(mask, v => v == 1 ? (byte)1 : (byte)0) : mask;
            var foreground = ImageOps.MaskedDownscale(work, inkOnly, fgFactor, takeInk: true, fallback: 0);
            // L'encre neutre prend une teinte unique : seule la vraie couleur coûte des octets.
            ImageOps.FlattenNeutral(foreground, (byte)darkTone, chromaThreshold: 45, limit: o.EnhanceFaintText ? 245 : 200);
            // Encre de couleur pâle (bleu clair, tampon délavé) : assombrie en gardant sa teinte
            if (o.EnhanceFaintText) ImageOps.DarkenInk(foreground, inkOnly, w, h, fgFactor, (byte)darkTone, Math.Clamp(o.MaxTextTone + 30, 60, 160));
            if (dark.CountInk() > 0)
                page.Layers.Add(new PdfLayer
                {
                    Image = ToJpeg(foreground, o.ForegroundQuality),
                    Mask = ToBitImage(dark, PdfImageKind.StencilMask, o.MaskCompression)
                });
            if (light.CountInk() > 0)
            {
                double t = ImageOps.PercentileOver(gray, mask, 0.5, 2) / 255.0;
                page.Layers.Add(new PdfLayer { Image = ToBitImage(light, PdfImageKind.StencilMask, o.MaskCompression), FillColor = (t, t, t) });
            }
        }
        return page;
    }

    private PdfImage ToJpeg(RasterImage img, int quality) => new()
    {
        Kind = PdfImageKind.Jpeg,
        Width = img.Width,
        Height = img.Height,
        Components = img.Channels,
        Filter = "DCTDecode",
        Data = _codec.EncodeJpeg(img, Math.Clamp(quality, 5, 100))
    };

    private static PdfImage ToBitImage(BitPlane plane, PdfImageKind kind, MaskCompression compression)
    {
        bool g4 = compression == MaskCompression.CcittG4;
        return new PdfImage
        {
            Kind = kind,
            Width = plane.Width,
            Height = plane.Height,
            Filter = g4 ? "CCITTFaxDecode" : "FlateDecode",
            Data = g4 ? CcittG4Encoder.Encode(plane) : PdfDocumentWriter.Deflate(plane.Bits)
        };
    }
}
