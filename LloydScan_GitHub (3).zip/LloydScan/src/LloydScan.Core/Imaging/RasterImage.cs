namespace LloydScan.Core.Imaging;

/// <summary>Image en mémoire : 1 canal (gris 8 bits) ou 3 canaux (R, G, B 8 bits), lignes contiguës.</summary>
public sealed class RasterImage
{
    public int Width { get; }
    public int Height { get; }
    public int Channels { get; }
    public byte[] Pixels { get; }
    public double Dpi { get; set; }

    public RasterImage(int width, int height, int channels, byte[] pixels, double dpi)
    {
        if (channels != 1 && channels != 3) throw new ArgumentOutOfRangeException(nameof(channels));
        if (width <= 0 || height <= 0) throw new ArgumentOutOfRangeException(nameof(width));
        if (pixels.Length < width * height * channels) throw new ArgumentException("Tampon trop petit.", nameof(pixels));
        Width = width; Height = height; Channels = channels; Pixels = pixels; Dpi = dpi;
    }

    public RasterImage(int width, int height, int channels, double dpi)
        : this(width, height, channels, new byte[width * height * channels], dpi) { }

    public int Stride => Width * Channels;
    public bool IsGray => Channels == 1;
    public long ByteSize => (long)Width * Height * Channels;

    /// <summary>Dimensions physiques en points PDF (1/72 de pouce).</summary>
    public double WidthPt => Width * 72.0 / Dpi;
    public double HeightPt => Height * 72.0 / Dpi;
}

/// <summary>Plan binaire 1 bit par pixel, lignes alignées sur l'octet, bit de poids fort à gauche. 1 = encre.</summary>
public sealed class BitPlane
{
    public int Width { get; }
    public int Height { get; }
    public int RowBytes { get; }
    public byte[] Bits { get; }

    public BitPlane(int width, int height)
    {
        Width = width; Height = height; RowBytes = (width + 7) / 8;
        Bits = new byte[RowBytes * height];
    }

    public bool this[int x, int y] => (Bits[y * RowBytes + (x >> 3)] & (0x80 >> (x & 7))) != 0;

    /// <summary>
    /// Construit le plan à partir d'un masque 1 octet/pixel :
    /// tous les pixels non nuls, ou seulement ceux égaux à <paramref name="only"/>.
    /// </summary>
    public static BitPlane FromMask(byte[] mask, int width, int height, byte? only = null)
    {
        var p = new BitPlane(width, height);
        for (int y = 0; y < height; y++)
        {
            int src = y * width, dst = y * p.RowBytes;
            for (int x = 0; x < width; x++)
            {
                byte m = mask[src + x];
                if (only.HasValue ? m == only.Value : m != 0) p.Bits[dst + (x >> 3)] |= (byte)(0x80 >> (x & 7));
            }
        }
        return p;
    }

    public long CountInk()
    {
        long n = 0;
        foreach (var b in Bits) n += System.Numerics.BitOperations.PopCount(b);
        return n;
    }
}
