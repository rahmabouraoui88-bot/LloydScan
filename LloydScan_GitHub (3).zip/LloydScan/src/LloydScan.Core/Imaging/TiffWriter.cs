using System.IO.Compression;

namespace LloydScan.Core.Imaging;

/// <summary>
/// Écriture d'un TIFF multipage, page par page (aucune page n'est gardée en mémoire après son écriture :
/// indispensable dans le processus 32 bits pour un document de 50 pages).
/// Compression adaptée à chaque page : CCITT G4 pour le noir et blanc, Deflate + prédicteur pour le gris et la couleur.
/// Lisible par la visionneuse Windows, Photoshop, IrfanView et les GED.
/// </summary>
public sealed class TiffWriter : IDisposable
{
    private readonly Stream _out;
    private readonly bool _leaveOpen;
    private long _nextIfdPointer = 4; // emplacement de l'offset du 1er IFD dans l'en-tête
    public int PageCount { get; private set; }

    public TiffWriter(Stream output, bool leaveOpen = false)
    {
        _out = output;
        _leaveOpen = leaveOpen;
        // En-tête little-endian : "II" 42 puis offset du 1er IFD (renseigné à l'ajout de la 1re page)
        _out.Write(new byte[] { 0x49, 0x49, 42, 0, 0, 0, 0, 0 });
    }

    /// <summary>Ajoute une page. L'image est simplifiée (couleur → gris → noir et blanc) si cela ne change rien à l'œil.</summary>
    public void AddPage(RasterImage page, bool simplify = true)
    {
        var img = simplify ? ImageExport.Simplify(page) : page;
        bool bilevel = img.IsGray && ImageExport.IsBilevel(img);

        byte[] data;
        ushort compression, photometric, samples;
        if (bilevel)
        {
            data = CcittG4Encoder.Encode(ImageExport.ToBitPlane(img));
            compression = 4;   // CCITT T.6
            photometric = 0;   // WhiteIsZero : bit 1 = noir, comme l'encodeur G4
            samples = 1;
        }
        else
        {
            data = Deflate(img);
            compression = 8;   // Adobe Deflate
            photometric = (ushort)(img.IsGray ? 1 : 2);
            samples = (ushort)img.Channels;
        }

        Align();
        long dataOffset = _out.Position;
        _out.Write(data);

        // Valeurs annexes (hors IFD) : BitsPerSample RGB et résolutions
        Align();
        long bpsOffset = 0;
        if (samples == 3)
        {
            bpsOffset = _out.Position;
            WriteU16(8); WriteU16(8); WriteU16(8);
        }
        Align();
        long resOffset = _out.Position;
        uint dpi = (uint)Math.Max(1, Math.Round(img.Dpi));
        WriteU32(dpi); WriteU32(1); // XResolution
        WriteU32(dpi); WriteU32(1); // YResolution

        var tags = new List<(ushort Tag, ushort Type, uint Count, uint Value)>
        {
            (254, 4, 1, 2),                                  // NewSubfileType : page d'un document multipage
            (256, 4, 1, (uint)img.Width),
            (257, 4, 1, (uint)img.Height),
            (258, 3, samples, samples == 3 ? (uint)bpsOffset : (uint)(bilevel ? 1 : 8)),
            (259, 3, 1, compression),
            (262, 3, 1, photometric),
            (273, 4, 1, (uint)dataOffset),                   // StripOffsets (une seule bande)
            (277, 3, 1, samples),
            (278, 4, 1, (uint)img.Height),                   // RowsPerStrip
            (279, 4, 1, (uint)data.Length),                  // StripByteCounts
            (282, 5, 1, (uint)resOffset),
            (283, 5, 1, (uint)resOffset + 8),
            (284, 3, 1, 1),                                  // PlanarConfiguration : contigu
            (296, 3, 1, 2),                                  // ResolutionUnit : pouce
            (297, 3, 2, (uint)PageCount | ((uint)0 << 16)),  // PageNumber (n, total inconnu = 0)
        };
        if (!bilevel) tags.Add((317, 3, 1, 2));              // Predictor : différence horizontale
        tags.Sort((a, b) => a.Tag.CompareTo(b.Tag));

        Align();
        long ifdOffset = _out.Position;
        WriteU16((ushort)tags.Count);
        foreach (var (tag, type, count, value) in tags)
        {
            WriteU16(tag); WriteU16(type); WriteU32(count);
            if (type == 3 && count == 1) { WriteU16((ushort)value); WriteU16(0); }
            else if (type == 3 && count == 2) { WriteU16((ushort)(value & 0xFFFF)); WriteU16((ushort)(value >> 16)); }
            else WriteU32(value);
        }
        long nextPointer = _out.Position;
        WriteU32(0); // pas de page suivante (corrigé à l'ajout de la suivante)
        long end = _out.Position;

        _out.Position = _nextIfdPointer;
        WriteU32((uint)ifdOffset);
        _out.Position = end;
        _nextIfdPointer = nextPointer;
        PageCount++;
    }

    private static byte[] Deflate(RasterImage img)
    {
        int c = img.Channels, stride = img.Stride;
        var row = new byte[stride];
        using var ms = new MemoryStream();
        using (var z = new ZLibStream(ms, CompressionLevel.Optimal, leaveOpen: true))
        {
            for (int y = 0; y < img.Height; y++)
            {
                int o = y * stride;
                // Prédicteur 2 : chaque échantillon est remplacé par sa différence avec le pixel de gauche
                for (int i = 0; i < c; i++) row[i] = img.Pixels[o + i];
                for (int i = c; i < stride; i++) row[i] = (byte)(img.Pixels[o + i] - img.Pixels[o + i - c]);
                z.Write(row, 0, stride);
            }
        }
        return ms.ToArray();
    }

    private void Align()
    {
        if ((_out.Position & 1) != 0) _out.WriteByte(0);
    }

    private void WriteU16(ushort v) { _out.WriteByte((byte)v); _out.WriteByte((byte)(v >> 8)); }
    private void WriteU32(uint v) { WriteU16((ushort)v); WriteU16((ushort)(v >> 16)); }

    public void Dispose()
    {
        _out.Flush();
        if (!_leaveOpen) _out.Dispose();
    }
}

/// <summary>Préparation des pages pour l'export d'images (JPEG, TIFF).</summary>
public static class ImageExport
{
    /// <summary>
    /// Une page couleur dont tous les pixels sont gris (R≈G≈B) devient une image en niveaux de gris ;
    /// une page grise quasi binaire devient du noir et blanc pur. Fichier 3 à 20 fois plus léger, aspect identique.
    /// </summary>
    public static RasterImage Simplify(RasterImage img)
    {
        if (!img.IsGray)
        {
            var p = img.Pixels;
            long n = (long)img.Width * img.Height;
            for (long i = 0; i < n; i++)
            {
                int r = p[i * 3], g = p[i * 3 + 1], b = p[i * 3 + 2];
                if (Math.Abs(r - g) > 8 || Math.Abs(g - b) > 8 || Math.Abs(r - b) > 8) return img;
            }
            var gray = new byte[n];
            for (long i = 0; i < n; i++) gray[i] = (byte)((p[i * 3] * 77 + p[i * 3 + 1] * 150 + p[i * 3 + 2] * 29) >> 8);
            img = new RasterImage(img.Width, img.Height, 1, gray, img.Dpi);
        }
        if (IsBilevel(img))
        {
            var bw = new byte[img.Pixels.Length];
            for (int i = 0; i < bw.Length; i++) bw[i] = img.Pixels[i] < 128 ? (byte)0 : (byte)255;
            return new RasterImage(img.Width, img.Height, 1, bw, img.Dpi);
        }
        return img;
    }

    /// <summary>Vrai si moins de 0,5 % des pixels sont des gris intermédiaires (lissage du rendu).</summary>
    public static bool IsBilevel(RasterImage img)
    {
        if (!img.IsGray) return false;
        long mid = 0, n = img.Pixels.Length, limit = n / 200;
        foreach (byte v in img.Pixels)
            if (v > 40 && v < 215 && ++mid > limit) return false;
        return true;
    }

    /// <summary>Gris → plan 1 bit (bit 1 = noir).</summary>
    public static BitPlane ToBitPlane(RasterImage gray)
    {
        var plane = new BitPlane(gray.Width, gray.Height);
        for (int y = 0; y < gray.Height; y++)
        {
            int o = y * gray.Width, r = y * plane.RowBytes;
            for (int x = 0; x < gray.Width; x++)
                if (gray.Pixels[o + x] < 128) plane.Bits[r + (x >> 3)] |= (byte)(0x80 >> (x & 7));
        }
        return plane;
    }
}
