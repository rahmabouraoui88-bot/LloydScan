namespace LloydScan.Core.Imaging;

/// <summary>
/// Retouches manuelles d'une page, choisies par l'agent dans la fenêtre « Image » :
/// recadrage, niveaux automatiques, luminosité, contraste, teinte, saturation, netteté, noir et blanc.
/// Elles sont rejouées sur la copie source à pleine résolution, puis la page est recompressée (MRC, OCR).
/// </summary>
public sealed class ImageAdjustments
{
    /// <summary>Part retirée de chaque bord, de 0 à 0,45 (0,1 = 10 % de la largeur ou de la hauteur).</summary>
    public double CropLeft { get; set; }
    public double CropTop { get; set; }
    public double CropRight { get; set; }
    public double CropBottom { get; set; }
    /// <summary>Étire les niveaux : le plus sombre devient noir, le plus clair blanc (bouton « Auto »).</summary>
    public bool AutoLevels { get; set; }
    /// <summary>-100 à +100.</summary>
    public int Brightness { get; set; }
    /// <summary>-100 à +100.</summary>
    public int Contrast { get; set; }
    /// <summary>Rotation de teinte, -180 à +180 degrés.</summary>
    public int Hue { get; set; }
    /// <summary>-100 (gris) à +100 (couleurs vives).</summary>
    public int Saturation { get; set; }
    /// <summary>0 à 100.</summary>
    public int Sharpen { get; set; }
    /// <summary>Page convertie en noir et blanc pur (texte net, fichier très léger).</summary>
    public bool BlackWhite { get; set; }

    public bool HasCrop => CropLeft > 0 || CropTop > 0 || CropRight > 0 || CropBottom > 0;
    public bool IsIdentity => !HasCrop && !AutoLevels && Brightness == 0 && Contrast == 0 && Hue == 0
                              && Saturation == 0 && Sharpen == 0 && !BlackWhite;

    public ImageAdjustments Clone() => (ImageAdjustments)MemberwiseClone();

    /// <summary>
    /// Recadrage tel que l'agent le voit à l'écran (page tournée de <paramref name="rotation"/>° dans le sens horaire) :
    /// (gauche, haut, droite, bas) affichés. Le recadrage est stocké par rapport à l'image source non tournée.
    /// </summary>
    public (double Left, double Top, double Right, double Bottom) DisplayCrop(int rotation) =>
        (((rotation % 360) + 360) % 360) switch
        {
            90 => (CropBottom, CropLeft, CropTop, CropRight),
            180 => (CropRight, CropBottom, CropLeft, CropTop),
            270 => (CropTop, CropRight, CropBottom, CropLeft),
            _ => (CropLeft, CropTop, CropRight, CropBottom)
        };

    /// <summary>Inverse de <see cref="DisplayCrop"/> : enregistre un recadrage saisi sur la page affichée tournée.</summary>
    public void SetDisplayCrop(int rotation, double left, double top, double right, double bottom)
    {
        switch (((rotation % 360) + 360) % 360)
        {
            case 90: (CropBottom, CropLeft, CropTop, CropRight) = (left, top, right, bottom); break;
            case 180: (CropRight, CropBottom, CropLeft, CropTop) = (left, top, right, bottom); break;
            case 270: (CropTop, CropRight, CropBottom, CropLeft) = (left, top, right, bottom); break;
            default: (CropLeft, CropTop, CropRight, CropBottom) = (left, top, right, bottom); break;
        }
    }

    /// <summary>Résumé lisible (journal, libellé de la page).</summary>
    public override string ToString()
    {
        var parts = new List<string>();
        if (HasCrop) parts.Add("recadrée");
        if (AutoLevels) parts.Add("niveaux auto");
        if (Brightness != 0) parts.Add($"luminosité {Brightness:+0;-0}");
        if (Contrast != 0) parts.Add($"contraste {Contrast:+0;-0}");
        if (Hue != 0) parts.Add($"teinte {Hue:+0;-0}°");
        if (Saturation != 0) parts.Add($"saturation {Saturation:+0;-0}");
        if (Sharpen != 0) parts.Add($"netteté {Sharpen}");
        if (BlackWhite) parts.Add("noir et blanc");
        return string.Join(", ", parts);
    }
}

public static class ImageAdjust
{
    /// <summary>Applique les retouches ; renvoie une nouvelle image (la source n'est pas modifiée).</summary>
    public static RasterImage Apply(RasterImage src, ImageAdjustments a)
    {
        var img = a.HasCrop ? Crop(src, a) : Copy(src);
        if (a.AutoLevels) StretchLevels(img);
        if (a.Brightness != 0 || a.Contrast != 0) BrightnessContrast(img, a.Brightness, a.Contrast);
        if (!img.IsGray && (a.Hue != 0 || a.Saturation != 0)) HueSaturation(img, a.Hue, a.Saturation);
        if (a.Sharpen > 0) img = SharpenImage(img, a.Sharpen);
        if (a.BlackWhite) img = ToBlackWhite(img);
        return img;
    }

    private static RasterImage Copy(RasterImage s) => new(s.Width, s.Height, s.Channels, (byte[])s.Pixels.Clone(), s.Dpi);

    public static RasterImage Crop(RasterImage s, ImageAdjustments a)
    {
        double l = Math.Clamp(a.CropLeft, 0, 0.45), r = Math.Clamp(a.CropRight, 0, 0.45);
        double t = Math.Clamp(a.CropTop, 0, 0.45), b = Math.Clamp(a.CropBottom, 0, 0.45);
        int x0 = (int)Math.Round(s.Width * l), x1 = (int)Math.Round(s.Width * (1 - r));
        int y0 = (int)Math.Round(s.Height * t), y1 = (int)Math.Round(s.Height * (1 - b));
        int w = Math.Max(16, x1 - x0), h = Math.Max(16, y1 - y0);
        x0 = Math.Clamp(x0, 0, s.Width - w); y0 = Math.Clamp(y0, 0, s.Height - h);
        int c = s.Channels;
        var dst = new byte[w * h * c];
        for (int y = 0; y < h; y++)
            Buffer.BlockCopy(s.Pixels, ((y0 + y) * s.Width + x0) * c, dst, y * w * c, w * c);
        return new RasterImage(w, h, c, dst, s.Dpi);
    }

    /// <summary>Le 0,5 % le plus sombre devient noir, le 0,5 % le plus clair devient blanc (même étirement sur R, V, B).</summary>
    public static void StretchLevels(RasterImage img)
    {
        var hist = new long[256];
        var p = img.Pixels;
        int c = img.Channels;
        for (int i = 0; i < p.Length; i += c)
        {
            int l = c == 1 ? p[i] : (p[i] * 77 + p[i + 1] * 150 + p[i + 2] * 29) >> 8;
            hist[l]++;
        }
        long total = (long)img.Width * img.Height, cut = total / 200, acc = 0;
        int lo = 0, hi = 255;
        for (int v = 0; v < 256; v++) { acc += hist[v]; if (acc > cut) { lo = v; break; } }
        acc = 0;
        for (int v = 255; v >= 0; v--) { acc += hist[v]; if (acc > cut) { hi = v; break; } }
        if (hi - lo < 16) return;
        var lut = new byte[256];
        for (int v = 0; v < 256; v++) lut[v] = (byte)Math.Clamp((v - lo) * 255 / (hi - lo), 0, 255);
        for (int i = 0; i < p.Length; i++) p[i] = lut[p[i]];
    }

    public static void BrightnessContrast(RasterImage img, int brightness, int contrast)
    {
        double offset = Math.Clamp(brightness, -100, 100) * 1.28;
        double c = Math.Clamp(contrast, -100, 100) * 2.55;
        double f = 259 * (c + 255) / (255 * (259 - c));
        var lut = new byte[256];
        for (int v = 0; v < 256; v++) lut[v] = (byte)Math.Clamp(Math.Round(f * (v - 128) + 128 + offset), 0, 255);
        var p = img.Pixels;
        for (int i = 0; i < p.Length; i++) p[i] = lut[p[i]];
    }

    /// <summary>Teinte et saturation (modèle TSL), pour les pages en couleur.</summary>
    public static void HueSaturation(RasterImage img, int hue, int saturation)
    {
        double dh = Math.Clamp(hue, -180, 180) / 360.0, sf = 1 + Math.Clamp(saturation, -100, 100) / 100.0;
        var p = img.Pixels;
        for (int i = 0; i < p.Length; i += 3)
        {
            double r = p[i] / 255.0, g = p[i + 1] / 255.0, b = p[i + 2] / 255.0;
            double max = Math.Max(r, Math.Max(g, b)), min = Math.Min(r, Math.Min(g, b));
            double l = (max + min) / 2, h = 0, s = 0, d = max - min;
            if (d < 1e-6) continue; // gris neutre : rien à faire
            s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
            if (max == r) h = (g - b) / d + (g < b ? 6 : 0);
            else if (max == g) h = (b - r) / d + 2;
            else h = (r - g) / d + 4;
            h /= 6;
            h = (h + dh) % 1; if (h < 0) h += 1;
            s = Math.Clamp(s * sf, 0, 1);
            double q = l < 0.5 ? l * (1 + s) : l + s - l * s, pp = 2 * l - q;
            p[i] = (byte)Math.Round(HueToRgb(pp, q, h + 1.0 / 3) * 255);
            p[i + 1] = (byte)Math.Round(HueToRgb(pp, q, h) * 255);
            p[i + 2] = (byte)Math.Round(HueToRgb(pp, q, h - 1.0 / 3) * 255);
        }
    }

    private static double HueToRgb(double p, double q, double t)
    {
        if (t < 0) t += 1;
        if (t > 1) t -= 1;
        if (t < 1.0 / 6) return p + (q - p) * 6 * t;
        if (t < 0.5) return q;
        if (t < 2.0 / 3) return p + (q - p) * (2.0 / 3 - t) * 6;
        return p;
    }

    /// <summary>Masque flou (unsharp mask) de rayon 1 : renforce les contours du texte.</summary>
    public static RasterImage SharpenImage(RasterImage src, int amount)
    {
        double k = Math.Clamp(amount, 0, 100) / 100.0 * 1.5;
        int w = src.Width, h = src.Height, c = src.Channels;
        var s = src.Pixels;
        var dst = new byte[s.Length];
        for (int y = 0; y < h; y++)
        {
            int ym = Math.Max(0, y - 1), yp = Math.Min(h - 1, y + 1);
            for (int x = 0; x < w; x++)
            {
                int xm = Math.Max(0, x - 1), xp = Math.Min(w - 1, x + 1);
                for (int ch = 0; ch < c; ch++)
                {
                    int sum = 0;
                    sum += s[(ym * w + xm) * c + ch] + s[(ym * w + x) * c + ch] + s[(ym * w + xp) * c + ch];
                    sum += s[(y * w + xm) * c + ch] + s[(y * w + x) * c + ch] + s[(y * w + xp) * c + ch];
                    sum += s[(yp * w + xm) * c + ch] + s[(yp * w + x) * c + ch] + s[(yp * w + xp) * c + ch];
                    int v = s[(y * w + x) * c + ch];
                    dst[(y * w + x) * c + ch] = (byte)Math.Clamp(Math.Round(v + k * (v - sum / 9.0)), 0, 255);
                }
            }
        }
        return new RasterImage(w, h, c, dst, src.Dpi);
    }

    /// <summary>Noir et blanc pur, par seuil local (le texte reste net même sur fond irrégulier).</summary>
    public static RasterImage ToBlackWhite(RasterImage src)
    {
        var gray = ImageOps.ToGray(src);
        var mask = ImageOps.LocalThreshold(gray, 0.15, minContrast: 20, maxInk: 230, solidDark: 80);
        var dst = new byte[gray.Width * gray.Height];
        for (int i = 0; i < dst.Length; i++) dst[i] = mask[i] != 0 ? (byte)0 : (byte)255;
        return new RasterImage(gray.Width, gray.Height, 1, dst, src.Dpi);
    }
}
