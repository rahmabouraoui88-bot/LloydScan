namespace LloydScan.Core.Imaging;

/// <summary>Opérations d'image élémentaires, en C# pur (aucune dépendance native).</summary>
public static class ImageOps
{
    /// <summary>Conversion en niveaux de gris (luminance BT.601).</summary>
    public static RasterImage ToGray(RasterImage src)
    {
        if (src.IsGray) return src;
        var dst = new byte[src.Width * src.Height];
        var p = src.Pixels;
        for (int i = 0, j = 0; i < dst.Length; i++, j += 3)
            dst[i] = (byte)((p[j] * 77 + p[j + 1] * 150 + p[j + 2] * 29) >> 8);
        return new RasterImage(src.Width, src.Height, 1, dst, src.Dpi);
    }

    /// <summary>Réduction par moyenne de surface (filtre boîte) — rapide et sans crénelage.</summary>
    public static RasterImage Resize(RasterImage src, int dw, int dh)
    {
        dw = Math.Max(1, dw); dh = Math.Max(1, dh);
        if (dw >= src.Width && dh >= src.Height) return src;
        dw = Math.Min(dw, src.Width); dh = Math.Min(dh, src.Height);

        int c = src.Channels, sw = src.Width, sh = src.Height, stride = src.Stride;
        var xs0 = new int[dw]; var xs1 = new int[dw];
        for (int x = 0; x < dw; x++)
        {
            xs0[x] = (int)((long)x * sw / dw);
            xs1[x] = Math.Max(xs0[x] + 1, (int)((long)(x + 1) * sw / dw));
        }
        var dst = new byte[dw * dh * c];
        var acc = new int[dw * c];
        var sp = src.Pixels;
        for (int y = 0; y < dh; y++)
        {
            int sy0 = (int)((long)y * sh / dh);
            int sy1 = Math.Max(sy0 + 1, (int)((long)(y + 1) * sh / dh));
            Array.Clear(acc);
            for (int sy = sy0; sy < sy1; sy++)
            {
                int row = sy * stride;
                for (int x = 0; x < dw; x++)
                {
                    int a = x * c;
                    for (int sx = xs0[x]; sx < xs1[x]; sx++)
                    {
                        int o = row + sx * c;
                        acc[a] += sp[o];
                        if (c == 3) { acc[a + 1] += sp[o + 1]; acc[a + 2] += sp[o + 2]; }
                    }
                }
            }
            int rows = sy1 - sy0, drow = y * dw * c;
            for (int x = 0; x < dw; x++)
            {
                int n = rows * (xs1[x] - xs0[x]), a = x * c;
                for (int k = 0; k < c; k++) dst[drow + a + k] = (byte)((acc[a + k] + n / 2) / n);
            }
        }
        double dpi = src.Dpi * dw / sw;
        return new RasterImage(dw, dh, c, dst, dpi);
    }

    /// <summary>Ramène l'image à la résolution cible si elle est plus élevée.</summary>
    public static RasterImage ScaleToDpi(RasterImage src, double targetDpi)
    {
        if (targetDpi <= 0 || src.Dpi <= targetDpi * 1.05) return src;
        double f = targetDpi / src.Dpi;
        var r = Resize(src, (int)Math.Round(src.Width * f), (int)Math.Round(src.Height * f));
        r.Dpi = targetDpi;
        return r;
    }

    public static RasterImage ScaleToWidth(RasterImage src, int width)
    {
        if (src.Width <= width) return src;
        int h = Math.Max(1, (int)Math.Round((double)src.Height * width / src.Width));
        return Resize(src, width, h);
    }

    /// <summary>
    /// Part des pixels nettement colorés (encre bleue, tampon rouge, logo).
    /// Les pixels quasi noirs ou quasi blancs sont ignorés pour ne pas compter les franges du scanner.
    /// </summary>
    public static double ColorRatio(RasterImage src, int chromaThreshold = 60)
    {
        if (src.IsGray) return 0;
        var p = src.Pixels;
        long colored = 0, sampled = 0;
        for (int y = 0; y < src.Height; y += 2)
        {
            int row = y * src.Stride;
            for (int x = 0; x < src.Width; x += 2)
            {
                int o = row + x * 3;
                int r = p[o], g = p[o + 1], b = p[o + 2];
                int max = Math.Max(r, Math.Max(g, b)), min = Math.Min(r, Math.Min(g, b));
                sampled++;
                if (max - min >= chromaThreshold && max > 50) colored++;
            }
        }
        return sampled == 0 ? 0 : (double)colored / sampled;
    }

    /// <summary>
    /// Seuillage local (Bradley-Roth) sur image grise : 1 = encre.
    /// Un pixel est de l'encre s'il est nettement plus sombre que la moyenne de son voisinage.
    /// </summary>
    /// <param name="sensitivity">Écart relatif à la moyenne locale (0,15 = 15 %).</param>
    /// <param name="minContrast">Écart absolu minimal, évite le bruit dans les aplats.</param>
    /// <param name="maxInk">Un pixel plus clair que cette valeur n'est jamais de l'encre.</param>
    /// <param name="solidDark">Si &gt; 0, tout pixel plus sombre est de l'encre (aplats noirs en mode noir et blanc).</param>
    /// <param name="detectInverse">Marque aussi (valeur 2) le texte clair sur fond sombre (logos, bandeaux).</param>
    public static byte[] LocalThreshold(RasterImage gray, double sensitivity = 0.15, int minContrast = 20,
                                        int maxInk = 215, int solidDark = 0, double windowMm = 5.0,
                                        bool detectInverse = false)
    {
        if (!gray.IsGray) gray = ToGray(gray);
        int w = gray.Width, h = gray.Height;
        int r = Math.Max(4, (int)Math.Round(gray.Dpi / 25.4 * windowMm / 2));
        var g = gray.Pixels;

        // Image intégrale (uint suffit : 255 × 2480 × 3508 < 2^32).
        int iw = w + 1;
        var integ = new uint[(long)iw * (h + 1)];
        for (int y = 0; y < h; y++)
        {
            uint rowSum = 0;
            int gi = y * w, ii = (y + 1) * iw;
            for (int x = 0; x < w; x++)
            {
                rowSum += g[gi + x];
                integ[ii + x + 1] = integ[ii - iw + x + 1] + rowSum;
            }
        }

        var mask = new byte[w * h];
        double factor = 1.0 - sensitivity;
        for (int y = 0; y < h; y++)
        {
            int y0 = Math.Max(0, y - r), y1 = Math.Min(h, y + r + 1);
            for (int x = 0; x < w; x++)
            {
                int v = g[y * w + x];
                if (v > maxInk && !detectInverse) continue;
                if (solidDark > 0 && v < solidDark) { mask[y * w + x] = 1; continue; }
                int x0 = Math.Max(0, x - r), x1 = Math.Min(w, x + r + 1);
                uint sum = integ[y1 * iw + x1] - integ[y0 * iw + x1] - integ[y1 * iw + x0] + integ[y0 * iw + x0];
                int area = (x1 - x0) * (y1 - y0);
                double mean = (double)sum / area;
                if (v <= maxInk && v < mean * factor && mean - v >= minContrast) mask[y * w + x] = 1;
                else if (detectInverse && mean < 140 && v > 150 && v > mean * (2 - factor) && v - mean >= minContrast)
                    mask[y * w + x] = 2; // texte clair sur aplat sombre
            }
        }
        return mask;
    }

    /// <summary>Supprime les points d'encre isolés (aucun voisin sur 8).</summary>
    public static int Despeckle(byte[] mask, int w, int h)
    {
        int removed = 0;
        for (int y = 0; y < h; y++)
        {
            for (int x = 0; x < w; x++)
            {
                int i = y * w + x;
                if (mask[i] == 0) continue;
                bool hasNeighbor = false;
                for (int dy = -1; dy <= 1 && !hasNeighbor; dy++)
                {
                    int yy = y + dy;
                    if ((uint)yy >= (uint)h) continue;
                    for (int dx = -1; dx <= 1; dx++)
                    {
                        if (dx == 0 && dy == 0) continue;
                        int xx = x + dx;
                        if ((uint)xx >= (uint)w) continue;
                        if (mask[yy * w + xx] != 0) { hasNeighbor = true; break; }
                    }
                }
                if (!hasNeighbor) { mask[i] = 0; removed++; }
            }
        }
        return removed;
    }

    /// <summary>Dilatation 3×3 (le masque grossit d'un pixel).</summary>
    public static byte[] Dilate(byte[] mask, int w, int h)
    {
        var tmp = new byte[mask.Length];
        for (int y = 0; y < h; y++)
        {
            int row = y * w;
            for (int x = 0; x < w; x++)
            {
                if (mask[row + x] != 0 || (x > 0 && mask[row + x - 1] != 0) || (x < w - 1 && mask[row + x + 1] != 0))
                    tmp[row + x] = 1;
            }
        }
        var dst = new byte[mask.Length];
        for (int y = 0; y < h; y++)
        {
            int row = y * w;
            for (int x = 0; x < w; x++)
            {
                if (tmp[row + x] != 0 || (y > 0 && tmp[row - w + x] != 0) || (y < h - 1 && tmp[row + w + x] != 0))
                    dst[row + x] = 1;
            }
        }
        return dst;
    }

    /// <summary>
    /// Réduction d'un facteur entier en ne moyennant que les pixels sélectionnés par le masque
    /// (<paramref name="takeInk"/> = true : pixels d'encre, sinon pixels de fond).
    /// Les blocs sans pixel utile sont comblés par diffusion depuis leurs voisins.
    /// </summary>
    public static RasterImage MaskedDownscale(RasterImage src, byte[] mask, int factor, bool takeInk, byte fallback)
    {
        factor = Math.Max(1, factor);
        int c = src.Channels, w = src.Width, h = src.Height;
        int dw = (w + factor - 1) / factor, dh = (h + factor - 1) / factor;
        var sum = new long[dw * dh * c];
        var cnt = new long[dw * dh];
        var p = src.Pixels;
        byte want = (byte)(takeInk ? 1 : 0);
        for (int y = 0; y < h; y++)
        {
            int by = y / factor;
            for (int x = 0; x < w; x++)
            {
                int i = y * w + x;
                if ((mask[i] != 0 ? (byte)1 : (byte)0) != want) continue;
                int b = by * dw + x / factor;
                int o = i * c;
                // Encre : le cœur du trait pèse plus que son bord anticrénelé (couleur fidèle, non délavée)
                long wgt = 1;
                if (takeInk)
                {
                    int l = c == 3 ? (p[o] * 77 + p[o + 1] * 150 + p[o + 2] * 29) >> 8 : p[o];
                    wgt = (long)(256 - l) * (256 - l);
                }
                cnt[b] += wgt;
                for (int k = 0; k < c; k++) sum[b * c + k] += p[o + k] * wgt;
            }
        }

        var dst = new byte[dw * dh * c];
        var filled = new bool[dw * dh];
        int empty = 0;
        for (int b = 0; b < cnt.Length; b++)
        {
            if (cnt[b] == 0) { empty++; continue; }
            filled[b] = true;
            for (int k = 0; k < c; k++) dst[b * c + k] = (byte)(sum[b * c + k] / cnt[b]);
        }

        // Comblement des trous par diffusion (quelques passes suffisent : les trous sont des traits de texte).
        var acc = new int[c];
        for (int pass = 0; pass < 64 && empty > 0; pass++)
        {
            var newly = new List<int>();
            for (int y = 0; y < dh; y++)
            {
                for (int x = 0; x < dw; x++)
                {
                    int b = y * dw + x;
                    if (filled[b]) continue;
                    int n = 0; Array.Clear(acc);
                    void Take(int nb) { if (filled[nb]) { n++; for (int k = 0; k < c; k++) acc[k] += dst[nb * c + k]; } }
                    if (x > 0) Take(b - 1);
                    if (x < dw - 1) Take(b + 1);
                    if (y > 0) Take(b - dw);
                    if (y < dh - 1) Take(b + dw);
                    if (n == 0) continue;
                    for (int k = 0; k < c; k++) dst[b * c + k] = (byte)(acc[k] / n);
                    newly.Add(b);
                }
            }
            if (newly.Count == 0) break;
            foreach (var b in newly) filled[b] = true;
            empty -= newly.Count;
        }
        if (empty > 0)
            for (int b = 0; b < filled.Length; b++)
                if (!filled[b]) for (int k = 0; k < c; k++) dst[b * c + k] = fallback;

        return new RasterImage(dw, dh, c, dst, src.Dpi / factor);
    }

    /// <summary>
    /// Remplace par une teinte unique les pixels qui ressemblent à l'encre du texte (peu saturés, non blancs).
    /// Les couleurs franches (encre bleue, tampons rouges) sont conservées.
    /// </summary>
    public static void FlattenNeutral(RasterImage img, byte tone, int chromaThreshold, int limit = 200)
    {
        var p = img.Pixels;
        if (img.IsGray)
        {
            for (int i = 0; i < p.Length; i++) if (p[i] < limit) p[i] = tone;
            return;
        }
        for (int o = 0; o < p.Length; o += 3)
        {
            int r = p[o], g = p[o + 1], b = p[o + 2];
            int max = Math.Max(r, Math.Max(g, b)), min = Math.Min(r, Math.Min(g, b));
            if (max - min < chromaThreshold && ((r * 77 + g * 150 + b * 29) >> 8) < limit)
            { p[o] = tone; p[o + 1] = tone; p[o + 2] = tone; }
        }
    }

    /// <summary>
    /// Part de la page occupée par des aplats de teinte moyenne (photos, schémas couleur).
    /// Calculée à ~50 dpi : le texte y devient une texture très contrastée et n'est pas compté.
    /// </summary>
    public static double PictureRatio(RasterImage src)
    {
        var g = ToGray(ScaleToDpi(src, 50));
        int w = g.Width, h = g.Height;
        var p = g.Pixels;
        long flat = 0, total = 0;
        for (int y = 1; y < h - 1; y++)
        {
            for (int x = 1; x < w - 1; x++)
            {
                total++;
                int v = p[y * w + x];
                if (v < 40 || v > 205) continue;
                int min = 255, max = 0;
                for (int dy = -1; dy <= 1; dy++)
                    for (int dx = -1; dx <= 1; dx++)
                    {
                        int n = p[(y + dy) * w + x + dx];
                        if (n < min) min = n;
                        if (n > max) max = n;
                    }
                if (max - min < 45) flat++;
            }
        }
        return total == 0 ? 0 : (double)flat / total;
    }

    /// <summary>
    /// Dans une image réduite d'un facteur <paramref name="factor"/>, peint en <paramref name="color"/>
    /// les blocs contenant au moins un pixel du masque égal à <paramref name="value"/> et encore à la teinte neutre.
    /// </summary>
    /// <summary>
    /// Assombrit l'encre de couleur trop claire de la petite image de couleur du texte, en conservant sa teinte :
    /// chaque canal est multiplié pour ramener la luminance à <paramref name="target"/>. Les blocs contenant du
    /// texte clair sur fond sombre (valeur 2 du masque) et la teinte neutre déjà uniformisée ne sont pas touchés.
    /// </summary>
    public static void DarkenInk(RasterImage small, byte[] mask, int fullWidth, int fullHeight, int factor, byte neutralTone, int target)
    {
        if (small.Channels != 3) return;
        var inverse = new bool[small.Width * small.Height];
        for (int y = 0; y < fullHeight; y++)
        {
            int row = y * fullWidth, by = Math.Min(small.Height - 1, y / factor) * small.Width;
            for (int x = 0; x < fullWidth; x++)
                if (mask[row + x] == 2) inverse[by + Math.Min(small.Width - 1, x / factor)] = true;
        }
        var p = small.Pixels;
        for (int i = 0, o = 0; i < inverse.Length; i++, o += 3)
        {
            if (inverse[i]) continue;
            int r = p[o], g = p[o + 1], b = p[o + 2];
            if (r == neutralTone && g == neutralTone && b == neutralTone) continue;
            int l = (r * 77 + g * 150 + b * 29) >> 8;
            if (l <= target) continue;
            double k = (double)target / l;
            p[o] = (byte)(r * k); p[o + 1] = (byte)(g * k); p[o + 2] = (byte)(b * k);
        }
    }

    public static void PaintBlocks(RasterImage small, byte[] mask, int fullWidth, int fullHeight, int factor,
                                   byte value, byte neutralTone, byte color)
    {
        int c = small.Channels;
        var p = small.Pixels;
        for (int y = 0; y < fullHeight; y++)
        {
            int row = y * fullWidth, by = y / factor;
            for (int x = 0; x < fullWidth; x++)
            {
                if (mask[row + x] != value) continue;
                int o = (by * small.Width + x / factor) * c;
                if (p[o] != neutralTone || (c == 3 && (p[o + 1] != neutralTone || p[o + 2] != neutralTone))) continue;
                for (int k = 0; k < c; k++) p[o + k] = color;
            }
        }
    }

    /// <summary>
    /// Percentile des niveaux de gris des pixels du masque égaux à <paramref name="value"/>.
    /// Le 25e percentile donne la teinte « cœur de trait » de l'encre, sans l'anticrénelage plus clair.
    /// </summary>
    public static int PercentileOver(RasterImage gray, byte[] mask, double percentile, byte value = 1)
    {
        var hist = new long[256];
        long n = 0;
        var g = gray.Pixels;
        for (int i = 0; i < mask.Length; i++)
            if (mask[i] == value) { hist[g[i]]++; n++; }
        if (n == 0) return value == 1 ? 0 : 255;
        long target = (long)(n * percentile), acc = 0;
        for (int v = 0; v < 256; v++) { acc += hist[v]; if (acc > target) return v; }
        return 255;
    }

    /// <summary>Recadre en retirant une marge relative sur chaque bord.</summary>
    public static RasterImage CropMargins(RasterImage src, double marginRatio)
    {
        int mx = (int)(src.Width * marginRatio), my = (int)(src.Height * marginRatio);
        int w = src.Width - 2 * mx, h = src.Height - 2 * my;
        if (w < 8 || h < 8) return src;
        int c = src.Channels;
        var dst = new byte[w * h * c];
        for (int y = 0; y < h; y++)
            Buffer.BlockCopy(src.Pixels, ((y + my) * src.Width + mx) * c, dst, y * w * c, w * c);
        return new RasterImage(w, h, c, dst, src.Dpi);
    }
}
