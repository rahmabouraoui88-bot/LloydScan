using LloydScan.Core.Configuration;

namespace LloydScan.Core.Imaging;

/// <summary>Bilan d'un nettoyage (affiché à l'agent et utile en recette).</summary>
public sealed record CleanupReport(int BorderPixels, int PunchHoles, double DeskewAngle)
{
    public override string ToString()
    {
        var parts = new List<string>();
        if (BorderPixels > 0) parts.Add("bords effacés");
        if (PunchHoles > 0) parts.Add($"{PunchHoles} trou(s) effacé(s)");
        if (Math.Abs(DeskewAngle) >= 0.05) parts.Add($"redressée de {DeskewAngle:+0.0;-0.0}°");
        return parts.Count == 0 ? "" : string.Join(", ", parts);
    }
}

/// <summary>
/// Nettoyage des pages avant optimisation :
///  - bords sombres (fond noir du scanner visible autour d'une page de travers ou plus petite) ;
///  - trous de perforation dans les marges ;
///  - redressement logiciel (si le pilote ne l'a pas fait).
/// </summary>
public static class ImageCleaner
{
    public static (RasterImage image, CleanupReport report) Clean(RasterImage src, CleanupSettings s)
    {
        var img = Clone(src);
        var paper = PaperColor(img);
        int border = s.RemoveBorders ? RemoveDarkBorders(img, paper, s.BorderMaxMm) : 0;
        int holes = s.RemovePunchHoles ? RemovePunchHoles(img, paper) : 0;
        double angle = 0;
        if (s.Deskew)
        {
            angle = EstimateSkew(img, s.DeskewMaxDegrees);
            if (Math.Abs(angle) >= 0.15) img = Rotate(img, -angle, paper);
            else angle = 0;
        }
        return (img, new CleanupReport(border, holes, angle));
    }

    private static RasterImage Clone(RasterImage src) =>
        new(src.Width, src.Height, src.Channels, (byte[])src.Pixels.Clone(), src.Dpi);

    /// <summary>Couleur du papier : moyenne des 10 % de pixels les plus clairs.</summary>
    public static byte[] PaperColor(RasterImage img)
    {
        var gray = ImageOps.ToGray(ImageOps.ScaleToDpi(img, 50));
        var hist = new int[256];
        foreach (var v in gray.Pixels) hist[v]++;
        int target = gray.Pixels.Length / 10, acc = 0, threshold = 255;
        for (int v = 255; v >= 0; v--) { acc += hist[v]; if (acc >= target) { threshold = v; break; } }

        var small = ImageOps.ScaleToDpi(img, 50);
        long[] sum = new long[small.Channels]; long n = 0;
        for (int i = 0; i < gray.Pixels.Length; i++)
        {
            if (gray.Pixels[i] < threshold) continue;
            for (int k = 0; k < small.Channels; k++) sum[k] += small.Pixels[i * small.Channels + k];
            n++;
        }
        return n == 0 ? Enumerable.Repeat((byte)255, img.Channels).ToArray() : sum.Select(v => (byte)(v / n)).ToArray();
    }

    private static int Lum(RasterImage img, int idx)
    {
        var p = img.Pixels;
        return img.IsGray ? p[idx] : (p[idx * 3] * 77 + p[idx * 3 + 1] * 150 + p[idx * 3 + 2] * 29) >> 8;
    }

    private static void Paint(RasterImage img, int idx, byte[] color)
    {
        int c = img.Channels;
        for (int k = 0; k < c; k++) img.Pixels[idx * c + k] = color[k];
    }

    /// <summary>
    /// Efface les zones sombres qui touchent un bord de l'image (fond du scanner), sur une profondeur limitée.
    /// Le texte proche des marges n'est pas touché tant qu'il ne touche pas le bord.
    /// </summary>
    public static int RemoveDarkBorders(RasterImage img, byte[] paper, double maxMm, int darkThreshold = 90)
    {
        int w = img.Width, h = img.Height, painted = 0;
        int maxX = Math.Min(w / 3, (int)(img.Dpi / 25.4 * maxMm));
        int maxY = Math.Min(h / 3, (int)(img.Dpi / 25.4 * maxMm));

        // Pour chaque ligne et colonne : on efface la plage sombre qui part du bord,
        // plus une frange de transition (~0,3 mm) pour ne pas laisser de liseré gris.
        int fringe = Math.Max(1, (int)(img.Dpi / 25.4 * 0.3));
        void Run(int start, int step, int limit, Func<int, int> index)
        {
            int k = 0;
            while (k < limit && Lum(img, index(start + k * step)) < darkThreshold) { Paint(img, index(start + k * step), paper); painted++; k++; }
            if (k == 0) return;
            for (int f = 0; f < fringe && k < limit; f++, k++) Paint(img, index(start + k * step), paper);
        }
        for (int y = 0; y < h; y++)
        {
            int row = y * w;
            Run(0, 1, maxX, x => row + x);
            Run(w - 1, -1, maxX, x => row + x);
        }
        for (int x = 0; x < w; x++)
        {
            int col = x;
            Run(0, 1, maxY, y => y * w + col);
            Run(h - 1, -1, maxY, y => y * w + col);
        }
        // Ne compter que si l'effacement est significatif (au moins une ligne de 5 mm)
        return painted > img.Dpi / 25.4 * 5 ? painted : 0;
    }

    /// <summary>
    /// Trous de perforation : taches sombres quasi circulaires de 4 à 9 mm dans une bande de 25 mm le long des bords.
    /// Détection à 75 dpi (composantes connexes), effacement à pleine résolution avec la couleur du papier.
    /// </summary>
    public static int RemovePunchHoles(RasterImage img, byte[] paper)
    {
        var small = ImageOps.ToGray(ImageOps.ScaleToDpi(img, 75));
        int w = small.Width, h = small.Height;
        double pxPerMm = small.Dpi / 25.4;
        int band = (int)(25 * pxPerMm);
        double minD = 4 * pxPerMm, maxD = 9 * pxPerMm;
        var visited = new bool[w * h];
        var g = small.Pixels;
        int found = 0;
        var queue = new Queue<int>();

        for (int y = 0; y < h; y++)
        {
            for (int x = 0; x < w; x++)
            {
                bool inBand = x < band || x >= w - band || y < band || y >= h - band;
                int i = y * w + x;
                if (!inBand || visited[i] || g[i] >= 110) continue;

                // Composante connexe sombre
                int minX = x, maxX = x, minY = y, maxY = y, area = 0;
                bool touchesEdge = false;
                queue.Enqueue(i); visited[i] = true;
                while (queue.Count > 0)
                {
                    int j = queue.Dequeue(), jx = j % w, jy = j / w;
                    area++;
                    minX = Math.Min(minX, jx); maxX = Math.Max(maxX, jx);
                    minY = Math.Min(minY, jy); maxY = Math.Max(maxY, jy);
                    if (jx == 0 || jy == 0 || jx == w - 1 || jy == h - 1) touchesEdge = true;
                    if (area > maxD * maxD * 2) continue; // trop grand : on finit d'explorer sans retenir
                    foreach (int n in new[] { j - 1, j + 1, j - w, j + w })
                    {
                        if (n < 0 || n >= g.Length || visited[n]) continue;
                        if ((n == j - 1 && jx == 0) || (n == j + 1 && jx == w - 1)) continue;
                        if (g[n] >= 110) continue;
                        visited[n] = true;
                        queue.Enqueue(n);
                    }
                }

                double bw = maxX - minX + 1, bh = maxY - minY + 1;
                double fill = area / (bw * bh);
                bool round = bw >= minD && bw <= maxD && bh >= minD && bh <= maxD
                             && Math.Abs(bw - bh) <= Math.Max(bw, bh) * 0.25
                             && fill > 0.55 && fill < 0.95;
                if (!round || touchesEdge) continue;

                // Effacement à pleine résolution (cercle agrandi de 1 mm)
                double scale = img.Dpi / small.Dpi;
                double cx = (minX + maxX + 1) / 2.0 * scale, cy = (minY + maxY + 1) / 2.0 * scale;
                double r = (Math.Max(bw, bh) / 2.0 + pxPerMm) * scale;
                int x0 = Math.Max(0, (int)(cx - r)), x1 = Math.Min(img.Width - 1, (int)(cx + r));
                int y0 = Math.Max(0, (int)(cy - r)), y1 = Math.Min(img.Height - 1, (int)(cy + r));
                for (int yy = y0; yy <= y1; yy++)
                    for (int xx = x0; xx <= x1; xx++)
                        if ((xx - cx) * (xx - cx) + (yy - cy) * (yy - cy) <= r * r)
                            Paint(img, yy * img.Width + xx, paper);
                found++;
            }
        }
        return found;
    }

    /// <summary>
    /// Angle d'inclinaison du texte (degrés, positif = sens horaire) par maximisation de la variance
    /// du profil de projection horizontal des pixels d'encre, à 100 dpi.
    /// </summary>
    public static double EstimateSkew(RasterImage img, double maxDegrees)
    {
        var gray = ImageOps.ToGray(ImageOps.ScaleToDpi(img, 100));
        var mask = ImageOps.LocalThreshold(gray, 0.2, minContrast: 30, maxInk: 180);
        int w = gray.Width, h = gray.Height;
        var xs = new List<int>(); var ys = new List<int>();
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++)
                if (mask[y * w + x] != 0) { xs.Add(x); ys.Add(y); }
        if (xs.Count < 500) return 0; // trop peu de texte pour décider

        // Sous-échantillonnage pour la rapidité
        int step = Math.Max(1, xs.Count / 60000);
        double Score(double deg)
        {
            double t = Math.Tan(deg * Math.PI / 180);
            int bins = h + (int)(Math.Abs(t) * w) + 2, offset = (int)(Math.Abs(t) * w) + 1;
            var hist = new int[bins];
            for (int i = 0; i < xs.Count; i += step)
            {
                int b = (int)Math.Round(ys[i] - xs[i] * t) + offset;
                if ((uint)b < (uint)bins) hist[b]++;
            }
            double s = 0; foreach (var v in hist) s += (double)v * v;
            return s;
        }

        double best = 0, bestScore = Score(0);
        for (double a = -maxDegrees; a <= maxDegrees + 1e-9; a += 0.25)
        {
            double sc = Score(a);
            if (sc > bestScore) { bestScore = sc; best = a; }
        }
        double center = best;
        for (double a = center - 0.25; a <= center + 0.25 + 1e-9; a += 0.05)
        {
            double sc = Score(a);
            if (sc > bestScore) { bestScore = sc; best = a; }
        }
        return Math.Round(best, 2);
    }

    /// <summary>Rotation d'un angle quelconque (degrés, sens horaire), interpolation bilinéaire, coins remplis de papier.</summary>
    public static RasterImage Rotate(RasterImage src, double degrees, byte[] fill)
    {
        int w = src.Width, h = src.Height, c = src.Channels;
        var dst = new byte[src.Pixels.Length];
        double rad = degrees * Math.PI / 180, cos = Math.Cos(rad), sin = Math.Sin(rad);
        double cx = (w - 1) / 2.0, cy = (h - 1) / 2.0;
        var p = src.Pixels;
        Parallel.For(0, h, y =>
        {
            double dy = y - cy;
            for (int x = 0; x < w; x++)
            {
                double dx = x - cx;
                // rotation inverse : position source du pixel destination
                double sx = cos * dx + sin * dy + cx, sy = -sin * dx + cos * dy + cy;
                int o = (y * w + x) * c;
                int x0 = (int)Math.Floor(sx), y0 = (int)Math.Floor(sy);
                if (x0 < 0 || y0 < 0 || x0 >= w - 1 || y0 >= h - 1)
                {
                    for (int k = 0; k < c; k++) dst[o + k] = fill[k];
                    continue;
                }
                double fx = sx - x0, fy = sy - y0;
                int i00 = (y0 * w + x0) * c, i10 = i00 + c, i01 = i00 + w * c, i11 = i01 + c;
                for (int k = 0; k < c; k++)
                {
                    double v = p[i00 + k] * (1 - fx) * (1 - fy) + p[i10 + k] * fx * (1 - fy)
                             + p[i01 + k] * (1 - fx) * fy + p[i11 + k] * fx * fy;
                    dst[o + k] = (byte)(v + 0.5);
                }
            }
        });
        return new RasterImage(w, h, c, dst, src.Dpi);
    }

    /// <summary>Rotation exacte par quarts de tour (vignettes).</summary>
    public static RasterImage RotateQuarter(RasterImage src, int degrees)
    {
        degrees = ((degrees % 360) + 360) % 360;
        if (degrees == 0) return src;
        int w = src.Width, h = src.Height, c = src.Channels;
        bool swap = degrees != 180;
        int dw = swap ? h : w, dh = swap ? w : h;
        var dst = new byte[src.Pixels.Length];
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++)
            {
                int nx, ny;
                switch (degrees)
                {
                    case 90: nx = h - 1 - y; ny = x; break;      // sens horaire
                    case 180: nx = w - 1 - x; ny = h - 1 - y; break;
                    default: nx = y; ny = w - 1 - x; break;      // 270
                }
                Buffer.BlockCopy(src.Pixels, (y * w + x) * c, dst, (ny * dw + nx) * c, c);
            }
        return new RasterImage(dw, dh, c, dst, src.Dpi);
    }
}
