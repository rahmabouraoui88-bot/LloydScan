namespace LloydScan.Core.Imaging;

/// <summary>
/// Encodeur CCITT Groupe 4 (ITU-T T.6), le format sans perte de référence pour les scans 1 bit.
/// 2 à 4 fois plus compact que Flate sur du texte, décodé nativement par tous les lecteurs PDF.
/// Convention : bit 1 = noir (encre). À déclarer avec /K -1 /BlackIs1 true.
/// </summary>
public static class CcittG4Encoder
{
    public static byte[] Encode(BitPlane plane)
    {
        int w = plane.Width;
        var writer = new BitWriter(plane.Bits.Length / 8 + 1024);
        var reference = new byte[plane.RowBytes]; // ligne de référence imaginaire : blanche
        var coding = new byte[plane.RowBytes];
        for (int y = 0; y < plane.Height; y++)
        {
            Buffer.BlockCopy(plane.Bits, y * plane.RowBytes, coding, 0, plane.RowBytes);
            EncodeRow(writer, coding, reference, w);
            (reference, coding) = (coding, reference);
        }
        // EOFB : deux EOL
        writer.Write(0x001, 12);
        writer.Write(0x001, 12);
        return writer.ToArray();
    }

    private static int Pixel(byte[] line, int x) => (line[x >> 3] >> (7 - (x & 7))) & 1;

    /// <summary>Première position ≥ start dont la couleur diffère de <paramref name="color"/> (ou width).</summary>
    private static int FindDiff(byte[] line, int start, int width, int color)
    {
        int x = start;
        // Saut rapide par octets entiers homogènes
        while (x < width)
        {
            if ((x & 7) == 0 && x + 8 <= width)
            {
                byte b = line[x >> 3];
                if ((color == 0 && b == 0x00) || (color == 1 && b == 0xFF)) { x += 8; continue; }
            }
            if (Pixel(line, x) != color) return x;
            x++;
        }
        return width;
    }

    private static int FindDiff2(byte[] line, int start, int width, int color) =>
        start < width ? FindDiff(line, start, width, color) : width;

    private static void EncodeRow(BitWriter wr, byte[] bp, byte[] rp, int bits)
    {
        int a0 = 0;
        int a1 = Pixel(bp, 0) != 0 ? 0 : FindDiff(bp, 0, bits, 0);
        int b1 = Pixel(rp, 0) != 0 ? 0 : FindDiff(rp, 0, bits, 0);
        while (true)
        {
            int b2 = FindDiff2(rp, b1, bits, b1 < bits ? Pixel(rp, b1) : 0);
            if (b2 >= a1)
            {
                int d = b1 - a1;
                if (d < -3 || d > 3)
                {
                    // Mode horizontal
                    int a2 = FindDiff2(bp, a1, bits, a1 < bits ? Pixel(bp, a1) : 0);
                    wr.Write(0b001, 3);
                    if (a0 + a1 == 0 || Pixel(bp, a0) == 0)
                    {
                        PutSpan(wr, a1 - a0, WhiteCodes, WhiteMakeup);
                        PutSpan(wr, a2 - a1, BlackCodes, BlackMakeup);
                    }
                    else
                    {
                        PutSpan(wr, a1 - a0, BlackCodes, BlackMakeup);
                        PutSpan(wr, a2 - a1, WhiteCodes, WhiteMakeup);
                    }
                    a0 = a2;
                }
                else
                {
                    // Mode vertical
                    var (code, len) = VCodes[d + 3];
                    wr.Write(code, len);
                    a0 = a1;
                }
            }
            else
            {
                // Mode passage
                wr.Write(0b0001, 4);
                a0 = b2;
            }
            if (a0 >= bits) break;
            int c0 = Pixel(bp, a0);
            a1 = FindDiff(bp, a0, bits, c0);
            b1 = FindDiff(rp, a0, bits, 1 - c0);
            b1 = FindDiff(rp, b1, bits, c0);
        }
    }

    private static void PutSpan(BitWriter wr, int span, (int code, int len)[] term, (int code, int len)[] makeup)
    {
        while (span >= 2624)
        {
            var e = Extended[^1]; // 2560
            wr.Write(e.code, e.len);
            span -= 2560;
        }
        if (span >= 64)
        {
            int m = span >> 6; // 1..40
            var e = m <= 27 ? makeup[m - 1] : Extended[m - 28];
            wr.Write(e.code, e.len);
            span -= m << 6;
        }
        var t = term[span];
        wr.Write(t.code, t.len);
    }

    // d = b1 - a1 : -3..+3 → VR3, VR2, VR1, V0, VL1, VL2, VL3
    private static readonly (int, int)[] VCodes =
    {
        (0b0000011, 7), (0b000011, 6), (0b011, 3), (0b1, 1), (0b010, 3), (0b000010, 6), (0b0000010, 7)
    };

    private static (int code, int len)[] Table(params string[] codes) =>
        codes.Select(s => (Convert.ToInt32(s, 2), s.Length)).ToArray();

    private static readonly (int code, int len)[] WhiteCodes = Table(
        "00110101", "000111", "0111", "1000", "1011", "1100", "1110", "1111",
        "10011", "10100", "00111", "01000", "001000", "000011", "110100", "110101",
        "101010", "101011", "0100111", "0001100", "0001000", "0010111", "0000011", "0000100",
        "0101000", "0101011", "0010011", "0100100", "0011000", "00000010", "00000011", "00011010",
        "00011011", "00010010", "00010011", "00010100", "00010101", "00010110", "00010111", "00101000",
        "00101001", "00101010", "00101011", "00101100", "00101101", "00000100", "00000101", "00001010",
        "00001011", "01010010", "01010011", "01010100", "01010101", "00100100", "00100101", "01011000",
        "01011001", "01011010", "01011011", "01001010", "01001011", "00110010", "00110011", "00110100");

    // 64, 128, … 1728
    private static readonly (int code, int len)[] WhiteMakeup = Table(
        "11011", "10010", "010111", "0110111", "00110110", "00110111", "01100100", "01100101",
        "01101000", "01100111", "011001100", "011001101", "011010010", "011010011", "011010100", "011010101",
        "011010110", "011010111", "011011000", "011011001", "011011010", "011011011", "010011000", "010011001",
        "010011010", "011000", "010011011");

    private static readonly (int code, int len)[] BlackCodes = Table(
        "0000110111", "010", "11", "10", "011", "0011", "0010", "00011",
        "000101", "000100", "0000100", "0000101", "0000111", "00000100", "00000111", "000011000",
        "0000010111", "0000011000", "0000001000", "00001100111", "00001101000", "00001101100", "00000110111", "00000101000",
        "00000010111", "00000011000", "000011001010", "000011001011", "000011001100", "000011001101", "000001101000", "000001101001",
        "000001101010", "000001101011", "000011010010", "000011010011", "000011010100", "000011010101", "000011010110", "000011010111",
        "000001101100", "000001101101", "000011011010", "000011011011", "000001010100", "000001010101", "000001010110", "000001010111",
        "000001100100", "000001100101", "000001010010", "000001010011", "000000100100", "000000110111", "000000111000", "000000100111",
        "000000101000", "000001011000", "000001011001", "000000101011", "000000101100", "000001011010", "000001100110", "000001100111");

    private static readonly (int code, int len)[] BlackMakeup = Table(
        "0000001111", "000011001000", "000011001001", "000001011011", "000000110011", "000000110100", "000000110101", "0000001101100",
        "0000001101101", "0000001001010", "0000001001011", "0000001001100", "0000001001101", "0000001110010", "0000001110011", "0000001110100",
        "0000001110101", "0000001110110", "0000001110111", "0000001010010", "0000001010011", "0000001010100", "0000001010101", "0000001011010",
        "0000001011011", "0000001100100", "0000001100101");

    // 1792 … 2560 (communs blanc/noir)
    private static readonly (int code, int len)[] Extended = Table(
        "00000001000", "00000001100", "00000001101", "000000010010", "000000010011", "000000010100", "000000010101",
        "000000010110", "000000010111", "000000011100", "000000011101", "000000011110", "000000011111");

    private sealed class BitWriter
    {
        private readonly MemoryStream _ms;
        private int _acc, _n;
        public BitWriter(int capacity) => _ms = new MemoryStream(capacity);

        public void Write(int code, int len)
        {
            for (int i = len - 1; i >= 0; i--)
            {
                _acc = (_acc << 1) | ((code >> i) & 1);
                if (++_n == 8) { _ms.WriteByte((byte)_acc); _acc = 0; _n = 0; }
            }
        }

        public byte[] ToArray()
        {
            if (_n > 0) { _ms.WriteByte((byte)(_acc << (8 - _n))); _acc = 0; _n = 0; }
            return _ms.ToArray();
        }
    }
}
