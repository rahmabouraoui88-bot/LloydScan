namespace LloydScan.Core.Imaging;

/// <summary>Décodage des images reçues (BMP du pilote TWAIN, TIFF/JPEG/PNG importés) et encodage JPEG.</summary>
public interface IImageCodec
{
    /// <summary>Décode un fichier image ; un TIFF multipage renvoie plusieurs pages.</summary>
    IReadOnlyList<RasterImage> Decode(byte[] data);

    /// <summary>Encode en JPEG baseline (gris si 1 canal, RGB si 3 canaux).</summary>
    byte[] EncodeJpeg(RasterImage image, int quality);
}

/// <summary>Lecture de QR code sur une image en niveaux de gris.</summary>
public interface IQrDecoder
{
    /// <summary>Renvoie le texte du premier QR trouvé, ou null.</summary>
    string? Decode(RasterImage gray);
}
