namespace LloydScan.Core.Imaging.Qr;

/// <summary>
/// Lecteur de QR code intégré à LloydScan (aucune bibliothèque externe).
/// Étapes : binarisation, recherche des trois motifs de repérage, motif d'alignement, redressement
/// de perspective, échantillonnage des modules, puis décodage de la matrice (format, Reed-Solomon, données).
/// Prévu pour des pages numérisées : QR imprimé, droit ou tourné (0 à 360°), légèrement incliné ou flou.
/// </summary>
public sealed class QrReader : IQrDecoder
{
    public string? Decode(RasterImage gray)
    {
        if (!gray.IsGray) gray = ImageOps.ToGray(gray);
        int w = gray.Width, h = gray.Height;
        if (w < 21 || h < 21) return null;
        foreach (var black in Binarizations(gray.Pixels, w, h))
        {
            var text = DecodeBinary(black, w, h);
            if (text != null) return text;
        }
        return null;
    }

    /// <summary>Décodage d'une matrice déjà échantillonnée (true = module noir), aussi en miroir.</summary>
    public static string? DecodeMatrix(bool[,] m) => QrMatrixDecoder.Decode(m) ?? QrMatrixDecoder.Decode(Transpose(m));

    private static bool[,] Transpose(bool[,] m)
    {
        int n = m.GetLength(0);
        var t = new bool[n, n];
        for (int y = 0; y < n; y++)
            for (int x = 0; x < n; x++) t[x, y] = m[y, x];
        return t;
    }

    // ------------------------------------------------------------------ binarisation

    /// <summary>Seuil global (Otsu), adapté aux fiches imprimées ; puis seuil local par blocs (éclairage inégal, fond coloré).</summary>
    private static IEnumerable<bool[]> Binarizations(byte[] px, int w, int h)
    {
        yield return Global(px, OtsuThreshold(px));
        yield return LocalBlocks(px, w, h);
    }

    private static int OtsuThreshold(byte[] px)
    {
        var hist = new long[256];
        foreach (var v in px) hist[v]++;
        long total = px.Length, sumAll = 0;
        for (int i = 0; i < 256; i++) sumAll += i * hist[i];
        long wB = 0, sumB = 0; double best = -1; int threshold = 128;
        for (int t = 0; t < 256; t++)
        {
            wB += hist[t];
            if (wB == 0) continue;
            long wF = total - wB;
            if (wF == 0) break;
            sumB += t * hist[t];
            double mB = (double)sumB / wB, mF = (double)(sumAll - sumB) / wF;
            double between = (double)wB * wF * (mB - mF) * (mB - mF);
            if (between > best) { best = between; threshold = t; }
        }
        return threshold;
    }

    private static bool[] Global(byte[] px, int threshold)
    {
        var b = new bool[px.Length];
        for (int i = 0; i < px.Length; i++) b[i] = px[i] <= threshold;
        return b;
    }

    /// <summary>
    /// Seuil local par blocs de 8 px : moyenne de chaque bloc, lissée sur 5 × 5 blocs. Un bloc uniforme
    /// (peu de contraste) prend le seuil de ses voisins, pour que l'intérieur d'un grand carré noir reste noir.
    /// </summary>
    private static bool[] LocalBlocks(byte[] px, int w, int h)
    {
        const int B = 8;
        int bw = (w + B - 1) / B, bh = (h + B - 1) / B;
        var level = new int[bh, bw];
        for (int by = 0; by < bh; by++)
            for (int bx = 0; bx < bw; bx++)
            {
                int min = 255, max = 0, sum = 0, n = 0;
                for (int y = by * B; y < Math.Min(h, by * B + B); y++)
                    for (int x = bx * B; x < Math.Min(w, bx * B + B); x++)
                    {
                        int v = px[y * w + x];
                        sum += v; n++;
                        if (v < min) min = v;
                        if (v > max) max = v;
                    }
                int avg = sum / Math.Max(1, n);
                if (max - min <= 24)
                {
                    avg = min / 2;
                    if (by > 0 && bx > 0)
                    {
                        int neighbors = (level[by - 1, bx] + 2 * level[by, bx - 1] + level[by - 1, bx - 1]) / 4;
                        if (min < neighbors) avg = neighbors;
                    }
                }
                level[by, bx] = avg;
            }
        var black = new bool[w * h];
        for (int by = 0; by < bh; by++)
            for (int bx = 0; bx < bw; bx++)
            {
                int cy = Math.Clamp(by, 2, Math.Max(2, bh - 3)), cx = Math.Clamp(bx, 2, Math.Max(2, bw - 3));
                int sum = 0, n = 0;
                for (int dy = -2; dy <= 2; dy++)
                    for (int dx = -2; dx <= 2; dx++)
                    {
                        int yy = cy + dy, xx = cx + dx;
                        if (yy < 0 || xx < 0 || yy >= bh || xx >= bw) continue;
                        sum += level[yy, xx]; n++;
                    }
                int t = sum / Math.Max(1, n);
                for (int y = by * B; y < Math.Min(h, by * B + B); y++)
                    for (int x = bx * B; x < Math.Min(w, bx * B + B); x++)
                        black[y * w + x] = px[y * w + x] <= t;
            }
        return black;
    }

    // ------------------------------------------------------------------ motifs de repérage

    private sealed class Finder
    {
        public double X, Y, Module;
        public int Count = 1;
    }

    private string? DecodeBinary(bool[] black, int w, int h)
    {
        var finders = FindFinders(black, w, h);
        if (finders.Count < 3) return null;
        foreach (var (tl, tr, bl) in RankTriples(finders).Take(6))
        {
            var text = DecodeAt(black, w, h, tl, tr, bl);
            if (text != null) return text;
        }
        return null;
    }

    private static List<Finder> FindFinders(bool[] black, int w, int h)
    {
        var found = new List<Finder>();
        var counts = new int[5];
        for (int y = 0; y < h; y++)
        {
            Array.Clear(counts);
            int state = 0;
            int row = y * w;
            for (int x = 0; x < w; x++)
            {
                if (black[row + x])
                {
                    if ((state & 1) == 1) state++;
                    counts[state]++;
                }
                else if ((state & 1) == 0)
                {
                    if (state == 4)
                    {
                        if (RatioOk(counts)) TryCenter(black, w, h, counts, y, x, found);
                        counts[0] = counts[2]; counts[1] = counts[3]; counts[2] = counts[4]; counts[3] = 1; counts[4] = 0;
                        state = 3;
                    }
                    else counts[++state]++;
                }
                else counts[state]++;
            }
            if (state == 4 && RatioOk(counts)) TryCenter(black, w, h, counts, y, w, found);
        }
        return found;
    }

    /// <summary>Rapport 1 : 1 : 3 : 1 : 1 (noir, blanc, noir, blanc, noir), avec la tolérance d'une impression scannée.</summary>
    private static bool RatioOk(int[] c)
    {
        int total = 0;
        for (int i = 0; i < 5; i++) { if (c[i] == 0) return false; total += c[i]; }
        if (total < 7) return false;
        double module = total / 7.0, tol = module / 1.5;
        return Math.Abs(module - c[0]) < tol && Math.Abs(module - c[1]) < tol && Math.Abs(3 * module - c[2]) < 3 * tol
            && Math.Abs(module - c[3]) < tol && Math.Abs(module - c[4]) < tol;
    }

    private static void TryCenter(bool[] black, int w, int h, int[] counts, int y, int endX, List<Finder> found)
    {
        int total = counts.Sum();
        double cx = endX - counts[4] - counts[3] - counts[2] / 2.0;
        double cy = CrossCheck(black, w, h, (int)cx, y, counts[2], total, vertical: true, out int vTotal);
        if (double.IsNaN(cy)) return;
        cx = CrossCheck(black, w, h, (int)cx, (int)cy, counts[2], total, vertical: false, out int hTotal);
        if (double.IsNaN(cx)) return;
        double module = (vTotal + hTotal) / 14.0;
        foreach (var f in found)
        {
            if (Math.Abs(f.X - cx) <= f.Module && Math.Abs(f.Y - cy) <= f.Module
                && (Math.Abs(f.Module - module) <= 1 || Math.Abs(f.Module - module) <= f.Module * 0.5))
            {
                int n = f.Count;
                f.X = (f.X * n + cx) / (n + 1); f.Y = (f.Y * n + cy) / (n + 1); f.Module = (f.Module * n + module) / (n + 1);
                f.Count++;
                return;
            }
        }
        found.Add(new Finder { X = cx, Y = cy, Module = module });
    }

    /// <summary>Vérifie le motif dans l'autre direction et renvoie le centre affiné (NaN si ce n'est pas un repère).</summary>
    private static double CrossCheck(bool[] black, int w, int h, int x, int y, int maxCount, int originalTotal, bool vertical, out int total)
    {
        total = 0;
        int limit = vertical ? h : w;
        int start = vertical ? y : x;
        bool B(int p) => vertical ? black[p * w + x] : black[y * w + p];
        if (x < 0 || y < 0 || x >= w || y >= h || !B(start)) return double.NaN;
        var c = new int[5];
        int i = start;
        while (i >= 0 && B(i)) { c[2]++; i--; }
        if (i < 0) return double.NaN;
        while (i >= 0 && !B(i) && c[1] <= maxCount) { c[1]++; i--; }
        if (i < 0 || c[1] > maxCount) return double.NaN;
        while (i >= 0 && B(i) && c[0] <= maxCount) { c[0]++; i--; }
        if (c[0] > maxCount) return double.NaN;
        i = start + 1;
        while (i < limit && B(i)) { c[2]++; i++; }
        if (i == limit) return double.NaN;
        while (i < limit && !B(i) && c[3] <= maxCount) { c[3]++; i++; }
        if (i == limit || c[3] > maxCount) return double.NaN;
        while (i < limit && B(i) && c[4] <= maxCount) { c[4]++; i++; }
        if (c[4] > maxCount) return double.NaN;
        total = c.Sum();
        if (5 * Math.Abs(total - originalTotal) >= 2 * originalTotal) return double.NaN;
        return RatioOk(c) ? i - c[4] - c[3] - c[2] / 2.0 : double.NaN;
    }

    /// <summary>Triplets de repères classés : angle droit, côtés égaux, modules de même taille.</summary>
    private static IEnumerable<(Finder tl, Finder tr, Finder bl)> RankTriples(List<Finder> all)
    {
        var pool = all.Where(f => f.Count >= 2).ToList();
        if (pool.Count < 3) pool = all;
        pool = pool.OrderByDescending(f => f.Count).Take(16).ToList();
        var ranked = new List<(double score, Finder tl, Finder tr, Finder bl)>();
        for (int a = 0; a < pool.Count; a++)
            for (int b = a + 1; b < pool.Count; b++)
                for (int c = b + 1; c < pool.Count; c++)
                {
                    var p = new[] { pool[a], pool[b], pool[c] };
                    double minM = p.Min(f => f.Module), maxM = p.Max(f => f.Module);
                    if (maxM > 1.6 * minM) continue;
                    // Sommet de l'angle droit = opposé au plus grand côté
                    double dab = D(p[0], p[1]), dbc = D(p[1], p[2]), dac = D(p[0], p[2]);
                    Finder corner, s1, s2; double leg1, leg2, hyp;
                    if (dbc >= dab && dbc >= dac) { corner = p[0]; s1 = p[1]; s2 = p[2]; leg1 = dab; leg2 = dac; hyp = dbc; }
                    else if (dac >= dab && dac >= dbc) { corner = p[1]; s1 = p[0]; s2 = p[2]; leg1 = dab; leg2 = dbc; hyp = dac; }
                    else { corner = p[2]; s1 = p[0]; s2 = p[1]; leg1 = dac; leg2 = dbc; hyp = dab; }
                    double module = (minM + maxM) / 2;
                    if (Math.Min(leg1, leg2) / module < 8) continue;             // version 1 : 14 modules entre repères
                    // Côtés inégaux tolérés (résolutions horizontale et verticale différentes, perspective)
                    double legDiff = Math.Abs(leg1 - leg2) / Math.Max(leg1, leg2);
                    double angleErr = Math.Abs(hyp * hyp - (leg1 * leg1 + leg2 * leg2)) / (hyp * hyp);
                    if (legDiff > 0.5 || angleErr > 0.3) continue;
                    // Orientation : (TR - TL) ^ (BL - TL) > 0 dans le repère image (y vers le bas)
                    double cross = (s1.X - corner.X) * (s2.Y - corner.Y) - (s1.Y - corner.Y) * (s2.X - corner.X);
                    var (tr, bl) = cross > 0 ? (s1, s2) : (s2, s1);
                    ranked.Add((legDiff + angleErr + (maxM - minM) / maxM, corner, tr, bl));
                }
        return ranked.OrderBy(r => r.score).Select(r => (r.tl, r.tr, r.bl));
    }

    private static double D(Finder a, Finder b) => Math.Sqrt((a.X - b.X) * (a.X - b.X) + (a.Y - b.Y) * (a.Y - b.Y));

    // ------------------------------------------------------------------ géométrie et échantillonnage

    private static string? DecodeAt(bool[] black, int w, int h, Finder tl, Finder tr, Finder bl)
    {
        // Taille du module mesurée le long des axes du QR (exacte même si le QR est tourné de 45°)
        // Mesure séparée sur chaque axe : tolère un scanner dont la résolution horizontale et verticale diffèrent
        double fallback = (tl.Module + tr.Module + bl.Module) / 3;
        double Mean(params double[] v) { var ok = v.Where(x => !double.IsNaN(x)).ToList(); return ok.Count > 0 ? ok.Average() : fallback; }
        double moduleU = Mean(AxisModule(black, w, h, tl, tr), AxisModule(black, w, h, tr, tl));
        double moduleV = Mean(AxisModule(black, w, h, tl, bl), AxisModule(black, w, h, bl, tl));
        double est = (D(tl, tr) / moduleU + D(tl, bl) / moduleV) / 2 + 7;
        double module = (moduleU + moduleV) / 2;
        int baseDim = (int)Math.Round((est - 17) / 4) * 4 + 17;
        foreach (int dim in new[] { baseDim, baseDim + 4, baseDim - 4 })
        {
            if (dim < 21 || dim > 177) continue;
            int version = (dim - 17) / 4;
            // 4e point : centre du motif d'alignement bas-droit (version 2 et plus), sinon coin estimé
            double brX = tr.X - tl.X + bl.X, brY = tr.Y - tl.Y + bl.Y;
            (double x, double y)? align = null;
            if (version >= 2)
            {
                double k = 1 - 3.0 / (dim - 7);
                double ex = tl.X + k * (brX - tl.X), ey = tl.Y + k * (brY - tl.Y);
                align = FindAlignment(black, w, h, ex, ey, tl, tr, bl, dim);
            }
            var transforms = new List<Perspective>();
            if (align is { } a)
                transforms.Add(Perspective.QuadToQuad(3.5, 3.5, dim - 3.5, 3.5, dim - 6.5, dim - 6.5, 3.5, dim - 3.5,
                                                      tl.X, tl.Y, tr.X, tr.Y, a.x, a.y, bl.X, bl.Y));
            transforms.Add(Perspective.QuadToQuad(3.5, 3.5, dim - 3.5, 3.5, dim - 3.5, dim - 3.5, 3.5, dim - 3.5,
                                                  tl.X, tl.Y, tr.X, tr.Y, brX, brY, bl.X, bl.Y));
            foreach (var t in transforms)
            {
                var m = Sample(black, w, h, t, dim);
                if (m == null) continue;
                var text = DecodeMatrix(m);
                if (!string.IsNullOrEmpty(text)) return text;
            }
        }
        return null;
    }

    /// <summary>
    /// Largeur du motif de repérage le long de la droite qui le relie à un autre repère : 7 modules
    /// (centre noir, anneau blanc, anneau noir, de part et d'autre du centre). NaN si la mesure échoue.
    /// </summary>
    private static double AxisModule(bool[] black, int w, int h, Finder from, Finder toward)
    {
        double len = D(from, toward);
        if (len < 1) return double.NaN;
        double dx = (toward.X - from.X) / len, dy = (toward.Y - from.Y) / len;
        double limit = from.Module * 12;
        double Run(double sx, double sy)
        {
            int state = 0;
            for (double t = 0; t < limit; t += 0.5)
            {
                int px = (int)Math.Round(from.X + sx * t), py = (int)Math.Round(from.Y + sy * t);
                if (px < 0 || py < 0 || px >= w || py >= h) return double.NaN;
                bool b = black[py * w + px];
                if (state == 0 && !b) state = 1;
                else if (state == 1 && b) state = 2;
                else if (state == 2 && !b) return t;
            }
            return double.NaN;
        }
        double total = Run(dx, dy) + Run(-dx, -dy);
        return double.IsNaN(total) ? double.NaN : total / 7;
    }

    /// <summary>
    /// Recherche du motif d'alignement (5 × 5 modules : centre noir, anneau blanc, anneau noir) autour de la position
    /// attendue, en suivant les axes du QR (tolère une rotation quelconque).
    /// </summary>
    private static (double x, double y)? FindAlignment(bool[] black, int w, int h, double ex, double ey,
                                                       Finder tl, Finder tr, Finder bl, int dim)
    {
        double ux = (tr.X - tl.X) / (dim - 7), uy = (tr.Y - tl.Y) / (dim - 7);
        double vx = (bl.X - tl.X) / (dim - 7), vy = (bl.Y - tl.Y) / (dim - 7);
        double module = Math.Sqrt(ux * ux + uy * uy);
        int radius = (int)Math.Ceiling(module * 6);
        int best = -1; double sx = 0, sy = 0; int n = 0;
        for (int dy = -radius; dy <= radius; dy++)
            for (int dx = -radius; dx <= radius; dx++)
            {
                double cx = ex + dx, cy = ey + dy;
                int score = 0;
                for (int j = -2; j <= 2; j++)
                    for (int i = -2; i <= 2; i++)
                    {
                        int ring = Math.Max(Math.Abs(i), Math.Abs(j));
                        bool want = ring != 1;      // noir au centre et sur l'anneau extérieur
                        int px = (int)Math.Round(cx + i * ux + j * vx), py = (int)Math.Round(cy + i * uy + j * vy);
                        bool got = px >= 0 && py >= 0 && px < w && py < h && black[py * w + px];
                        if (got == want) score++;
                    }
                if (score > best) { best = score; sx = cx; sy = cy; n = 1; }
                else if (score == best) { sx += cx; sy += cy; n++; }
            }
        return best >= 23 ? (sx / n, sy / n) : null;
    }

    private static bool[,]? Sample(bool[] black, int w, int h, Perspective t, int dim)
    {
        var m = new bool[dim, dim];
        int outside = 0;
        for (int r = 0; r < dim; r++)
            for (int c = 0; c < dim; c++)
            {
                var (x, y) = t.Map(c + 0.5, r + 0.5);
                int px = (int)Math.Floor(x), py = (int)Math.Floor(y);
                if (px < 0 || py < 0 || px >= w || py >= h) { if (++outside > dim) return null; continue; }
                m[r, c] = black[py * w + px];
            }
        return m;
    }

    /// <summary>Transformation projective (homographie) d'un quadrilatère vers un autre.</summary>
    private readonly struct Perspective
    {
        private readonly double a11, a12, a13, a21, a22, a23, a31, a32, a33;

        private Perspective(double a11, double a21, double a31, double a12, double a22, double a32, double a13, double a23, double a33)
        {
            this.a11 = a11; this.a12 = a12; this.a13 = a13; this.a21 = a21; this.a22 = a22;
            this.a23 = a23; this.a31 = a31; this.a32 = a32; this.a33 = a33;
        }

        public (double x, double y) Map(double x, double y)
        {
            double d = a13 * x + a23 * y + a33;
            return ((a11 * x + a21 * y + a31) / d, (a12 * x + a22 * y + a32) / d);
        }

        public static Perspective QuadToQuad(double x0, double y0, double x1, double y1, double x2, double y2, double x3, double y3,
                                             double u0, double v0, double u1, double v1, double u2, double v2, double u3, double v3)
            => SquareToQuad(u0, v0, u1, v1, u2, v2, u3, v3).Times(SquareToQuad(x0, y0, x1, y1, x2, y2, x3, y3).Adjoint());

        private static Perspective SquareToQuad(double x0, double y0, double x1, double y1, double x2, double y2, double x3, double y3)
        {
            double dx3 = x0 - x1 + x2 - x3, dy3 = y0 - y1 + y2 - y3;
            if (Math.Abs(dx3) < 1e-12 && Math.Abs(dy3) < 1e-12)
                return new Perspective(x1 - x0, x2 - x1, x0, y1 - y0, y2 - y1, y0, 0, 0, 1);
            double dx1 = x1 - x2, dx2 = x3 - x2, dy1 = y1 - y2, dy2 = y3 - y2;
            double den = dx1 * dy2 - dx2 * dy1;
            double a13 = (dx3 * dy2 - dx2 * dy3) / den, a23 = (dx1 * dy3 - dx3 * dy1) / den;
            return new Perspective(x1 - x0 + a13 * x1, x3 - x0 + a23 * x3, x0,
                                   y1 - y0 + a13 * y1, y3 - y0 + a23 * y3, y0, a13, a23, 1);
        }

        private Perspective Adjoint() => new(
            a22 * a33 - a23 * a32, a23 * a31 - a21 * a33, a21 * a32 - a22 * a31,
            a13 * a32 - a12 * a33, a11 * a33 - a13 * a31, a12 * a31 - a11 * a32,
            a12 * a23 - a13 * a22, a13 * a21 - a11 * a23, a11 * a22 - a12 * a21);

        private Perspective Times(Perspective o) => new(
            a11 * o.a11 + a21 * o.a12 + a31 * o.a13, a11 * o.a21 + a21 * o.a22 + a31 * o.a23, a11 * o.a31 + a21 * o.a32 + a31 * o.a33,
            a12 * o.a11 + a22 * o.a12 + a32 * o.a13, a12 * o.a21 + a22 * o.a22 + a32 * o.a23, a12 * o.a31 + a22 * o.a32 + a32 * o.a33,
            a13 * o.a11 + a23 * o.a12 + a33 * o.a13, a13 * o.a21 + a23 * o.a22 + a33 * o.a23, a13 * o.a31 + a23 * o.a32 + a33 * o.a33);
    }
}
