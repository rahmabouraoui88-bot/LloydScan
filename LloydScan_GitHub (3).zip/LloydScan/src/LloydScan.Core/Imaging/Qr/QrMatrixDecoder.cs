using System.Text;

namespace LloydScan.Core.Imaging.Qr;

/// <summary>
/// Décodage d'une matrice QR déjà échantillonnée (true = module noir) : informations de format et de version,
/// lecture des mots de code, correction d'erreurs Reed-Solomon, puis décodage des segments de données.
/// Implémentation propre à LloydScan, d'après la norme ISO/IEC 18004.
/// </summary>
internal static class QrMatrixDecoder
{
    private const int FormatMask = 0x5412;

    // 32 informations de format valides (niveau 2 bits + masque 3 bits) → code BCH(15,5)
    private static readonly int[] FormatCodes = Enumerable.Range(0, 32).Select(d => (Bch(d, 10, 0x537) | (d << 10)) ^ FormatMask).ToArray();
    // Informations de version 7 à 40 → code BCH(18,6)
    private static readonly int[] VersionCodes = Enumerable.Range(0, 41).Select(v => v < 7 ? 0 : (Bch(v, 12, 0x1F25) | (v << 12))).ToArray();

    private static int Bch(int data, int degree, int poly)
    {
        int v = data << degree;
        int polyDeg = 31 - System.Numerics.BitOperations.LeadingZeroCount((uint)poly);
        for (int i = 31 - System.Numerics.BitOperations.LeadingZeroCount((uint)Math.Max(v, 1)); i >= polyDeg; i--)
            if ((v & (1 << i)) != 0) v ^= poly << (i - polyDeg);
        return v;
    }

    /// <summary>Renvoie le texte, ou null si la matrice n'est pas un QR lisible.</summary>
    public static string? Decode(bool[,] m)
    {
        int dim = m.GetLength(0);
        if (dim < 21 || dim > 177 || (dim - 17) % 4 != 0) return null;
        int version = (dim - 17) / 4;

        // Information de format : deux copies, on retient le code valide le plus proche
        int f1 = 0, f2 = 0;
        // Bit(m, x, y) : x = colonne, y = ligne
        for (int x = 0; x <= 5; x++) f1 = (f1 << 1) | Bit(m, x, 8);
        f1 = (f1 << 1) | Bit(m, 7, 8);
        f1 = (f1 << 1) | Bit(m, 8, 8);
        f1 = (f1 << 1) | Bit(m, 8, 7);
        for (int y = 5; y >= 0; y--) f1 = (f1 << 1) | Bit(m, 8, y);
        for (int y = dim - 1; y >= dim - 7; y--) f2 = (f2 << 1) | Bit(m, 8, y);
        for (int x = dim - 8; x < dim; x++) f2 = (f2 << 1) | Bit(m, x, 8);
        int format = Nearest(FormatCodes, f1, f2, 3);
        if (format < 0) return null;
        int ecBits = format >> 3, mask = format & 7;
        int level = ecBits switch { 1 => 0, 0 => 1, 3 => 2, _ => 3 }; // L, M, Q, H

        // Information de version (7 et plus) : contrôle de cohérence avec la taille mesurée
        if (version >= 7)
        {
            int v1 = 0, v2 = 0;
            for (int i = 5; i >= 0; i--)
                for (int j = dim - 9; j >= dim - 11; j--) v1 = (v1 << 1) | Bit(m, j, i);
            for (int j = 5; j >= 0; j--)
                for (int i = dim - 9; i >= dim - 11; i--) v2 = (v2 << 1) | Bit(m, j, i);
            int read = Nearest(VersionCodes, v1, v2, 3);
            if (read >= 7 && read != version) return null;
        }

        var function = FunctionPatterns(version, dim);
        var codewords = ReadCodewords(m, function, mask, dim);
        var data = CorrectAndDeinterleave(codewords, version, level);
        return data == null ? null : ParseSegments(data, version);
    }

    private static int Bit(bool[,] m, int x, int y) => m[y, x] ? 1 : 0;

    private static int Nearest(int[] codes, int a, int b, int maxDistance)
    {
        int best = -1, bestDist = int.MaxValue;
        for (int i = 0; i < codes.Length; i++)
        {
            if (codes[i] == 0) continue;
            int d = Math.Min(System.Numerics.BitOperations.PopCount((uint)(codes[i] ^ a)),
                             System.Numerics.BitOperations.PopCount((uint)(codes[i] ^ b)));
            if (d < bestDist) { bestDist = d; best = i; }
        }
        return bestDist <= maxDistance ? best : -1;
    }

    /// <summary>Modules réservés (motifs de repérage, synchronisation, alignement, format, version).</summary>
    private static bool[,] FunctionPatterns(int version, int dim)
    {
        var f = new bool[dim, dim];
        void Rect(int x0, int y0, int w, int h)
        {
            for (int y = y0; y < y0 + h; y++)
                for (int x = x0; x < x0 + w; x++)
                    if (x >= 0 && y >= 0 && x < dim && y < dim) f[y, x] = true;
        }
        Rect(0, 0, 9, 9);              // repère haut-gauche + format
        Rect(dim - 8, 0, 8, 9);        // repère haut-droit + format
        Rect(0, dim - 8, 9, 8);        // repère bas-gauche + format
        Rect(6, 0, 1, dim);            // synchronisation
        Rect(0, 6, dim, 1);
        var centers = QrTables.Alignment[version - 1];
        foreach (int cy in centers)
            foreach (int cx in centers)
            {
                if ((cx <= 8 && cy <= 8) || (cx >= dim - 9 && cy <= 8) || (cx <= 8 && cy >= dim - 9)) continue;
                Rect(cx - 2, cy - 2, 5, 5);
            }
        if (version >= 7)
        {
            Rect(dim - 11, 0, 3, 6);
            Rect(0, dim - 11, 6, 3);
        }
        return f;
    }

    private static bool MaskBit(int mask, int x, int y) => mask switch
    {
        0 => (x + y) % 2 == 0,
        1 => y % 2 == 0,
        2 => x % 3 == 0,
        3 => (x + y) % 3 == 0,
        4 => (y / 2 + x / 3) % 2 == 0,
        5 => x * y % 2 + x * y % 3 == 0,
        6 => (x * y % 2 + x * y % 3) % 2 == 0,
        _ => ((x + y) % 2 + x * y % 3) % 2 == 0
    };

    /// <summary>Lecture en zigzag par paires de colonnes, de droite à gauche, en sautant la colonne 6.</summary>
    private static byte[] ReadCodewords(bool[,] m, bool[,] function, int mask, int dim)
    {
        var bytes = new List<byte>();
        int current = 0, bits = 0;
        bool upward = true;
        for (int right = dim - 1; right > 0; right -= 2)
        {
            if (right == 6) right = 5;
            for (int k = 0; k < dim; k++)
            {
                int y = upward ? dim - 1 - k : k;
                for (int c = 0; c < 2; c++)
                {
                    int x = right - c;
                    if (function[y, x]) continue;
                    bool bit = m[y, x] ^ MaskBit(mask, x, y);
                    current = (current << 1) | (bit ? 1 : 0);
                    if (++bits == 8) { bytes.Add((byte)current); current = 0; bits = 0; }
                }
            }
            upward = !upward;
        }
        return bytes.ToArray();
    }

    /// <summary>Désentrelace les blocs, corrige chacun (Reed-Solomon) et renvoie les octets de données.</summary>
    private static byte[]? CorrectAndDeinterleave(byte[] raw, int version, int level)
    {
        var spec = QrTables.Blocks[(version - 1) * 4 + level];
        var blocks = new List<(int total, int data)>();
        for (int i = 0; i < spec.Length; i += 3)
            for (int n = 0; n < spec[i]; n++) blocks.Add((spec[i + 1], spec[i + 2]));
        int totalCodewords = blocks.Sum(b => b.total);
        if (raw.Length < totalCodewords) return null;

        int ecPerBlock = blocks[0].total - blocks[0].data;
        int maxData = blocks.Max(b => b.data);
        var buffers = blocks.Select(b => new byte[b.total]).ToArray();
        int p = 0;
        for (int i = 0; i < maxData; i++)
            for (int b = 0; b < blocks.Count; b++)
                if (i < blocks[b].data) buffers[b][i] = raw[p++];
        for (int i = 0; i < ecPerBlock; i++)
            for (int b = 0; b < blocks.Count; b++)
                buffers[b][blocks[b].data + i] = raw[p++];

        var result = new List<byte>();
        for (int b = 0; b < blocks.Count; b++)
        {
            if (!ReedSolomon.Correct(buffers[b], ecPerBlock)) return null;
            result.AddRange(buffers[b].Take(blocks[b].data));
        }
        return result.ToArray();
    }

    private const string Alphanumeric = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ $%*+-./:";

    private static string? ParseSegments(byte[] data, int version)
    {
        var reader = new BitReader(data);
        var text = new StringBuilder();
        var pending = new List<byte>();     // octets en mode « byte », décodés ensemble (UTF-8 si valide)
        Encoding? eci = null;
        int sizeClass = version <= 9 ? 0 : version <= 26 ? 1 : 2;

        void FlushBytes()
        {
            if (pending.Count == 0) return;
            text.Append(DecodeBytes(pending.ToArray(), eci));
            pending.Clear();
        }

        while (reader.Available >= 4)
        {
            int mode = reader.Read(4);
            switch (mode)
            {
                case 0: FlushBytes(); return text.ToString();      // fin
                case 1:                                              // numérique
                {
                    FlushBytes();
                    int count = reader.Read(new[] { 10, 12, 14 }[sizeClass]);
                    while (count >= 3) { int v = reader.Read(10); if (v > 999) return null; text.Append(v.ToString("000")); count -= 3; }
                    if (count == 2) { int v = reader.Read(7); if (v > 99) return null; text.Append(v.ToString("00")); }
                    else if (count == 1) { int v = reader.Read(4); if (v > 9) return null; text.Append(v); }
                    break;
                }
                case 2:                                              // alphanumérique
                {
                    FlushBytes();
                    int count = reader.Read(new[] { 9, 11, 13 }[sizeClass]);
                    while (count >= 2)
                    {
                        int v = reader.Read(11);
                        if (v >= 45 * 45) return null;
                        text.Append(Alphanumeric[v / 45]).Append(Alphanumeric[v % 45]);
                        count -= 2;
                    }
                    if (count == 1) { int v = reader.Read(6); if (v >= 45) return null; text.Append(Alphanumeric[v]); }
                    break;
                }
                case 4:                                              // octets
                {
                    int count = reader.Read(new[] { 8, 16, 16 }[sizeClass]);
                    if (reader.Available < count * 8) return null;
                    for (int i = 0; i < count; i++) pending.Add((byte)reader.Read(8));
                    break;
                }
                case 7:                                              // ECI : jeu de caractères
                {
                    FlushBytes();
                    int first = reader.Read(8), value;
                    if ((first & 0x80) == 0) value = first;
                    else if ((first & 0xC0) == 0x80) value = ((first & 0x3F) << 8) | reader.Read(8);
                    else value = ((first & 0x1F) << 16) | reader.Read(16);
                    eci = value switch
                    {
                        26 => new UTF8Encoding(false, true),
                        3 or 1 => Encoding.Latin1,
                        _ => null
                    };
                    break;
                }
                case 3: reader.Read(16); break;                      // assemblage structuré : ignoré
                case 5: break;                                       // FNC1 (1re position)
                case 9: reader.Read(8); break;                       // FNC1 (2e position)
                case 8:                                              // kanji : non utilisé par LLOYD/ELISE
                    return null;
                default:
                    return null;
            }
        }
        FlushBytes();
        return text.ToString();
    }

    private static string DecodeBytes(byte[] bytes, Encoding? eci)
    {
        if (eci != null)
        {
            try { return eci.GetString(bytes); } catch (DecoderFallbackException) { }
        }
        try { return new UTF8Encoding(false, true).GetString(bytes); }  // UTF-8 valide (cas courant)
        catch (DecoderFallbackException) { return Encoding.Latin1.GetString(bytes); }
    }

    private sealed class BitReader
    {
        private readonly byte[] _data;
        private int _pos;
        public BitReader(byte[] data) => _data = data;
        public int Available => _data.Length * 8 - _pos;
        public int Read(int n)
        {
            int v = 0;
            for (int i = 0; i < n; i++)
            {
                int bit = _pos < _data.Length * 8 ? (_data[_pos >> 3] >> (7 - (_pos & 7))) & 1 : 0;
                v = (v << 1) | bit;
                _pos++;
            }
            return v;
        }
    }
}

/// <summary>Correction d'erreurs Reed-Solomon sur GF(256), polynôme 0x11D (norme QR).</summary>
internal static class ReedSolomon
{
    private static readonly int[] Exp = new int[512];
    private static readonly int[] Log = new int[256];

    static ReedSolomon()
    {
        int x = 1;
        for (int i = 0; i < 255; i++)
        {
            Exp[i] = x; Log[x] = i;
            x <<= 1;
            if (x >= 256) x ^= 0x11D;
        }
        for (int i = 255; i < 512; i++) Exp[i] = Exp[i - 255];
    }

    private static int Mul(int a, int b) => a == 0 || b == 0 ? 0 : Exp[Log[a] + Log[b]];
    private static int Inv(int a) => Exp[255 - Log[a]];

    /// <summary>Corrige le bloc sur place (données puis <paramref name="ecCount"/> octets de contrôle). False si irrécupérable.</summary>
    public static bool Correct(byte[] block, int ecCount)
    {
        int n = block.Length;
        // Syndromes S_j = R(alpha^j), j = 0..ecCount-1 (le 1er octet est le coefficient de plus haut degré)
        var s = new int[ecCount];
        bool clean = true;
        for (int j = 0; j < ecCount; j++)
        {
            int v = 0;
            for (int i = 0; i < n; i++) v = Mul(v, Exp[j]) ^ block[i];
            s[j] = v;
            if (v != 0) clean = false;
        }
        if (clean) return true;

        // Berlekamp-Massey : polynôme localisateur d'erreurs
        var c = new int[ecCount + 1]; var b = new int[ecCount + 1];
        c[0] = 1; b[0] = 1;
        int l = 0, m = 1, bb = 1;
        for (int k = 0; k < ecCount; k++)
        {
            int d = s[k];
            for (int i = 1; i <= l; i++) d ^= Mul(c[i], s[k - i]);
            if (d == 0) { m++; continue; }
            var t = (int[])c.Clone();
            int coef = Mul(d, Inv(bb));
            for (int i = 0; i + m <= ecCount; i++) c[i + m] ^= Mul(coef, b[i]);
            if (2 * l <= k)
            {
                l = k + 1 - l; b = t; bb = d; m = 1;
            }
            else m++;
        }
        if (2 * l > ecCount) return false;

        // Recherche de Chien : positions des erreurs
        var positions = new List<int>();
        for (int i = 0; i < n; i++)
        {
            // position i (depuis la fin) ↔ X = alpha^i ; racine de C en X^-1
            int xInv = Exp[(255 - i) % 255], v = 0, pw = 1;
            for (int k = 0; k <= l; k++) { v ^= Mul(c[k], pw); pw = Mul(pw, xInv); }
            if (v == 0) positions.Add(i);
        }
        if (positions.Count != l) return false;

        // Forney : valeur des erreurs. Omega = S(x) * C(x) mod x^ecCount
        var omega = new int[ecCount];
        for (int i = 0; i < ecCount; i++)
        {
            int v = 0;
            for (int k = 0; k <= Math.Min(i, l); k++) v ^= Mul(c[k], s[i - k]);
            omega[i] = v;
        }
        foreach (int i in positions)
        {
            int x = Exp[i], xInv = Inv(x);
            int num = 0, pw = 1;
            for (int k = 0; k < ecCount; k++) { num ^= Mul(omega[k], pw); pw = Mul(pw, xInv); }
            int den = 0; pw = 1;   // dérivée formelle de C : termes impairs
            for (int k = 1; k <= l; k += 2)
            {
                den ^= Mul(c[k], Exp[(Log[xInv] * (k - 1)) % 255]);
            }
            if (den == 0) return false;
            int magnitude = Mul(x, Mul(num, Inv(den)));   // b = 0 (racines alpha^0..alpha^(n-k-1))
            block[n - 1 - i] ^= (byte)magnitude;
        }
        // Vérification
        for (int j = 0; j < ecCount; j++)
        {
            int v = 0;
            for (int i = 0; i < n; i++) v = Mul(v, Exp[j]) ^ block[i];
            if (v != 0) return false;
        }
        return true;
    }
}
