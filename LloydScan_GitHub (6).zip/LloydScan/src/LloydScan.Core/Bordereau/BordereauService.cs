using LloydScan.Core.Configuration;
using LloydScan.Core.Processing;

namespace LloydScan.Core.Bordereau;

/// <summary>
/// Profil « Bordereau » : texte OCR des pages → type, compagnie, période, total et lignes → contrôles → classeur Excel.
/// L'OCR est fait pendant la numérisation ; ici on ne lit que du texte (instantané).
/// </summary>
public sealed class BordereauService
{
    private readonly BordereauSettings _settings;
    private readonly BordereauExtractor _extractor;

    public BordereauService(BordereauSettings settings)
    {
        _settings = settings;
        var path = settings.ResolveTemplatesPath();
        TemplatesFound = File.Exists(path);
        Config = TemplatesFound ? BordereauConfig.Load(path) : new BordereauConfig();
        _extractor = new BordereauExtractor(Config);
    }

    public BordereauConfig Config { get; }
    /// <summary>Faux si bordereau-templates.json est absent : motifs génériques seulement, aucune compagnie connue.</summary>
    public bool TemplatesFound { get; }

    /// <summary>
    /// Un bordereau par page, ou un par document (fiche séparatrice entre deux bordereaux de plusieurs pages).
    /// « Auto » : par document s'il y a des fiches séparatrices dans le lot, sinon par page.
    /// </summary>
    public List<BordereauRecord> Extract(IEnumerable<ScanDocument> documents, bool batchHasSeparators)
    {
        var mode = _settings.Mode;
        if (mode == BordereauMode.Auto) mode = batchHasSeparators ? BordereauMode.Document : BordereauMode.Page;
        var records = new List<BordereauRecord>();
        foreach (var doc in documents)
        {
            var pages = doc.Pages.Where(p => !p.IsSeparator && p.Optimized != null).ToList();
            if (pages.Count == 0)
            {
                if (doc.IsNativePdf) records.Add(_extractor.Extract("", doc, 1, doc.PageCount, Label(doc, 1, doc.PageCount)));
                continue;
            }
            if (mode == BordereauMode.Document)
            {
                var text = string.Join("\n", pages.Select(p => OcrText.ToText(p.Optimized!.Text)));
                int first = doc.Pages.IndexOf(pages[0]) + 1;
                records.Add(_extractor.Extract(text, doc, first, pages.Count, Label(doc, first, pages.Count)));
            }
            else
                foreach (var p in pages)
                {
                    int index = doc.Pages.IndexOf(p) + 1;
                    records.Add(_extractor.Extract(OcrText.ToText(p.Optimized!.Text), doc, index, 1, Label(doc, index, 1)));
                }
        }
        Validate(records);
        return records;
    }

    private static string Label(ScanDocument doc, int page, int count) =>
        count > 1 ? $"{doc.FileName} (p. {page}-{page + count - 1})" : $"{doc.FileName} (p. {page})";

    public void Validate(IReadOnlyList<BordereauRecord> records) => BordereauValidator.Validate(records, _settings.MaxAgeYears);

    // ---------------- Corrections manuelles (mêmes règles de lecture que l'OCR) ----------------

    public static void SetTotal(BordereauRecord r, string? text)
    {
        r.TotalRaw = text;
        r.Total = ValueParser.TryParseAmount(text, out var v) ? v : null;
        r.Corrected = true;
    }

    public static void SetPeriod(BordereauRecord r, string? text)
    {
        r.PeriodRaw = text;
        r.Period = ValueParser.TryParsePeriod(text, out var p) ? p : null;
        r.Corrected = true;
    }

    /// <summary>Compagnie saisie : remplacée par son nom officiel si elle est connue (« gat » → « GAT Assurances »).</summary>
    public void SetCompany(BordereauRecord r, string? text)
    {
        r.Company = string.IsNullOrWhiteSpace(text) ? null : Config.NormalizeCompany(text) ?? text.Trim();
        r.Corrected = true;
    }

    // ---------------- Export Excel ----------------

    /// <summary>
    /// Classeur « Sinistres » (une ligne par sinistre : référence et montant en face) + « Bordereaux » (contrôles),
    /// et, à côté, le dossier « …_documents » avec le PDF de chaque bordereau (lien sur chaque ligne).
    /// Renvoie le nombre de PDF copiés.
    /// </summary>
    public int ExportExcel(IReadOnlyList<BordereauRecord> records, string xlsxPath)
    {
        Validate(records);
        string dir = Path.GetDirectoryName(Path.GetFullPath(xlsxPath))!;
        Directory.CreateDirectory(dir);
        string docsName = Path.GetFileNameWithoutExtension(xlsxPath) + "_documents";
        string docsDir = Path.Combine(dir, docsName);

        var files = new Dictionary<ScanDocument, string>();
        foreach (var doc in records.Select(r => r.Document).OfType<ScanDocument>().Distinct())
        {
            if (doc.Pdf == null) continue;
            Directory.CreateDirectory(docsDir);
            var name = string.IsNullOrWhiteSpace(doc.FileName) ? $"document_{doc.Sequence:000}.pdf" : doc.FileName;
            File.WriteAllBytes(Path.Combine(docsDir, name), doc.Pdf);
            files[doc] = name;
        }
        string? LinkOf(BordereauRecord r) =>
            r.Document != null && files.TryGetValue(r.Document, out var f) ? docsName + "/" + Uri.EscapeDataString(f) : null;

        var book = new XlsxWorkbook { Title = "Bordereaux de règlement" };

        // ----- Feuille 1 : une ligne par sinistre, le montant en face de chaque référence -----
        var detail = book.Add("Sinistres");
        string[] h2 = { "Référence sinistre", "Montant (TND)", "Compagnie", "Période", "Type de bordereau", "Contrat / immatriculation", "Libellé (assuré…)", "N° bordereau", "Document source" };
        detail.ColumnWidths = new double[] { 20, 16, 22, 10, 30, 22, 26, 12, 46 };
        for (int c = 0; c < h2.Length; c++) detail.Text(1, c + 1, h2[c], XlsxSheet.Style.Header);
        int drow = 2, number = 1;
        decimal dtotal = 0;
        foreach (var r in records)
        {
            // Bordereau dont les lignes ne collent pas au total : ses lignes sont surlignées pour vérification
            bool warn = r.Issues.Contains(IssueKind.SumMismatch) || r.Issues.Contains(IssueKind.CountMismatch);
            var text = warn ? XlsxSheet.Style.TextWarn : XlsxSheet.Style.Text;
            foreach (var l in r.Lines)
            {
                detail.Text(drow, 1, l.Reference, text);
                if (l.Amount is decimal a) { detail.Number(drow, 2, (double)a, warn ? XlsxSheet.Style.AmountWarn : XlsxSheet.Style.Amount); dtotal += a; }
                else detail.Text(drow, 2, l.AmountRaw, XlsxSheet.Style.TextWarn);
                detail.Text(drow, 3, r.Company, text);
                if (r.Period is DateTime p) detail.Date(drow, 4, p, warn ? XlsxSheet.Style.PeriodWarn : XlsxSheet.Style.Period);
                else detail.Text(drow, 4, r.PeriodRaw, text);
                detail.Text(drow, 5, r.Type, text);
                detail.Text(drow, 6, l.Identifier, text);
                detail.Text(drow, 7, l.Label, text);
                detail.Number(drow, 8, number, text);
                if (LinkOf(r) is string link) detail.Link(drow, 9, r.SourceLabel, link, warn ? XlsxSheet.Style.LinkWarn : XlsxSheet.Style.Link);
                else detail.Text(drow, 9, r.SourceLabel, text);
                drow++;
            }
            number++;
        }
        TotalRow(detail, drow, h2.Length, 1, 2, dtotal);

        // ----- Feuille 2 : une ligne par bordereau, avec les contrôles -----
        var main = book.Add("Bordereaux");
        string[] h1 = { "N° bordereau", "Type de bordereau", "Compagnie", "Période", "Référence", "Nb lignes", "Somme des lignes", "Total du bordereau", "Contrôle", "Saisie", "Document source" };
        main.ColumnWidths = new double[] { 12, 30, 22, 10, 16, 9, 17, 18, 44, 10, 46 };
        for (int c = 0; c < h1.Length; c++) main.Text(1, c + 1, h1[c], XlsxSheet.Style.Header);
        int row = 2;
        decimal total = 0;
        foreach (var r in records)
        {
            bool warn = r.HasIssues;
            var text = warn ? XlsxSheet.Style.TextWarn : XlsxSheet.Style.Text;
            var amount = warn ? XlsxSheet.Style.AmountWarn : XlsxSheet.Style.Amount;
            main.Number(row, 1, row - 1, text);
            main.Text(row, 2, r.Type, text);
            main.Text(row, 3, r.Company, text);
            if (r.Period is DateTime p) main.Date(row, 4, p, warn ? XlsxSheet.Style.PeriodWarn : XlsxSheet.Style.Period);
            else main.Text(row, 4, r.PeriodRaw, text);
            main.Text(row, 5, r.Reference, text);
            main.Number(row, 6, r.Lines.Count, text);
            if (r.Lines.Count > 0) main.Number(row, 7, (double)r.LinesSum, amount); else main.Empty(row, 7, text);
            if (r.Total is decimal t) { main.Number(row, 8, (double)t, amount); total += t; }
            else main.Text(row, 8, r.TotalRaw, text);
            main.Text(row, 9, r.IssuesText, text);
            main.Text(row, 10, r.Corrected ? "Corrigée" : "OCR", text);
            if (LinkOf(r) is string link) main.Link(row, 11, r.SourceLabel, link, warn ? XlsxSheet.Style.LinkWarn : XlsxSheet.Style.Link);
            else main.Text(row, 11, r.SourceLabel, text);
            row++;
        }
        TotalRow(main, row, h1.Length, 3, 8, total);

        book.Save(xlsxPath);
        return files.Count;
    }

    /// <summary>Ligne TOTAL : SOUS.TOTAL ignore les lignes masquées par un filtre.</summary>
    private static void TotalRow(XlsxSheet sheet, int row, int columns, int labelCol, int amountCol, decimal cached)
    {
        int last = row - 1;
        for (int c = 1; c <= columns; c++) sheet.Empty(row, c, XlsxSheet.Style.TotalBlank);
        sheet.Text(row, labelCol, "TOTAL", XlsxSheet.Style.TotalLabel);
        string col = XlsxSheet.CellRef(1, amountCol)[..^1];
        if (last >= 2)
        {
            sheet.Formula(row, amountCol, $"SUBTOTAL(109,{col}2:{col}{last})", (double)cached, XlsxSheet.Style.TotalAmount);
            sheet.AutoFilter = $"A1:{XlsxSheet.CellRef(last, columns)}";
        }
        else sheet.Number(row, amountCol, 0, XlsxSheet.Style.TotalAmount);
    }
}
