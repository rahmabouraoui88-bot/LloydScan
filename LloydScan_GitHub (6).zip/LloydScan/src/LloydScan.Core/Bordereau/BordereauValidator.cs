using System.Globalization;

namespace LloydScan.Core.Bordereau;

/// <summary>Contrôles de cohérence, relancés après chaque correction.</summary>
public static class BordereauValidator
{
    private static readonly CultureInfo Fr = CultureInfo.GetCultureInfo("fr-FR");

    public static void Validate(IReadOnlyList<BordereauRecord> records, int maxAgeYears = 3, DateTime? today = null)
    {
        var now = today ?? DateTime.Today;
        foreach (var r in records)
        {
            r.Issues.RemoveAll(i => i != IssueKind.NoText);
            if (r.Issues.Contains(IssueKind.NoText) && (r.Total.HasValue || !string.IsNullOrWhiteSpace(r.Company)))
                r.Issues.Remove(IssueKind.NoText); // saisi à la main

            if (string.IsNullOrWhiteSpace(r.Company)) r.Issues.Add(IssueKind.MissingCompany);

            if (r.Period is null)
                r.Issues.Add(string.IsNullOrWhiteSpace(r.PeriodRaw) ? IssueKind.MissingPeriod : IssueKind.InvalidPeriod);
            else if (r.Period > now || r.Period < new DateTime(now.Year, now.Month, 1).AddYears(-Math.Max(1, maxAgeYears)))
                r.Issues.Add(IssueKind.InvalidPeriod);

            if (r.Total is null)
                r.Issues.Add(string.IsNullOrWhiteSpace(r.TotalRaw) ? IssueKind.MissingTotal : IssueKind.InvalidTotal);
            else if (r.Total <= 0)
                r.Issues.Add(IssueKind.InvalidTotal);

            // Contrôles croisés : la somme des lignes doit égaler le total, le nombre de lignes celui annoncé
            if (r.Lines.Count == 0) r.Issues.Add(IssueKind.NoLines);
            else if (r.Total is decimal t && Math.Abs(r.LinesSum - t) > 0.0005m) r.Issues.Add(IssueKind.SumMismatch);
            if (r.DeclaredCount is int n && r.Lines.Count > 0 && n != r.Lines.Count) r.Issues.Add(IssueKind.CountMismatch);
        }

        // Doublon : même compagnie, même type, même période et même total
        foreach (var g in records
                     .Where(r => r.Total.HasValue && !string.IsNullOrWhiteSpace(r.Company))
                     .GroupBy(r => (TextTools.FoldWords(r.Company!), TextTools.FoldWords(r.Type ?? ""), r.Period, r.Total))
                     .Where(g => g.Count() > 1))
            foreach (var r in g) r.Issues.Add(IssueKind.Duplicate);
    }

    public static string Describe(IssueKind k, BordereauRecord? r = null) => k switch
    {
        IssueKind.NoText => "Aucun texte lu (OCR)",
        IssueKind.UnknownModel => "Modèle de bordereau non reconnu",
        IssueKind.MissingCompany => "Compagnie non trouvée",
        IssueKind.MissingPeriod => "Période (mois) non trouvée",
        IssueKind.InvalidPeriod => "Période illisible ou hors délai",
        IssueKind.MissingTotal => "Total non trouvé",
        IssueKind.InvalidTotal => "Total illisible",
        IssueKind.SumMismatch => r?.Total is decimal t
            ? $"Somme des lignes {r.LinesSum.ToString("#,##0.000", Fr)} ≠ total {t.ToString("#,##0.000", Fr)}"
            : "Somme des lignes différente du total",
        IssueKind.CountMismatch => r != null ? $"{r.Lines.Count} ligne(s) lue(s), {r.DeclaredCount} annoncée(s)" : "Nombre de lignes différent",
        IssueKind.NoLines => "Aucune ligne de détail lue",
        IssueKind.Duplicate => "Bordereau en double (même compagnie, période et total)",
        _ => k.ToString()
    };
}
