using System.Globalization;
using System.Text.RegularExpressions;

namespace LloydScan.Core.Bordereau;

/// <summary>Lecture des montants (dinars, 3 décimales) et des dates écrits sur les bordereaux.</summary>
public static class ValueParser
{
    private static readonly CultureInfo Fr = CultureInfo.GetCultureInfo("fr-FR");

    private static readonly string[] DateFormats =
    {
        "dd/MM/yyyy", "d/M/yyyy", "dd-MM-yyyy", "d-M-yyyy", "dd.MM.yyyy", "d.M.yyyy",
        "dd/MM/yy", "d/M/yy", "dd-MM-yy", "dd.MM.yy", "yyyy-MM-dd", "yyyy/MM/dd", "d MMMM yyyy", "dd MMMM yyyy"
    };

    /// <summary>
    /// « 1 234,567 », « 1.234,567 », « 1,234.567 », « 1234.567 », « 12 500 DT ».
    /// Deux séparateurs différents : le dernier est la virgule décimale.
    /// Un seul séparateur : répété = milliers ; unique suivi de 3 chiffres ou moins = décimales (dinars à 3 décimales).
    /// </summary>
    public static bool TryParseAmount(string? raw, out decimal value)
    {
        value = 0;
        if (string.IsNullOrWhiteSpace(raw)) return false;

        var s = Regex.Replace(raw.Trim(), @"(TND|DT|D\.T\.?|dinars?)\s*$", "", RegexOptions.IgnoreCase).Trim();
        // Confusions OCR courantes dans un nombre
        s = s.Replace('O', '0').Replace('o', '0').Replace('l', '1').Replace('I', '1');
        s = Regex.Replace(s, @"[\s  ']", "");
        if (!Regex.IsMatch(s, @"^-?\d[\d.,]*$")) return false;

        int lastDot = s.LastIndexOf('.'), lastComma = s.LastIndexOf(',');
        char? dec = null;
        if (lastDot >= 0 && lastComma >= 0) dec = lastDot > lastComma ? '.' : ',';
        else if (lastComma >= 0) dec = s.Count(c => c == ',') == 1 ? ',' : null;
        else if (lastDot >= 0) dec = s.Count(c => c == '.') == 1 ? '.' : null;

        string normalized;
        if (dec == null) normalized = s.Replace(".", "").Replace(",", "");
        else
        {
            char other = dec == '.' ? ',' : '.';
            normalized = s.Replace(other.ToString(), "").Replace(dec.Value, '.');
        }
        return decimal.TryParse(normalized, NumberStyles.AllowDecimalPoint | NumberStyles.AllowLeadingSign,
            CultureInfo.InvariantCulture, out value);
    }

    private static readonly string[] Months =
        { "JANVIER", "FEVRIER", "MARS", "AVRIL", "MAI", "JUIN", "JUILLET", "AOUT", "SEPTEMBRE", "OCTOBRE", "NOVEMBRE", "DECEMBRE" };

    /// <summary>Période (mois) : « 12/2025 », « 12-2025 », « Décembre 2025 », « Mois Décembre 2025 », ou une date complète.</summary>
    public static bool TryParsePeriod(string? raw, out DateTime value)
    {
        value = default;
        if (string.IsNullOrWhiteSpace(raw)) return false;
        var s = TextTools.Fold(raw.Trim());
        var m = Regex.Match(s, @"(?<!\d)(\d{1,2})\s*[/\-.]\s*(\d{4})(?!\d)");
        if (m.Success && !Regex.IsMatch(s, @"\d{1,2}\s*[/\-.]\s*\d{1,2}\s*[/\-.]\s*\d{4}"))
        {
            int month = int.Parse(m.Groups[1].Value, CultureInfo.InvariantCulture), year = int.Parse(m.Groups[2].Value, CultureInfo.InvariantCulture);
            if (month is >= 1 and <= 12 && year is > 1990 and < 2200) { value = new DateTime(year, month, 1); return true; }
        }
        m = Regex.Match(s, @"\b(JANVIER|FEVRIER|MARS|AVRIL|MAI|JUIN|JUILLET|AOUT|SEPTEMBRE|OCTOBRE|NOVEMBRE|DECEMBRE)\s+(\d{4})\b");
        if (m.Success)
        {
            value = new DateTime(int.Parse(m.Groups[2].Value, CultureInfo.InvariantCulture), Array.IndexOf(Months, m.Groups[1].Value) + 1, 1);
            return true;
        }
        m = Regex.Match(raw, @"\d{1,2}[/\-.]\d{1,2}[/\-.]\d{2,4}");
        if (m.Success && TryParseDate(m.Value, out var d)) { value = new DateTime(d.Year, d.Month, 1); return true; }
        return false;
    }

    public static bool TryParseDate(string? raw, out DateTime value)
    {
        value = default;
        if (string.IsNullOrWhiteSpace(raw)) return false;
        var s = Regex.Replace(raw.Trim(), @"\s+", " ");
        if (!DateTime.TryParseExact(s, DateFormats, Fr, DateTimeStyles.None, out value)) return false;
        if (value.Year < 100) value = value.AddYears(2000);
        return true;
    }
}
