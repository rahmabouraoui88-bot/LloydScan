using System.Text.RegularExpressions;
using LloydScan.Core.Ocr;

namespace LloydScan.Core.Bordereau;

/// <summary>
/// Lit un bordereau à partir du texte OCR : type, compagnie concernée, période, référence, total,
/// nombre de lignes annoncé et lignes du tableau (référence, contrat/immatriculation, libellé, montant).
/// </summary>
public sealed class BordereauExtractor
{
    private readonly BordereauConfig _config;

    /// <summary>Motifs de repli, valables pour la plupart des bordereaux.</summary>
    private static readonly ModelDefinition Generic = new()
    {
        Name = "Générique",
        TypePatterns =
        {
            @"^\W*(?<v>(?:BORDEREAU|[EÉ]TAT|RELEV[EÉ]|D[EÉ]COMPTE)\b[^\n]{3,70})$"
        },
        CompanyPatterns =
        {
            @"COMPAGNIE\s+ADVERSE\s*[:\-]?\s*(?<v>[^\n]+)",
            @"COMPTE\s+DE\s+LA\s+COMPAGNIE\s*[:\-]?\s*(?<v>[^\n]+)",
            @"COMPAGNIE\s*[:\-]\s*(?<v>[^\n]+)"
        },
        PeriodPatterns =
        {
            @"MOIS\s*/\s*ANN[EÉ]E\s*[:\-]?\s*(?<v>\d{1,2}\s*[/\-.]\s*\d{4})",
            @"\bMOIS\s+(?:DE\s+|D['’]\s*)?(?<v>[A-Za-zÀ-ÿ]+\s+\d{4})",
            @"P[EÉ]RIODE\s*[:\-]?\s*(?<v>[^\n]{4,30})",
            @"\b(?<v>(?:JANVIER|F[EÉ]VRIER|MARS|AVRIL|MAI|JUIN|JUILLET|AO[UÛ]T|SEPTEMBRE|OCTOBRE|NOVEMBRE|D[EÉ]CEMBRE)\s+\d{4})\b",
            @"DATE\s*(?:DU\s+R[EÉÈ]GLEMENT|DU\s+BORDEREAU|D['’]?\s*[EÉ]MISSION)?\s*[:\-]?\s*(?<v>\d{1,2}[/\-.]\d{1,2}[/\-.]\d{2,4})"
        },
        ReferencePatterns =
        {
            @"BORDEREAU\s*(?:DE\s+R[EÉÈ]GLEMENT)?\s*(?:N[°ºO]|NUM[EÉ]RO|R[EÉ]F(?:[EÉ]RENCE)?\.?)\s*[:\-]?\s*(?<v>[A-Z0-9][A-Z0-9/\-_.]{2,})",
            @"R[EÉ]F(?:[EÉ]RENCE)?\.?\s*(?:DU\s+)?BORDEREAU\s*[:\-]?\s*(?<v>[A-Z0-9][A-Z0-9/\-_.]{2,})"
        },
        TotalPatterns =
        {
            @"TOTAL\s*DU\s*MOIS\s*[:\-]?\s*(?<v>\d[\d\s.,]*\d)",
            @"(?:TOTAL\s+G[EÉ]N[EÉ]RAL|NET\s+[AÀ]\s+PAYER|MONTANT\s+TOTAL|TOTAL\s+[AÀ]\s+R[EÉÈ]GLER)\s*(?:\(?\s*(?:TND|DT)\s*\)?)?\s*[:\-]?\s*(?<v>\d[\d\s.,]*\d)",
            @"\bTOTAL\b\s*(?:\(?\s*(?:TND|DT)\s*\)?)?\s*[:\-|]?\s*(?<v>\d[\d\s.,]*\d)"
        },
        CountPatterns =
        {
            @"NOMBRE\s+DE\s+(?:SINISTRES?|QUITTANCES?|DOSSIERS?|LIGNES?|R[EÉ]GLEMENTS?)\s*[:\-]?\s*(?<v>\d{1,4})\b"
        }
    };

    // Lignes de tableau : une référence longue (n° de sinistre…) et un montant à 3 décimales
    private static readonly Regex RefToken = new(@"(?<![\w])\d{8,}(?![\w])", RegexOptions.CultureInvariant);
    private static readonly Regex AmountToken = new(@"(?<![\d.,])\d{1,3}(?:[ .  ]\d{3})*,\d{3}(?![\d,])|(?<![\d.,])\d+[,.]\d{3}(?![\d.,])", RegexOptions.CultureInvariant);
    private static readonly Regex IdToken = new(@"^(?=.*\d)[A-Z0-9][A-Z0-9/\-]{3,}$", RegexOptions.CultureInvariant | RegexOptions.IgnoreCase);

    public BordereauExtractor(BordereauConfig config) => _config = config;

    public BordereauRecord Extract(string text, Processing.ScanDocument? document, int pageIndex, int pageCount, string label)
    {
        var rec = new BordereauRecord
        {
            Document = document, PageIndex = pageIndex, PageCount = pageCount, SourceLabel = label, OcrText = text
        };
        if (string.IsNullOrWhiteSpace(text))
        {
            rec.Issues.Add(IssueKind.NoText);
            return rec;
        }

        var folded = TextTools.Fold(text);
        var model = _config.Models
            .Select(m => (m, score: m.Score(folded)))
            .Where(x => x.score > 0)
            .OrderByDescending(x => x.score)
            .Select(x => x.m)
            .FirstOrDefault();
        rec.Model = model?.Name ?? "Générique";

        rec.Type = Clean(First(model?.TypePatterns, text) ?? First(Generic.TypePatterns, text));
        rec.Company = FindCompany(model, text);
        rec.PeriodRaw = First(model?.PeriodPatterns, text) ?? First(Generic.PeriodPatterns, text);
        if (ValueParser.TryParsePeriod(rec.PeriodRaw, out var period)) rec.Period = period;
        rec.Reference = First(model?.ReferencePatterns, text) ?? First(Generic.ReferencePatterns, text);
        rec.TotalRaw = First(model?.TotalPatterns, text) ?? First(Generic.TotalPatterns, text);
        if (ValueParser.TryParseAmount(rec.TotalRaw, out var total)) rec.Total = total;
        var count = First(model?.CountPatterns, text) ?? First(Generic.CountPatterns, text);
        if (int.TryParse(count, out var n)) rec.DeclaredCount = n;
        rec.Lines.AddRange(ReadLines(text));
        return rec;
    }

    /// <summary>
    /// Compagnie concernée : d'abord le champ écrit (« Compagnie adverse : », « pour le compte de la compagnie »),
    /// sinon la première compagnie connue citée, en ignorant la nôtre (présente sur tous les bordereaux).
    /// </summary>
    private string? FindCompany(ModelDefinition? model, string text)
    {
        foreach (var raw in All(model?.CompanyPatterns, text).Concat(All(Generic.CompanyPatterns, text)))
        {
            var name = _config.NormalizeCompany(raw);
            if (name != null && !IsOwn(name)) return name;
            var cleaned = Clean(Regex.Replace(raw, @"^[\s\d\-–:.]+", ""));
            if (cleaned is { Length: >= 3 } && !IsOwn(cleaned) && name == null && _config.NormalizeCompany(cleaned) == null
                && Regex.IsMatch(cleaned, "[A-Za-z]{3}"))
                return cleaned;
        }
        // Repli : compagnie connue citée le plus tôt dans le texte
        var words = " " + TextTools.FoldWords(text) + " ";
        return _config.Companies
            .Where(c => !IsOwn(c.Name))
            .Select(c => (c.Name, pos: c.Keywords.Select(k => words.IndexOf(" " + TextTools.FoldWords(k) + " ", StringComparison.Ordinal))
                                               .Where(i => i >= 0).DefaultIfEmpty(int.MaxValue).Min()))
            .Where(x => x.pos < int.MaxValue)
            .OrderBy(x => x.pos)
            .Select(x => x.Name)
            .FirstOrDefault();
    }

    private bool IsOwn(string name)
    {
        var f = " " + TextTools.FoldWords(name) + " ";
        return _config.OwnCompanyKeywords.Any(k => f.Contains(" " + TextTools.FoldWords(k) + " ", StringComparison.Ordinal));
    }

    /// <summary>Lignes du tableau : référence (8 chiffres et plus), identifiant, libellé et montant.</summary>
    public static List<BordereauLine> ReadLines(string text)
    {
        var lines = new List<BordereauLine>();
        foreach (var rawLine in text.Split('\n'))
        {
            var line = rawLine.Replace('|', ' ').Trim();
            if (TextTools.Fold(line).Contains("TOTAL", StringComparison.Ordinal)) continue;
            var reference = RefToken.Match(line);
            var amounts = AmountToken.Matches(line);
            if (!reference.Success || amounts.Count == 0) continue;
            var amount = amounts[^1];
            if (amount.Index < reference.Index) continue;

            var entry = new BordereauLine { Reference = reference.Value, AmountRaw = amount.Value.Trim() };
            if (ValueParser.TryParseAmount(entry.AmountRaw, out var a)) entry.Amount = a;
            var labels = new List<string>();
            // Avant la référence (ex. « Lloyd Tunisien ») et entre la référence et le montant
            var parts = new[] { line[..reference.Index], line[(reference.Index + reference.Length)..amount.Index] };
            for (int k = 0; k < parts.Length; k++)
                foreach (var token in parts[k].Split(' ', StringSplitOptions.RemoveEmptyEntries))
                {
                    if (k == 1 && entry.Identifier == null && IdToken.IsMatch(token)) entry.Identifier = token;
                    else if (Regex.IsMatch(token, @"^[A-Za-zÀ-ÿ'’\-.]{2,}$")) labels.Add(token);
                }
            entry.Label = labels.Count > 0 ? string.Join(" ", labels) : null;
            lines.Add(entry);
        }
        return lines;
    }

    private static string? Clean(string? s) => string.IsNullOrWhiteSpace(s) ? null : Regex.Replace(s, @"\s+", " ").Trim(' ', ':', '-', '|', '.');

    private static string? First(IEnumerable<string>? patterns, string text) => All(patterns, text).FirstOrDefault();

    private static IEnumerable<string> All(IEnumerable<string>? patterns, string text)
    {
        if (patterns == null) yield break;
        foreach (var p in patterns)
        {
            Match m;
            try { m = ModelDefinition.Compile(p).Match(text); }
            catch (ArgumentException) { continue; }          // motif mal écrit dans le fichier des modèles
            catch (RegexMatchTimeoutException) { continue; } // motif trop lent
            if (m.Success && m.Groups["v"].Success)
            {
                var v = m.Groups["v"].Value.Split('\n')[0].Trim().TrimEnd('.', ',', ':', ';', '|').Trim();
                if (v.Length > 0) yield return v;
            }
        }
    }
}

/// <summary>Reconstitue les lignes de texte d'une page à partir des mots OCR et de leur position.</summary>
public static class OcrText
{
    public static string ToText(IEnumerable<OcrWord> words)
    {
        // Coordonnées PDF : Y part du bas. On trie de haut en bas, puis on regroupe les mots alignés.
        var list = words.OrderByDescending(w => w.Y + w.Height / 2).ToList();
        var lines = new List<List<OcrWord>>();
        foreach (var w in list)
        {
            double cy = w.Y + w.Height / 2;
            var line = lines.LastOrDefault();
            if (line != null)
            {
                double ly = line.Average(x => x.Y + x.Height / 2), lh = line.Average(x => x.Height);
                if (Math.Abs(cy - ly) < Math.Max(lh, w.Height) * 0.5) { line.Add(w); continue; }
            }
            lines.Add(new List<OcrWord> { w });
        }
        return string.Join("\n", lines.Select(l => string.Join(" ", l.OrderBy(x => x.X).Select(x => x.Text))));
    }
}
