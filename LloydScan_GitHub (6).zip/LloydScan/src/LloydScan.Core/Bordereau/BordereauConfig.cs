using System.Text.Json;
using System.Text.RegularExpressions;

namespace LloydScan.Core.Bordereau;

/// <summary>
/// Fichier bordereau-templates.json (géré par l'administrateur, sans recompilation) :
/// les compagnies connues et les modèles de bordereaux (une mise en page = un modèle).
/// </summary>
public sealed class BordereauConfig
{
    /// <summary>Notre compagnie : jamais retenue comme « compagnie concernée » (elle figure sur tous les bordereaux).</summary>
    public List<string> OwnCompanyKeywords { get; set; } = new() { "LLOYD" };
    public List<CompanyDefinition> Companies { get; set; } = new();
    public List<ModelDefinition> Models { get; set; } = new();

    public static BordereauConfig Load(string path)
    {
        var options = new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true,
            ReadCommentHandling = JsonCommentHandling.Skip,
            AllowTrailingCommas = true
        };
        return JsonSerializer.Deserialize<BordereauConfig>(File.ReadAllText(path), options) ?? new BordereauConfig();
    }

    /// <summary>Nom officiel d'une compagnie à partir d'un texte (« 000003 - ASSURANCES GAT » → « GAT Assurances »).</summary>
    public string? NormalizeCompany(string? text)
    {
        if (string.IsNullOrWhiteSpace(text)) return null;
        var folded = " " + TextTools.FoldWords(text) + " ";
        return Companies.FirstOrDefault(c => c.Keywords.Any(k => folded.Contains(" " + TextTools.FoldWords(k) + " ", StringComparison.Ordinal)))?.Name;
    }
}

public sealed class CompanyDefinition
{
    public string Name { get; set; } = "";
    /// <summary>Mots qui désignent la compagnie (mots entiers ; majuscules et accents indifférents).</summary>
    public List<string> Keywords { get; set; } = new();
}

/// <summary>Une mise en page de bordereau. Chaque motif expose sa valeur dans le groupe nommé « v ».</summary>
public sealed class ModelDefinition
{
    public string Name { get; set; } = "";
    /// <summary>Phrases qui identifient ce modèle (titre du bordereau…).</summary>
    public List<string> DetectKeywords { get; set; } = new();
    public List<string> TypePatterns { get; set; } = new();
    public List<string> CompanyPatterns { get; set; } = new();
    public List<string> PeriodPatterns { get; set; } = new();
    public List<string> ReferencePatterns { get; set; } = new();
    public List<string> TotalPatterns { get; set; } = new();
    public List<string> CountPatterns { get; set; } = new();

    public int Score(string folded) => DetectKeywords.Count(k => folded.Contains(TextTools.Fold(k), StringComparison.Ordinal));

    internal static Regex Compile(string pattern) =>
        new(pattern, RegexOptions.IgnoreCase | RegexOptions.CultureInvariant | RegexOptions.Multiline, TimeSpan.FromSeconds(2));
}

internal static class TextTools
{
    /// <summary>Majuscules sans accents : « Payées » et « PAYEES » se reconnaissent.</summary>
    public static string Fold(string s)
    {
        var d = s.Normalize(System.Text.NormalizationForm.FormD);
        var sb = new System.Text.StringBuilder(d.Length);
        foreach (var c in d)
            if (System.Globalization.CharUnicodeInfo.GetUnicodeCategory(c) != System.Globalization.UnicodeCategory.NonSpacingMark)
                sb.Append(char.ToUpperInvariant(c));
        return sb.ToString();
    }

    /// <summary>Comme Fold, ponctuation remplacée par des espaces (comparaison par mots entiers).</summary>
    public static string FoldWords(string s) =>
        Regex.Replace(Regex.Replace(Fold(s), @"[^A-Z0-9]+", " "), @"\s+", " ").Trim();
}
