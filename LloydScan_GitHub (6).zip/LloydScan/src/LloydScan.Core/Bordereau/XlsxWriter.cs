using System.Globalization;
using System.IO.Compression;
using System.Security;
using System.Text;

namespace LloydScan.Core.Bordereau;

/// <summary>
/// Écriture d'un classeur Excel (.xlsx) d'une feuille, sans bibliothèque externe : texte, nombres, dates,
/// formule, liens, filtre automatique, première ligne figée, couleurs. Ouvert par Excel, LibreOffice et Google Sheets.
/// </summary>
public sealed class XlsxSheet
{
    public enum Style
    {
        Default = 0, Header = 1, Text = 2, Amount = 3, Date = 4,
        TextWarn = 5, AmountWarn = 6, DateWarn = 7, Link = 8, LinkWarn = 9,
        TotalLabel = 10, TotalAmount = 11, TotalBlank = 12, Period = 13, PeriodWarn = 14
    }

    private sealed record Cell(int Col, string Xml);
    private readonly SortedDictionary<int, List<Cell>> _rows = new();
    private readonly List<(string Ref, string Target)> _links = new();
    public string Name { get; set; } = "Feuille1";
    public double[] ColumnWidths { get; set; } = Array.Empty<double>();
    public bool FreezeFirstRow { get; set; } = true;
    public string? AutoFilter { get; set; }

    private static string Ref(int row, int col)
    {
        var s = "";
        for (int c = col; c > 0; c = (c - 1) / 26) s = (char)('A' + (c - 1) % 26) + s;
        return s + row.ToString(CultureInfo.InvariantCulture);
    }

    private void Add(int row, int col, string xml)
    {
        if (!_rows.TryGetValue(row, out var list)) _rows[row] = list = new List<Cell>();
        list.RemoveAll(c => c.Col == col);
        list.Add(new Cell(col, xml));
    }

    public void Text(int row, int col, string? text, Style style = Style.Text) =>
        Add(row, col, $"<c r=\"{Ref(row, col)}\" s=\"{(int)style}\" t=\"inlineStr\"><is><t xml:space=\"preserve\">{Esc(text ?? "")}</t></is></c>");

    public void Number(int row, int col, double value, Style style) =>
        Add(row, col, $"<c r=\"{Ref(row, col)}\" s=\"{(int)style}\"><v>{value.ToString("R", CultureInfo.InvariantCulture)}</v></c>");

    public void Date(int row, int col, DateTime date, Style style) =>
        Number(row, col, (date.Date - new DateTime(1899, 12, 30)).TotalDays, style);

    public void Empty(int row, int col, Style style) =>
        Add(row, col, $"<c r=\"{Ref(row, col)}\" s=\"{(int)style}\"/>");

    /// <summary>Formule avec sa valeur déjà calculée (affichée même sans recalcul).</summary>
    public void Formula(int row, int col, string formula, double cached, Style style) =>
        Add(row, col, $"<c r=\"{Ref(row, col)}\" s=\"{(int)style}\"><f>{Esc(formula)}</f><v>{cached.ToString("R", CultureInfo.InvariantCulture)}</v></c>");

    /// <summary>Lien vers un fichier (chemin relatif au classeur) ou une adresse.</summary>
    public void Link(int row, int col, string text, string target, Style style)
    {
        Text(row, col, text, style);
        _links.Add((Ref(row, col), target));
    }

    public static string CellRef(int row, int col) => Ref(row, col);

    internal string RelsXml()
    {
        if (_links.Count == 0) return "";
        var rels = new StringBuilder("<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">");
        for (int i = 0; i < _links.Count; i++)
            rels.Append($"<Relationship Id=\"rIdL{i + 1}\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink\" Target=\"{Esc(_links[i].Target)}\" TargetMode=\"External\"/>");
        rels.Append("</Relationships>");
        return rels.ToString();
    }

    internal string FilterDefinedName(int sheetIndex) => AutoFilter == null ? "" :
        $"<definedName name=\"_xlnm._FilterDatabase\" localSheetId=\"{sheetIndex}\" hidden=\"1\">'{Esc(Name.Replace("'", "''"))}'!{Absolute(AutoFilter)}</definedName>";

    private static string Absolute(string range) =>
        string.Join(":", range.Split(':').Select(r =>
        {
            int i = 0;
            while (i < r.Length && char.IsLetter(r[i])) i++;
            return "$" + r[..i] + "$" + r[i..];
        }));

    internal string SheetXml()
    {
        var sb = new StringBuilder();
        sb.Append("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" " +
                  "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">");
        sb.Append("<sheetPr><pageSetUpPr fitToPage=\"1\"/></sheetPr>");
        sb.Append("<sheetViews><sheetView workbookViewId=\"0\"");
        sb.Append(FreezeFirstRow
            ? "><pane ySplit=\"1\" topLeftCell=\"A2\" activePane=\"bottomLeft\" state=\"frozen\"/><selection pane=\"bottomLeft\" activeCell=\"A2\" sqref=\"A2\"/></sheetView>"
            : "/>");
        sb.Append("</sheetViews><sheetFormatPr defaultRowHeight=\"15\"/>");
        if (ColumnWidths.Length > 0)
        {
            sb.Append("<cols>");
            for (int i = 0; i < ColumnWidths.Length; i++)
                sb.Append($"<col min=\"{i + 1}\" max=\"{i + 1}\" width=\"{ColumnWidths[i].ToString(CultureInfo.InvariantCulture)}\" customWidth=\"1\"/>");
            sb.Append("</cols>");
        }
        sb.Append("<sheetData>");
        foreach (var (row, cells) in _rows)
        {
            sb.Append($"<row r=\"{row}\">");
            foreach (var c in cells.OrderBy(c => c.Col)) sb.Append(c.Xml);
            sb.Append("</row>");
        }
        sb.Append("</sheetData>");
        if (AutoFilter != null) sb.Append($"<autoFilter ref=\"{AutoFilter}\"/>");
        if (_links.Count > 0)
        {
            sb.Append("<hyperlinks>");
            for (int i = 0; i < _links.Count; i++) sb.Append($"<hyperlink ref=\"{_links[i].Ref}\" r:id=\"rIdL{i + 1}\"/>");
            sb.Append("</hyperlinks>");
        }
        sb.Append("<pageMargins left=\"0.5\" right=\"0.5\" top=\"0.6\" bottom=\"0.6\" header=\"0.3\" footer=\"0.3\"/>");
        sb.Append("<pageSetup orientation=\"landscape\" paperSize=\"9\" fitToWidth=\"1\" fitToHeight=\"0\"/>");
        sb.Append("</worksheet>");
        return sb.ToString();
    }

    internal static string Esc(string s)
    {
        // Caractères de contrôle interdits en XML (texte OCR)
        var clean = new string(s.Where(c => c == '\t' || c == '\n' || c == '\r' || c >= ' ').ToArray());
        return SecurityElement.Escape(clean) ?? "";
    }

    internal const string StylesXml =
        "<styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">" +
        "<numFmts count=\"3\"><numFmt numFmtId=\"164\" formatCode=\"#,##0.000\"/><numFmt numFmtId=\"165\" formatCode=\"dd/mm/yyyy\"/><numFmt numFmtId=\"166\" formatCode=\"mm/yyyy\"/></numFmts>" +
        "<fonts count=\"4\">" +
        "<font><sz val=\"11\"/><name val=\"Calibri\"/><family val=\"2\"/></font>" +
        "<font><b/><sz val=\"11\"/><name val=\"Calibri\"/><family val=\"2\"/></font>" +
        "<font><b/><sz val=\"11\"/><color rgb=\"FFFFFFFF\"/><name val=\"Calibri\"/><family val=\"2\"/></font>" +
        "<font><u/><sz val=\"11\"/><color rgb=\"FF0563C1\"/><name val=\"Calibri\"/><family val=\"2\"/></font>" +
        "</fonts>" +
        "<fills count=\"4\">" +
        "<fill><patternFill patternType=\"none\"/></fill>" +
        "<fill><patternFill patternType=\"gray125\"/></fill>" +
        "<fill><patternFill patternType=\"solid\"><fgColor rgb=\"FF1F4E78\"/><bgColor indexed=\"64\"/></patternFill></fill>" +
        "<fill><patternFill patternType=\"solid\"><fgColor rgb=\"FFFFF2CC\"/><bgColor indexed=\"64\"/></patternFill></fill>" +
        "</fills>" +
        "<borders count=\"2\">" +
        "<border><left/><right/><top/><bottom/><diagonal/></border>" +
        "<border><left/><right/><top style=\"medium\"><color auto=\"1\"/></top><bottom/><diagonal/></border>" +
        "</borders>" +
        "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>" +
        "<cellXfs count=\"15\">" +
        "<xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/>" +                                                     // 0
        "<xf numFmtId=\"0\" fontId=\"2\" fillId=\"2\" borderId=\"0\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\" applyAlignment=\"1\"><alignment vertical=\"center\" wrapText=\"1\"/></xf>" + // 1 en-tête
        "<xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/>" +                                                     // 2 texte
        "<xf numFmtId=\"164\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyNumberFormat=\"1\"/>" +                          // 3 montant
        "<xf numFmtId=\"165\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyNumberFormat=\"1\"/>" +                          // 4 date
        "<xf numFmtId=\"0\" fontId=\"0\" fillId=\"3\" borderId=\"0\" xfId=\"0\" applyFill=\"1\"/>" +                                    // 5 texte à vérifier
        "<xf numFmtId=\"164\" fontId=\"0\" fillId=\"3\" borderId=\"0\" xfId=\"0\" applyNumberFormat=\"1\" applyFill=\"1\"/>" +          // 6
        "<xf numFmtId=\"165\" fontId=\"0\" fillId=\"3\" borderId=\"0\" xfId=\"0\" applyNumberFormat=\"1\" applyFill=\"1\"/>" +          // 7
        "<xf numFmtId=\"0\" fontId=\"3\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyFont=\"1\"/>" +                                    // 8 lien
        "<xf numFmtId=\"0\" fontId=\"3\" fillId=\"3\" borderId=\"0\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\"/>" +                    // 9
        "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"0\" borderId=\"1\" xfId=\"0\" applyFont=\"1\" applyBorder=\"1\"/>" +                  // 10 TOTAL
        "<xf numFmtId=\"164\" fontId=\"1\" fillId=\"0\" borderId=\"1\" xfId=\"0\" applyNumberFormat=\"1\" applyFont=\"1\" applyBorder=\"1\"/>" + // 11
        "<xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"1\" xfId=\"0\" applyBorder=\"1\"/>" +                                  // 12
        "<xf numFmtId=\"166\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyNumberFormat=\"1\"/>" +                          // 13 période
        "<xf numFmtId=\"166\" fontId=\"0\" fillId=\"3\" borderId=\"0\" xfId=\"0\" applyNumberFormat=\"1\" applyFill=\"1\"/>" +          // 14
        "</cellXfs>" +
        "<cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles>" +
        "</styleSheet>";
}

/// <summary>Classeur de plusieurs feuilles (styles communs).</summary>
public sealed class XlsxWorkbook
{
    public List<XlsxSheet> Sheets { get; } = new();
    public string Title { get; set; } = "";

    public XlsxSheet Add(string name)
    {
        var sheet = new XlsxSheet { Name = name };
        Sheets.Add(sheet);
        return sheet;
    }

    public void Save(string path)
    {
        var temp = path + ".tmp";
        using (var fs = File.Create(temp))
        using (var zip = new ZipArchive(fs, ZipArchiveMode.Create))
        {
            void Entry(string name, string content)
            {
                var e = zip.CreateEntry(name, CompressionLevel.Optimal);
                using var w = new StreamWriter(e.Open(), new UTF8Encoding(false));
                w.Write(content);
            }
            const string decl = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n";
            var types = new StringBuilder("<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
                "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
                "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
                "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>" +
                "<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>" +
                "<Override PartName=\"/docProps/core.xml\" ContentType=\"application/vnd.openxmlformats-package.core-properties+xml\"/>");
            for (int i = 0; i < Sheets.Count; i++)
                types.Append($"<Override PartName=\"/xl/worksheets/sheet{i + 1}.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>");
            types.Append("</Types>");
            Entry("[Content_Types].xml", decl + types);
            Entry("_rels/.rels", decl +
                "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/>" +
                "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties\" Target=\"docProps/core.xml\"/>" +
                "</Relationships>");
            Entry("docProps/core.xml", decl +
                "<cp:coreProperties xmlns:cp=\"http://schemas.openxmlformats.org/package/2006/metadata/core-properties\" " +
                "xmlns:dc=\"http://purl.org/dc/elements/1.1/\" xmlns:dcterms=\"http://purl.org/dc/terms/\" " +
                "xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">" +
                $"<dc:title>{XlsxSheet.Esc(Title)}</dc:title><dc:creator>NAPS++</dc:creator>" +
                $"<dcterms:created xsi:type=\"dcterms:W3CDTF\">{DateTime.UtcNow:yyyy-MM-ddTHH:mm:ssZ}</dcterms:created>" +
                "</cp:coreProperties>");
            var sheets = new StringBuilder();
            var names = new StringBuilder();
            var wbRels = new StringBuilder("<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">");
            for (int i = 0; i < Sheets.Count; i++)
            {
                sheets.Append($"<sheet name=\"{XlsxSheet.Esc(Sheets[i].Name)}\" sheetId=\"{i + 1}\" r:id=\"rId{i + 1}\"/>");
                names.Append(Sheets[i].FilterDefinedName(i));
                wbRels.Append($"<Relationship Id=\"rId{i + 1}\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet{i + 1}.xml\"/>");
            }
            wbRels.Append($"<Relationship Id=\"rId{Sheets.Count + 1}\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/></Relationships>");
            Entry("xl/workbook.xml", decl +
                "<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" " +
                "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">" +
                $"<sheets>{sheets}</sheets>" + (names.Length > 0 ? $"<definedNames>{names}</definedNames>" : "") +
                "<calcPr calcId=\"191029\" fullCalcOnLoad=\"1\"/></workbook>");
            Entry("xl/_rels/workbook.xml.rels", decl + wbRels);
            Entry("xl/styles.xml", decl + XlsxSheet.StylesXml);
            for (int i = 0; i < Sheets.Count; i++)
            {
                Entry($"xl/worksheets/sheet{i + 1}.xml", decl + Sheets[i].SheetXml());
                var rels = Sheets[i].RelsXml();
                if (rels.Length > 0) Entry($"xl/worksheets/_rels/sheet{i + 1}.xml.rels", decl + rels);
            }
        }
        File.Move(temp, path, overwrite: true);
    }
}
