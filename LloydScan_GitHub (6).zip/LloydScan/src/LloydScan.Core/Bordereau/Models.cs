using LloydScan.Core.Processing;

namespace LloydScan.Core.Bordereau;

public enum IssueKind
{
    NoText,
    UnknownModel,
    MissingCompany,
    MissingPeriod,
    InvalidPeriod,
    MissingTotal,
    InvalidTotal,
    SumMismatch,
    CountMismatch,
    NoLines,
    Duplicate
}

/// <summary>Une ligne du tableau d'un bordereau (un sinistre / une quittance).</summary>
public sealed class BordereauLine
{
    /// <summary>N° de sinistre ou « Nos Réf. ».</summary>
    public string Reference { get; set; } = "";
    /// <summary>Second identifiant de la ligne : n° de contrat ou immatriculation.</summary>
    public string? Identifier { get; set; }
    /// <summary>Texte de la ligne (assuré, compagnie…).</summary>
    public string? Label { get; set; }
    public decimal? Amount { get; set; }
    public string? AmountRaw { get; set; }
}

/// <summary>Un bordereau extrait. Les champs *Raw gardent le texte tel que lu par l'OCR.</summary>
public sealed class BordereauRecord
{
    /// <summary>Document NAPS++ d'origine (son PDF est joint à l'export Excel).</summary>
    public ScanDocument? Document { get; init; }
    /// <summary>Première page du bordereau dans le document (1 = première page).</summary>
    public int PageIndex { get; init; } = 1;
    public int PageCount { get; init; } = 1;
    public string SourceLabel { get; init; } = "";

    /// <summary>Modèle reconnu (« Recours hors IDA », « État des quittances payées »… ; « Générique » sinon).</summary>
    public string Model { get; set; } = "Générique";
    /// <summary>Type écrit sur le bordereau (titre).</summary>
    public string? Type { get; set; }
    /// <summary>Compagnie concernée (compagnie adverse / pour le compte de).</summary>
    public string? Company { get; set; }
    /// <summary>Période du bordereau (mois).</summary>
    public DateTime? Period { get; set; }
    public string? PeriodRaw { get; set; }
    /// <summary>Référence du bordereau, s'il en a une.</summary>
    public string? Reference { get; set; }
    public decimal? Total { get; set; }
    public string? TotalRaw { get; set; }
    /// <summary>Nombre de lignes annoncé sur le bordereau (« Nombre de sinistres : 1 »), s'il est écrit.</summary>
    public int? DeclaredCount { get; set; }
    public List<BordereauLine> Lines { get; } = new();
    public decimal LinesSum => Lines.Where(l => l.Amount.HasValue).Sum(l => l.Amount!.Value);

    /// <summary>Vrai si l'agent a corrigé au moins un champ à la main.</summary>
    public bool Corrected { get; set; }

    public List<IssueKind> Issues { get; } = new();
    public bool HasIssues => Issues.Count > 0;
    public string IssuesText => HasIssues ? string.Join(" ; ", Issues.Distinct().Select(i => BordereauValidator.Describe(i, this))) : "OK";

    /// <summary>Texte OCR complet, affiché pour aider à la correction.</summary>
    public string OcrText { get; init; } = "";
}
