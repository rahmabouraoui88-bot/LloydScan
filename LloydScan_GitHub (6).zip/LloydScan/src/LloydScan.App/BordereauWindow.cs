using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;
using LloydScan.Core.Bordereau;
using Microsoft.Win32;

namespace LloydScan.App;

/// <summary>
/// Écran de vérification des bordereaux de règlement : une ligne par bordereau (compagnie, référence, montant, date),
/// lignes à vérifier en jaune, correction directe dans le tableau, texte lu et document à côté, puis export Excel.
/// </summary>
public sealed class BordereauWindow : Window
{
    private static readonly CultureInfo Fr = CultureInfo.GetCultureInfo("fr-FR");
    private readonly BordereauService _service;
    private readonly List<BordereauRecord> _records;
    private readonly string _outputFolder;
    private readonly ObservableCollection<BordereauRow> _rows = new();
    private readonly DataGrid _grid;
    private readonly TextBox _ocrText;
    private readonly DataGrid _lines;
    private readonly ObservableCollection<LineRow> _lineRows = new();
    private readonly TextBlock _source;
    private readonly TextBlock _summary;
    private readonly Func<List<BordereauRecord>>? _reextract;

    public BordereauWindow(BordereauService service, List<BordereauRecord> records, string outputFolder,
                           Func<List<BordereauRecord>>? reextract = null)
    {
        _service = service;
        _records = records;
        _outputFolder = outputFolder;
        _reextract = reextract;

        Title = "Bordereaux de règlement — vérification avant export Excel";
        Width = 1250;
        Height = 760;
        MinWidth = 900;
        MinHeight = 500;
        WindowStartupLocation = WindowStartupLocation.CenterOwner;
        FontFamily = new FontFamily("Segoe UI");
        FontSize = 13;

        _summary = new TextBlock { Margin = new Thickness(12, 10, 12, 4), FontSize = 14, TextWrapping = TextWrapping.Wrap };
        var help = new TextBlock
        {
            Margin = new Thickness(12, 0, 12, 8), Foreground = Brushes.DimGray, FontSize = 12, TextWrapping = TextWrapping.Wrap,
            Text = "Lignes en jaune : à vérifier (le motif est dans « Contrôle »). Double-cliquez sur une case pour la corriger " +
                   "(total : 14282,087 · période : 12/2025). À droite : chaque n° de sinistre avec son montant (corrigeables), le texte OCR et le document."
        };

        _grid = new DataGrid
        {
            ItemsSource = _rows,
            AutoGenerateColumns = false,
            CanUserAddRows = false,
            CanUserDeleteRows = false,
            SelectionMode = DataGridSelectionMode.Single,
            HeadersVisibility = DataGridHeadersVisibility.Column,
            GridLinesVisibility = DataGridGridLinesVisibility.Horizontal,
            HorizontalGridLinesBrush = new SolidColorBrush(Color.FromRgb(0xE3, 0xE6, 0xEA)),
            RowHeight = 28,
            Margin = new Thickness(12, 0, 6, 0)
        };
        _grid.Columns.Add(Col("N°", nameof(BordereauRow.Number), 40, readOnly: true));
        _grid.Columns.Add(Col("Type de bordereau", nameof(BordereauRow.Type), 190));
        _grid.Columns.Add(Col("Compagnie", nameof(BordereauRow.Company), 140));
        _grid.Columns.Add(Col("Période", nameof(BordereauRow.PeriodText), 75));
        _grid.Columns.Add(Col("Référence", nameof(BordereauRow.Reference), 100));
        _grid.Columns.Add(Col("Lignes", nameof(BordereauRow.LinesText), 70, readOnly: true, right: true));
        _grid.Columns.Add(Col("Somme lignes", nameof(BordereauRow.LinesSumText), 110, readOnly: true, right: true));
        _grid.Columns.Add(Col("Total (TND)", nameof(BordereauRow.TotalText), 110, right: true));
        _grid.Columns.Add(Col("Contrôle", nameof(BordereauRow.Control), 260, readOnly: true));

        var rowStyle = new Style(typeof(DataGridRow));
        var warn = new DataTrigger { Binding = new Binding(nameof(BordereauRow.HasIssues)), Value = true };
        warn.Setters.Add(new Setter(BackgroundProperty, new SolidColorBrush(Color.FromRgb(0xFF, 0xF2, 0xCC))));
        rowStyle.Triggers.Add(warn);
        _grid.RowStyle = rowStyle;
        _grid.SelectionChanged += (_, _) => ShowDetails();
        _grid.MouseDoubleClick += (_, e) =>
        {
            // Double-clic sur une colonne non modifiable : ouvrir le document
            if (_grid.CurrentColumn?.IsReadOnly == true) ShowDocument();
        };

        // ----- Panneau de droite : texte lu + document -----
        _ocrText = new TextBox
        {
            IsReadOnly = true, TextWrapping = TextWrapping.Wrap, VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
            FontFamily = new FontFamily("Consolas"), FontSize = 12, Background = new SolidColorBrush(Color.FromRgb(0xF7, 0xF8, 0xFA))
        };
        var showDoc = new Button { Content = "🔍 Voir le document", Padding = new Thickness(10, 4, 10, 4), Margin = new Thickness(0, 6, 0, 0), HorizontalAlignment = HorizontalAlignment.Left };
        showDoc.Click += (_, _) => ShowDocument();
        _lines = new DataGrid
        {
            ItemsSource = _lineRows, AutoGenerateColumns = false, CanUserAddRows = false, CanUserDeleteRows = false,
            HeadersVisibility = DataGridHeadersVisibility.Column, Height = 220, Margin = new Thickness(0, 0, 0, 8),
            GridLinesVisibility = DataGridGridLinesVisibility.Horizontal, RowHeight = 24
        };
        _lines.Columns.Add(Col("Référence sinistre", nameof(LineRow.Reference), 140));
        _lines.Columns.Add(Col("Montant", nameof(LineRow.AmountText), 100, right: true));
        _lines.Columns.Add(Col("Contrat / immat.", nameof(LineRow.Identifier), 110, readOnly: true));
        _lines.Columns.Add(Col("Libellé", nameof(LineRow.Label), 130, readOnly: true));
        _source = new TextBlock { TextWrapping = TextWrapping.Wrap, Foreground = Brushes.DimGray, FontSize = 12, Margin = new Thickness(0, 0, 0, 6) };
        var side = new DockPanel { Width = 360, Margin = new Thickness(6, 0, 12, 0) };
        var linesTitle = new TextBlock { Text = "Sinistres du bordereau : référence et montant (corrigeables)", FontWeight = FontWeights.SemiBold, Margin = new Thickness(0, 0, 0, 4), TextWrapping = TextWrapping.Wrap };
        var sideTitle = new TextBlock { Text = "Texte lu sur le bordereau (OCR)", FontWeight = FontWeights.SemiBold, Margin = new Thickness(0, 0, 0, 4) };
        foreach (var e in new UIElement[] { _source, linesTitle, _lines, sideTitle }) DockPanel.SetDock(e, Dock.Top);
        DockPanel.SetDock(showDoc, Dock.Bottom);
        side.Children.Add(_source);
        side.Children.Add(linesTitle);
        side.Children.Add(_lines);
        side.Children.Add(sideTitle);
        side.Children.Add(showDoc);
        side.Children.Add(_ocrText);

        // ----- Boutons -----
        var buttons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(12, 10, 12, 12) };
        if (_reextract != null)
        {
            var again = new Button { Content = "Relire les pages", Padding = new Thickness(10, 5, 10, 5), Margin = new Thickness(0, 0, 8, 0),
                ToolTip = "Refaire la lecture (après une retouche des pages). Les corrections faites ici sont perdues." };
            again.Click += (_, _) => Reextract();
            buttons.Children.Add(again);
        }
        var export = new Button { Content = "Exporter vers Excel…", IsDefault = true, Padding = new Thickness(14, 5, 14, 5), Margin = new Thickness(0, 0, 8, 0), FontWeight = FontWeights.SemiBold };
        export.Click += async (_, _) => await ExportAsync();
        var close = new Button { Content = "Fermer", IsCancel = true, Padding = new Thickness(14, 5, 14, 5) };
        buttons.Children.Add(export);
        buttons.Children.Add(close);

        var root = new DockPanel();
        DockPanel.SetDock(_summary, Dock.Top);
        DockPanel.SetDock(help, Dock.Top);
        DockPanel.SetDock(buttons, Dock.Bottom);
        DockPanel.SetDock(side, Dock.Right);
        root.Children.Add(_summary);
        root.Children.Add(help);
        root.Children.Add(buttons);
        root.Children.Add(side);
        root.Children.Add(_grid);
        Content = root;

        Load(records);
    }

    private static DataGridTextColumn Col(string header, string path, double width, bool readOnly = false, bool right = false)
    {
        var col = new DataGridTextColumn
        {
            Header = header,
            Binding = new Binding(path) { Mode = readOnly ? BindingMode.OneWay : BindingMode.TwoWay, UpdateSourceTrigger = UpdateSourceTrigger.LostFocus },
            Width = new DataGridLength(width),
            IsReadOnly = readOnly
        };
        var style = new Style(typeof(TextBlock));
        style.Setters.Add(new Setter(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center));
        style.Setters.Add(new Setter(TextBlock.PaddingProperty, new Thickness(4, 0, 4, 0)));
        if (right) style.Setters.Add(new Setter(TextBlock.TextAlignmentProperty, TextAlignment.Right));
        col.ElementStyle = style;
        return col;
    }

    private void ShowDetails()
    {
        var r = (_grid.SelectedItem as BordereauRow)?.Record;
        _ocrText.Text = r?.OcrText ?? "";
        _source.Text = r == null ? "" : $"Document : {r.SourceLabel}  ·  modèle : {r.Model}";
        _lineRows.Clear();
        if (r != null) foreach (var l in r.Lines) _lineRows.Add(new LineRow(r, l, Changed));
    }

    private void Load(List<BordereauRecord> records)
    {
        _rows.Clear();
        int n = 1;
        foreach (var r in records) _rows.Add(new BordereauRow(r, n++, _service, Changed));
        UpdateSummary();
        if (_rows.Count > 0) _grid.SelectedIndex = 0;
    }

    /// <summary>Après une correction : nouveaux contrôles sur tout le tableau (les doublons dépendent des autres lignes).</summary>
    private void Changed()
    {
        _service.Validate(_records);
        foreach (var row in _rows) row.Refresh();
        UpdateSummary();
    }

    private void UpdateSummary()
    {
        int issues = _records.Count(r => r.HasIssues);
        decimal total = _records.Where(r => r.Total.HasValue).Sum(r => r.Total!.Value);
        _summary.Text = $"{_records.Count} bordereau(x) · total {total.ToString("#,##0.000", Fr)} TND · " +
                        (issues == 0 ? "tout est complet ✔" : $"{issues} à vérifier (en jaune)");
    }

    private void ShowDocument()
    {
        if (_grid.SelectedItem is not BordereauRow { Record.Document: { Pdf: { } pdf } doc } row) return;
        try
        {
            new PreviewWindow(pdf, doc.FileName, row.Record.PageIndex - 1) { Owner = this }.Show();
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, "Aperçu impossible : " + ex.Message, AppInfo.Name, MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }

    private void Reextract()
    {
        if (_reextract == null) return;
        if (_records.Any(r => r.Corrected) &&
            MessageBox.Show(this, "Relire les pages efface les corrections faites dans ce tableau. Continuer ?", "Relire les pages",
                MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
        var fresh = _reextract();
        _records.Clear();
        _records.AddRange(fresh);
        Load(_records);
    }

    private async Task ExportAsync()
    {
        _grid.CommitEdit(DataGridEditingUnit.Row, true);
        if (_records.Count == 0) return;
        int issues = _records.Count(r => r.HasIssues);
        if (issues > 0 && MessageBox.Show(this,
                $"{issues} bordereau(x) restent à vérifier (lignes en jaune).\nIls seront exportés surlignés en jaune, avec le motif dans la colonne « Contrôle ».\n\nExporter quand même ?",
                "Exporter vers Excel", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;

        try { Directory.CreateDirectory(_outputFolder); } catch { /* dossier proposé seulement */ }
        var dialog = new SaveFileDialog
        {
            Title = "Enregistrer le tableau des bordereaux",
            Filter = "Classeur Excel (*.xlsx)|*.xlsx",
            FileName = $"Bordereaux_{DateTime.Now:yyyy-MM-dd_HHmm}.xlsx",
            InitialDirectory = Directory.Exists(_outputFolder) ? _outputFolder : Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
            AddExtension = true
        };
        if (dialog.ShowDialog(this) != true) return;
        string path = dialog.FileName;
        IsEnabled = false;
        try
        {
            int pdfs = await Task.Run(() => _service.ExportExcel(_records, path));
            IsEnabled = true;
            var answer = MessageBox.Show(this,
                $"Tableau enregistré :\n{path}\n\n{_records.Count} ligne(s), {pdfs} document(s) PDF joint(s) dans le dossier « {Path.GetFileNameWithoutExtension(path)}_documents » " +
                "(lien dans la dernière colonne).\n\nOuvrir le tableau maintenant ?",
                "Export Excel terminé", MessageBoxButton.YesNo, MessageBoxImage.Information);
            if (answer == MessageBoxResult.Yes)
                Process.Start(new ProcessStartInfo(path) { UseShellExecute = true });
        }
        catch (Exception ex)
        {
            IsEnabled = true;
            MessageBox.Show(this, "Export impossible : " + ex.Message +
                            (ex is IOException ? "\n(Le fichier est peut-être déjà ouvert dans Excel.)" : ""),
                AppInfo.Name, MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }
}

/// <summary>Une ligne du tableau de vérification (correction directe des champs).</summary>
public sealed class BordereauRow : INotifyPropertyChanged
{
    private static readonly CultureInfo Fr = CultureInfo.GetCultureInfo("fr-FR");
    private readonly Action _changed;
    private readonly BordereauService _service;

    public BordereauRow(BordereauRecord record, int number, BordereauService service, Action changed)
    {
        Record = record;
        Number = number;
        _service = service;
        _changed = changed;
    }

    public BordereauRecord Record { get; }
    public int Number { get; }
    public string Source => Record.SourceLabel;
    public string Control => Record.IssuesText;
    public bool HasIssues => Record.HasIssues;
    public string LinesText => Record.DeclaredCount is int n && n != Record.Lines.Count ? $"{Record.Lines.Count} / {n}" : Record.Lines.Count.ToString(Fr);
    public string LinesSumText => Record.Lines.Count == 0 ? "" : Record.LinesSum.ToString("#,##0.000", Fr);

    private static string? Trimmed(string? v) => string.IsNullOrWhiteSpace(v) ? null : v.Trim();

    public string? Type
    {
        get => Record.Type;
        set { if (Trimmed(value) == Record.Type) return; Record.Type = Trimmed(value); Record.Corrected = true; _changed(); }
    }

    public string? Company
    {
        get => Record.Company;
        set { if (Trimmed(value) == Record.Company) return; _service.SetCompany(Record, value); _changed(); }
    }

    public string? Reference
    {
        get => Record.Reference;
        set { if (Trimmed(value) == Record.Reference) return; Record.Reference = Trimmed(value); Record.Corrected = true; _changed(); }
    }

    public string? PeriodText
    {
        get => Record.Period?.ToString("MM/yyyy", Fr) ?? Record.PeriodRaw;
        set { if (value == PeriodText) return; BordereauService.SetPeriod(Record, value); _changed(); }
    }

    public string? TotalText
    {
        get => Record.Total?.ToString("#,##0.000", Fr) ?? Record.TotalRaw;
        set { if (value == TotalText) return; BordereauService.SetTotal(Record, value); _changed(); }
    }

    public void Refresh() => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(string.Empty));

    public event PropertyChangedEventHandler? PropertyChanged;
}

/// <summary>Un sinistre du bordereau sélectionné : référence et montant corrigeables.</summary>
public sealed class LineRow : INotifyPropertyChanged
{
    private static readonly CultureInfo Fr = CultureInfo.GetCultureInfo("fr-FR");
    private readonly BordereauRecord _record;
    private readonly BordereauLine _line;
    private readonly Action _changed;

    public LineRow(BordereauRecord record, BordereauLine line, Action changed)
    {
        _record = record; _line = line; _changed = changed;
    }

    public string? Identifier => _line.Identifier;
    public string? Label => _line.Label;

    public string Reference
    {
        get => _line.Reference;
        set { var v = (value ?? "").Trim(); if (v == _line.Reference) return; _line.Reference = v; _record.Corrected = true; _changed(); }
    }

    public string? AmountText
    {
        get => _line.Amount?.ToString("#,##0.000", Fr) ?? _line.AmountRaw;
        set
        {
            if (value == AmountText) return;
            _line.AmountRaw = value;
            _line.Amount = ValueParser.TryParseAmount(value, out var a) ? a : null;
            _record.Corrected = true;
            _changed();
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(string.Empty));
        }
    }

    public event PropertyChangedEventHandler? PropertyChanged;
}
